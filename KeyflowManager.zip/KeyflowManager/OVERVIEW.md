# MROSINT Overview

## What it is

MROSINT is an online search tool that helps people find public information about mobile numbers, Aadhar details, and vehicle registrations using open-source data.

## How it works

Users buy credits using UPI payments (like PhonePe or Google Pay) to perform searches. Each search type costs different credits - mobile searches cost ₹99, Aadhar checks cost ₹149, and vehicle lookups cost ₹49.63.

## Key features

- Admin dashboard for managing users, payments, and system settings
- Referral system where users earn ₹25 for each friend who joins
- Telegram bot (@MROSINT1bot) for checking balances and getting search results
- Complete search history and transaction records for every user

## Technical basics

Built using Python Flask for the website, Bootstrap for mobile-friendly design, and secure databases. All sensitive data is encrypted with bank-level security.

## Recent improvements (July 2025)

- Better admin controls for managing users and credits
- Enhanced account settings for users to update profiles and passwords
- Improved mobile search results showing more details like names and addresses
- Simpler UPI payment process with exact-amount QR codes

## Special note about Telegram

The platform connects to an existing Telegram bot (@MROSINT1bot) for notifications. If this connection feature isn't working, just mention it needs to be added - no design changes needed since the interface is already good.