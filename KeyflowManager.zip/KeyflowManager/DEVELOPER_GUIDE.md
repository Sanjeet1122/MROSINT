# MROSINT Complete Developer Guide

This guide explains every component of the MROSINT platform. Anyone can recreate this exact website by following this documentation.

## Project Overview

MROSINT is a Flask-based OSINT platform with military-grade security, UPI payment integration, and comprehensive admin panel.

## Directory Structure

```
.
├── app.py                    # Flask app initialization, database setup
├── main.py                   # Application entry point
├── models.py                 # Database models (User, Payment, Search, etc.)
├── routes.py                 # Main application routes
├── admin_routes.py           # Admin panel routes  
├── support_routes.py         # Support ticket system routes
├── forms.py                  # WTForms form definitions
├── api_client.py            # Secure API client for external services
├── security.py              # Encryption and security utilities
├── security_interceptor.py   # Anti-interception protection
├── utils.py                 # Helper functions
├── config/
│   └── api_config.json      # API service configurations
├── services/
│   └── api_service.py       # Dynamic API service handler
├── static/
│   ├── css/
│   │   ├── style.css        # Main application styles
│   │   └── admin.css        # Admin panel styles
│   ├── js/
│   │   └── admin.js         # Admin panel JavaScript
│   └── images/
│       └── logo.svg         # MROSINT logo
├── templates/
│   ├── base.html            # Base template for user pages
│   ├── admin_base.html      # Base template for admin pages
│   ├── index.html           # Landing page
│   ├── login.html           # Login page
│   ├── register.html        # Registration page
│   ├── dashboard.html       # User dashboard
│   ├── search.html          # Search interface
│   ├── payment.html         # Payment page with UPI QR
│   ├── profile.html         # User profile
│   └── admin/               # Admin panel templates
└── logs/                    # Application logs

```

## Core Files Explained

### 1. app.py - Application Foundation
```python
# Purpose: Initialize Flask app, configure database, set security
# Key components:
- Flask app creation with secret key
- SQLAlchemy database configuration
- ProxyFix for HTTPS support
- Database connection pooling
- Automatic table creation
```

### 2. models.py - Database Schema
```python
# All database tables defined here:

User:
- id, username, email, password_hash
- credits (wallet balance)
- is_admin, is_active flags
- referral tracking
- telegram_id integration

Payment:
- id, user_id, amount, credits
- transaction_id, payment_method
- status tracking, admin approval
- UPI payment details

Search:
- id, user_id, search_type, query
- result storage, cost tracking
- timestamp, IP logging

Transaction:
- Credit/debit history
- Referral earnings
- Payment records

SystemSetting:
- Dynamic configuration storage
- Pricing, bonuses, API keys

AdminAction:
- Complete admin audit trail
- IP tracking, action logging

SystemLog:
- Security events
- API calls, errors
```

### 3. routes.py - User Routes
```python
Main routes:
/ - Landing page
/login - User authentication
/register - New user signup with referral
/dashboard - User home, balance display
/search - OSINT search interface
/search/<type> - Mobile/Aadhar/Vehicle search
/payment - UPI payment with QR generation
/profile - User settings
/logout - Session termination
```

### 4. admin_routes.py - Admin Panel
```python
Admin routes:
/admin - Dashboard with statistics
/admin/users - User management
/admin/payments - Payment approvals
/admin/pricing - Cost configuration
/admin/settings - System settings
/admin/logs - Security & system logs
/admin/api-config - API service management
/admin/security - Security settings
/admin/support-tickets - Support management
```

### 5. forms.py - Form Validation
```python
Forms with validation:
- LoginForm: Username/password
- RegisterForm: With referral code
- SearchForm: Mobile/Aadhar/Vehicle regex
- PaymentForm: Amount validation
- AdminUserForm: User management
- PaymentApprovalForm: Approve/reject
```

### 6. api_client.py - External API Integration
```python
Features:
- AES-256 encryption for API keys
- HMAC-SHA256 request signing
- Automatic retry logic
- Fallback demo data
- External API calls for:
  * Mobile number search
  * Aadhar verification
  * Vehicle information
```

### 7. security.py - Encryption System
```python
Security features:
- Master key generation
- API key encryption/decryption
- Password hashing (bcrypt)
- Secure key storage
- Environment variable management
```

### 8. security_interceptor.py - Anti-Interception
```python
Protection against:
- Burp Suite detection
- OWASP ZAP blocking
- Proxy tool prevention
- Request tampering
- Replay attacks
```

## Configuration Files

### config/api_config.json
```json
{
  "mobile_api": {
    "name": "Mobile Number Search",
    "base_url": "https://api-url.com",
    "endpoint": "/search",
    "method": "GET",
    "requires_key": false,
    "cost": 99.0,
    "active": true
  }
}
```

### Environment Variables
```
DATABASE_URL - PostgreSQL connection
SESSION_SECRET - Flask session key
MASTER_ENCRYPTION_KEY - API key encryption
TELEGRAM_BOT_TOKEN - Bot integration
ANTI_INTERCEPT_KEY - Security key
```

## Frontend Structure

### Templates Hierarchy
```
base.html
├── index.html (landing)
├── login.html
├── register.html
├── dashboard.html
├── search.html
├── payment.html
└── profile.html

admin_base.html
└── admin/*.html (all admin pages)
```

### CSS Architecture
```css
/* CSS Variables for theming */
--primary: #5469d4
--success: #10b981
--danger: #ef4444
--warning: #f59e0b

/* Stripe-inspired design system */
.card - Rounded white containers
.btn - Button styles
.form-control - Input styling
```

### JavaScript Features
```javascript
// Dark mode toggle
// Payment QR generation
// Form validation
// Admin dashboard charts
// Real-time notifications
```

## Database Setup

### PostgreSQL Schema
```sql
-- Users table with credits system
CREATE TABLE users (
    id SERIAL PRIMARY KEY,
    username VARCHAR(64) UNIQUE NOT NULL,
    email VARCHAR(120) UNIQUE NOT NULL,
    password_hash VARCHAR(256),
    credits FLOAT DEFAULT 0,
    is_admin BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT NOW()
);

-- Payments with UPI integration
CREATE TABLE payments (
    id SERIAL PRIMARY KEY,
    user_id INTEGER REFERENCES users(id),
    amount FLOAT NOT NULL,
    credits FLOAT NOT NULL,
    transaction_id VARCHAR(100),
    status VARCHAR(20) DEFAULT 'pending',
    upi_id VARCHAR(100)
);
```

## Security Implementation

### 1. Authentication Flow
```python
# Password hashing with bcrypt
# Session management
# Admin role checking
# CSRF protection
```

### 2. API Security
```python
# AES-256 encryption for keys
# HMAC-SHA256 request signing
# Timestamp validation
# Nonce for replay protection
```

### 3. Anti-Interception
```python
# User-agent analysis
# Proxy detection
# Request fingerprinting
# Rate limiting
```

## Payment System

### UPI Integration
```python
# QR code generation
# Exact amount formatting (₹100.00)
# Payment tracking
# Admin approval system
# Automatic credit addition
```

## Credit System

### Pricing Structure
- Mobile Search: ₹99
- Aadhar Verification: ₹149  
- Vehicle Search: ₹49.63

### Bonus System
- Signup Bonus: ₹500
- Referral Bonus: ₹50
- Referral Signup: ₹25

## API Services

### External APIs Used
1. Mobile Number API
   - Endpoint: /search?mobile={number}
   - Returns: Name, address, operator

2. Aadhar API (configurable)
   - Verification endpoint
   - Requires API key

3. Vehicle API (configurable)
   - Registration details
   - Owner information

## Admin Features

### User Management
- View all users
- Edit credits
- Ban/unban users
- Reset passwords

### Payment Management
- Approve/reject payments
- View transaction history
- Generate QR codes

### System Configuration
- Dynamic pricing
- API key management
- Security settings
- Bonus configuration

## Support System

### Telegram Bot Integration
- Ticket creation
- Balance checking
- Payment notifications
- Admin alerts

## Deployment Requirements

### Dependencies (pyproject.toml)
```toml
flask
flask-sqlalchemy
flask-wtf
werkzeug
cryptography
requests
psycopg2-binary
qrcode
gunicorn
```

### Server Setup
```bash
# Gunicorn configuration
gunicorn --bind 0.0.0.0:5000 main:app
```

## How to Recreate This Project

1. **Setup Flask App**
   - Copy app.py structure
   - Configure database connection
   - Set environment variables

2. **Create Database Models**
   - Copy models.py completely
   - Run db.create_all()

3. **Implement Routes**
   - Copy routes.py for user features
   - Copy admin_routes.py for admin panel
   - Copy support_routes.py for support

4. **Add Security**
   - Implement security.py encryption
   - Add security_interceptor.py
   - Configure CSRF protection

5. **Frontend Setup**
   - Copy all templates
   - Add CSS/JS files
   - Implement dark mode

6. **Payment Integration**
   - UPI QR generation
   - Payment approval flow
   - Credit management

7. **API Integration**
   - Configure api_config.json
   - Implement api_service.py
   - Add external API calls

8. **Admin Panel**
   - Copy admin templates
   - Implement admin routes
   - Add management features

9. **Deploy**
   - Set all environment variables
   - Configure PostgreSQL
   - Run with Gunicorn

## Testing Credentials

Default Admin:
- Username: mrmac
- Password: 953146563

UPI ID: 9053407823@mbk

## Important Security Notes

1. Always use HTTPS in production
2. Set strong MASTER_ENCRYPTION_KEY
3. Enable rate limiting
4. Monitor security logs
5. Regular security audits

## Support & Maintenance

- Check logs/ directory for errors
- Monitor SystemLog entries
- Review AdminAction audit trail
- Test API endpoints regularly
- Keep dependencies updated

---

This guide contains everything needed to recreate the MROSINT platform. Each component is explained with its purpose and implementation details.