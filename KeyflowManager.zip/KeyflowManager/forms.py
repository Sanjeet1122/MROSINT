from flask_wtf import FlaskForm
from wtforms import StringField, PasswordField, FloatField, SelectField, TextAreaField, IntegerField, BooleanField, HiddenField, SubmitField
from wtforms.validators import DataRequired, Email, Length, NumberRange, Regexp, ValidationError, Optional, URL
from models import User, SystemSetting
import re

class LoginForm(FlaskForm):
    username = StringField('Username', validators=[DataRequired(), Length(min=3, max=64)])
    password = PasswordField('Password', validators=[DataRequired()])

class RegisterForm(FlaskForm):
    username = StringField('Username', validators=[
        DataRequired(), 
        Length(min=3, max=64),
        Regexp('^[A-Za-z0-9_]+$', message='Username must contain only letters, numbers, and underscores')
    ])
    email = StringField('Email', validators=[DataRequired(), Email()])
    full_name = StringField('Full Name', validators=[DataRequired(), Length(min=2, max=100)])
    password = PasswordField('Password', validators=[DataRequired(), Length(min=6)])
    referral_code = StringField('Referral Code (Optional)', validators=[Optional()])
    
    def validate_username(self, username):
        user = User.query.filter_by(username=username.data).first()
        if user:
            raise ValidationError('Username already exists. Choose a different one.')
    
    def validate_email(self, email):
        user = User.query.filter_by(email=email.data).first()
        if user:
            raise ValidationError('Email already registered. Choose a different one.')

class SearchForm(FlaskForm):
    search_type = SelectField('Search Type', choices=[
        ('mobile', 'Mobile Number'),
        ('aadhar', 'Aadhar Number'),
        ('vehicle', 'Vehicle Number')
    ], validators=[DataRequired()])
    query = StringField('Search Query', validators=[DataRequired()])
    
    def validate_query(self, query):
        if self.search_type.data == 'mobile':
            if not re.match(r'^\d{10}$', query.data):
                raise ValidationError('Mobile number must be exactly 10 digits')
        elif self.search_type.data == 'aadhar':
            if not re.match(r'^\d{12}$', query.data):
                raise ValidationError('Aadhar number must be exactly 12 digits')
        elif self.search_type.data == 'vehicle':
            if not re.match(r'^[A-Z]{2}\d{2}[A-Z]{1,2}\d{4}$', query.data.upper()):
                raise ValidationError('Vehicle number format should be like UP14GF2831')

class PaymentForm(FlaskForm):
    amount = FloatField('Amount', validators=[
        DataRequired(), 
        NumberRange(min=100, max=10000, message='Amount must be between ₹100 and ₹10,000')
    ])

class AdminUserForm(FlaskForm):
    user_id = IntegerField('User ID', validators=[DataRequired()])
    credits = FloatField('Credits to Add/Remove', validators=[DataRequired()])
    action = SelectField('Action', choices=[
        ('add', 'Add Credits'),
        ('remove', 'Remove Credits'),
        ('activate', 'Activate User'),
        ('deactivate', 'Deactivate User')
    ], validators=[DataRequired()])
    reason = TextAreaField('Reason', validators=[DataRequired()])

class GiftCardRedeemForm(FlaskForm):
    code = StringField('Gift Card Code', validators=[
        DataRequired(),
        Length(min=16, max=20, message='Invalid gift card code format')
    ])
    submit = SubmitField('Redeem Gift Card')

class AdminEditUserForm(FlaskForm):
    username = StringField('Username', validators=[DataRequired(), Length(min=3, max=64)])
    email = StringField('Email', validators=[DataRequired(), Email()])
    full_name = StringField('Full Name', validators=[DataRequired(), Length(min=2, max=100)])
    credits = FloatField('Credits', validators=[DataRequired(), NumberRange(min=0)])
    is_active = BooleanField('Active')
    is_admin = BooleanField('Admin')
    new_password = PasswordField('New Password (Optional)', validators=[Optional(), Length(min=6)])
    confirm_password = PasswordField('Confirm Password', validators=[Optional()])
    reason = TextAreaField('Reason for Changes', validators=[DataRequired()])
    
    def __init__(self, user_id=None, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.user_id = user_id
    
    def validate_username(self, username):
        user = User.query.filter_by(username=username.data).first()
        if user and (not self.user_id or user.id != self.user_id):
            raise ValidationError('Username already exists. Choose a different one.')
    
    def validate_email(self, email):
        user = User.query.filter_by(email=email.data).first()
        if user and (not self.user_id or user.id != self.user_id):
            raise ValidationError('Email already registered. Choose a different one.')
    
    def validate_confirm_password(self, confirm_password):
        if self.new_password.data and self.new_password.data != confirm_password.data:
            raise ValidationError('Password confirmation does not match.')

class APIKeyForm(FlaskForm):
    name = StringField('API Key Name', validators=[DataRequired(), Length(min=3, max=100)])
    service = SelectField('Service Type', choices=[
        ('mobile_api', 'Mobile Search API'),
        ('aadhar_api', 'Aadhar Search API'),
        ('vehicle_api', 'Vehicle Search API')
    ], validators=[DataRequired()])
    key_value = StringField('API Key', validators=[DataRequired(), Length(min=10)])
    endpoint_url = StringField('Endpoint URL', validators=[Optional(), URL()])

class SystemSettingForm(FlaskForm):
    key = StringField('Setting Key', validators=[DataRequired(), Length(min=3, max=100)])
    value = TextAreaField('Value', validators=[DataRequired()])
    data_type = SelectField('Data Type', choices=[
        ('string', 'String'),
        ('int', 'Integer'),
        ('float', 'Float'),
        ('bool', 'Boolean'),
        ('json', 'JSON')
    ], validators=[DataRequired()])
    description = StringField('Description', validators=[Optional(), Length(max=500)])
    category = SelectField('Category', choices=[
        ('general', 'General'),
        ('pricing', 'Pricing'),
        ('payment', 'Payment'),
        ('api', 'API'),
        ('telegram', 'Telegram'),
        ('referral', 'Referral')
    ], validators=[DataRequired()])

class PaymentApprovalForm(FlaskForm):
    payment_id = HiddenField('Payment ID', validators=[DataRequired()])
    action = SelectField('Action', choices=[
        ('approve', 'Approve Payment'),
        ('reject', 'Reject Payment')
    ], validators=[DataRequired()])
    admin_notes = TextAreaField('Admin Notes', validators=[Optional()])

class VehicleSearchForm(FlaskForm):
    vehicle_number = StringField('Vehicle Number', validators=[
        DataRequired(),
        Regexp(r'^[A-Z]{2}\d{2}[A-Z]{1,2}\d{4}$', message='Invalid vehicle number format (e.g., UP14GF2831)')
    ])

class PricingForm(FlaskForm):
    mobile_cost = FloatField('Mobile Search Cost (₹)', validators=[
        DataRequired(),
        NumberRange(min=0.01, max=1000, message='Cost must be between ₹0.01 and ₹1000')
    ])
    aadhar_cost = FloatField('Aadhar Search Cost (₹)', validators=[
        DataRequired(),
        NumberRange(min=0.01, max=1000, message='Cost must be between ₹0.01 and ₹1000')
    ])
    vehicle_cost = FloatField('Vehicle Search Cost (₹)', validators=[
        DataRequired(),
        NumberRange(min=0.01, max=1000, message='Cost must be between ₹0.01 and ₹1000')
    ])

class ProfileForm(FlaskForm):
    full_name = StringField('Full Name', validators=[DataRequired(), Length(min=2, max=100)])
    username = StringField('Username', validators=[DataRequired(), Length(min=3, max=64)])
    email = StringField('Email', validators=[DataRequired(), Email()])
    mobile = StringField('Mobile Number', validators=[
        Optional(),
        Regexp(r'^\d{10}$', message='Mobile number must be exactly 10 digits')
    ])

class PaymentSettingsForm(FlaskForm):
    upi_id = StringField('UPI ID', validators=[
        DataRequired(),
        Regexp(r'^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+$', message='Invalid UPI ID format (e.g., 9876543210@paytm)')
    ])

class ChangePasswordForm(FlaskForm):
    current_password = PasswordField('Current Password', validators=[DataRequired()])
    new_password = PasswordField('New Password', validators=[DataRequired(), Length(min=6)])
    confirm_password = PasswordField('Confirm New Password', validators=[DataRequired()])

class UPISettingsForm(FlaskForm):
    upi_id = StringField('UPI ID', validators=[
        DataRequired(),
        Regexp(r'^[a-zA-Z0-9.\-_]{2,256}@[a-zA-Z]{2,64}$', message='Invalid UPI ID format')
    ])
    min_amount = FloatField('Minimum Amount (₹)', validators=[
        DataRequired(),
        NumberRange(min=1, max=10000, message='Amount must be between ₹1 and ₹10,000')
    ])
    max_amount = FloatField('Maximum Amount (₹)', validators=[
        DataRequired(),
        NumberRange(min=100, max=100000, message='Amount must be between ₹100 and ₹1,00,000')
    ])
    auto_approve = BooleanField('Auto Approve Payments')

class SupportTicketForm(FlaskForm):
    subject = StringField('Subject', validators=[
        DataRequired(message='Subject is required'),
        Length(min=5, max=200, message='Subject must be between 5 and 200 characters')
    ])
    category = SelectField('Category', validators=[DataRequired()], choices=[
        ('billing', 'Billing & Payments'),
        ('technical', 'Technical Issue'),
        ('account', 'Account Related'),
        ('referral', 'Referral Program'),
        ('other', 'Other')
    ])
    priority = SelectField('Priority', validators=[DataRequired()], choices=[
        ('low', 'Low'),
        ('medium', 'Medium'),
        ('high', 'High')
    ])
    description = TextAreaField('Description', validators=[
        DataRequired(message='Please describe your issue'),
        Length(min=20, message='Please provide more details (minimum 20 characters)')
    ])

class SupportReplyForm(FlaskForm):
    message = TextAreaField('Message', validators=[
        DataRequired(message='Message cannot be empty'),
        Length(min=1, message='Message cannot be empty')
    ])

class BonusSettingsForm(FlaskForm):
    signup_bonus = FloatField('Signup Bonus (₹)', validators=[
        DataRequired(),
        NumberRange(min=0, max=10000, message='Signup bonus must be between ₹0 and ₹10,000')
    ])
    referral_bonus = FloatField('Referral Bonus (₹)', validators=[
        DataRequired(),
        NumberRange(min=0, max=5000, message='Referral bonus must be between ₹0 and ₹5,000')
    ])
    referral_signup_bonus = FloatField('Referral Signup Bonus (₹)', validators=[
        DataRequired(),
        NumberRange(min=0, max=5000, message='Referral signup bonus must be between ₹0 and ₹5,000')
    ])
