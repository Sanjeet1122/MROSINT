#!/usr/bin/env python3
"""
MROSINT Telegram Bot Webhook Integration
Integrates the Telegram bot with Flask application
"""

import os
import logging
from flask import request, jsonify
from telegram import Update
from telegram.ext import Application
import asyncio
from concurrent.futures import ThreadPoolExecutor
import json

# Import main app and bot
import sys
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from app import app
from telegram_bot.bot import MROSINTBot

# Setup logging
logging.basicConfig(
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    level=logging.INFO
)
logger = logging.getLogger(__name__)

# Initialize bot application
BOT_TOKEN = os.environ.get('TELEGRAM_BOT_TOKEN', '7577806882:AAHPzM8GY8bSpAqp2hd75hw6cgV5f6jf0zM')
WEBHOOK_URL = os.environ.get('WEBHOOK_URL', 'https://mrosint.com/telegram-webhook')

# Create async event loop for bot
loop = asyncio.new_event_loop()
asyncio.set_event_loop(loop)

# Initialize bot
bot_instance = MROSINTBot()
application = bot_instance.application

# Thread pool for async operations
executor = ThreadPoolExecutor(max_workers=4)

def setup_webhook():
    """Set up webhook for Telegram bot"""
    try:
        # Initialize application
        loop.run_until_complete(application.initialize())
        
        # Set webhook
        loop.run_until_complete(
            application.bot.set_webhook(
                url=WEBHOOK_URL,
                allowed_updates=Update.ALL_TYPES
            )
        )
        logger.info(f"Webhook set to: {WEBHOOK_URL}")
        return True
    except Exception as e:
        logger.error(f"Failed to set webhook: {e}")
        return False

def register_telegram_routes(app):
    """Register Telegram webhook routes"""
    
    @app.route('/telegram-webhook', methods=['POST'])
    def telegram_webhook():
        """Handle incoming Telegram updates"""
        try:
            # Parse update
            update_data = request.get_json()
            logger.info(f"Received update: {update_data.get('update_id')}")
            
            # Create Update object
            update = Update.de_json(update_data, application.bot)
            
            # Process update asynchronously
            future = executor.submit(
                asyncio.run,
                application.process_update(update)
            )
            
            # Don't wait for processing to complete
            return jsonify({"ok": True}), 200
            
        except Exception as e:
            logger.error(f"Error processing update: {e}")
            return jsonify({"ok": False, "error": str(e)}), 500

    @app.route('/telegram-webhook/info', methods=['GET'])
    def webhook_info():
        """Get webhook information"""
        try:
            # Get webhook info
            webhook_info = loop.run_until_complete(
                application.bot.get_webhook_info()
            )
            
            return jsonify({
                "url": webhook_info.url,
                "has_custom_certificate": webhook_info.has_custom_certificate,
                "pending_update_count": webhook_info.pending_update_count,
                "last_error_date": webhook_info.last_error_date,
                "last_error_message": webhook_info.last_error_message,
                "max_connections": webhook_info.max_connections,
                "allowed_updates": webhook_info.allowed_updates
            })
        except Exception as e:
            return jsonify({"error": str(e)}), 500

    @app.route('/telegram-webhook/set', methods=['POST'])
    def set_webhook():
        """Manually set webhook (admin only)"""
        # Add admin authentication here
        if setup_webhook():
            return jsonify({"ok": True, "message": "Webhook set successfully"})
        else:
            return jsonify({"ok": False, "message": "Failed to set webhook"}), 500

    @app.route('/telegram-webhook/delete', methods=['POST'])
    def delete_webhook():
        """Delete webhook (admin only)"""
        # Add admin authentication here
        try:
            loop.run_until_complete(application.bot.delete_webhook())
            return jsonify({"ok": True, "message": "Webhook deleted"})
        except Exception as e:
            return jsonify({"ok": False, "error": str(e)}), 500

    @app.route('/telegram-bot/send-message', methods=['POST'])
    def send_telegram_message():
        """Send message to Telegram user (internal use)"""
        try:
            data = request.get_json()
            chat_id = data.get('chat_id')
            text = data.get('text')
            parse_mode = data.get('parse_mode', 'Markdown')
            
            if not chat_id or not text:
                return jsonify({"error": "chat_id and text required"}), 400
            
            # Send message
            message = loop.run_until_complete(
                application.bot.send_message(
                    chat_id=chat_id,
                    text=text,
                    parse_mode=parse_mode
                )
            )
            
            return jsonify({
                "ok": True,
                "message_id": message.message_id
            })
        except Exception as e:
            return jsonify({"error": str(e)}), 500
    
    # Return the registered functions
    return {
        'telegram_webhook': telegram_webhook,
        'webhook_info': webhook_info,
        'set_webhook': set_webhook,
        'delete_webhook': delete_webhook,
        'send_telegram_message': send_telegram_message
    }

# Notification functions for internal use
def notify_user_payment_approved(user_id, amount):
    """Notify user when payment is approved"""
    try:
        from models import User
        user = User.query.get(user_id)
        if user and user.telegram_id:
            text = f"""
✅ *Payment Approved!*

Your payment of ₹{amount:.2f} has been approved.
Credits have been added to your account.

Check your balance: /balance
"""
            loop.run_until_complete(
                application.bot.send_message(
                    chat_id=user.telegram_id,
                    text=text,
                    parse_mode='Markdown'
                )
            )
    except Exception as e:
        logger.error(f"Failed to notify user {user_id}: {e}")

def notify_admin_new_payment(payment_id, user_name, amount):
    """Notify admin about new payment"""
    try:
        ADMIN_ID = 7597633895
        text = f"""
💰 *New Payment Alert*

User: {user_name}
Amount: ₹{amount:.2f}
Payment ID: #{payment_id}

Please check admin panel to approve.
"""
        loop.run_until_complete(
            application.bot.send_message(
                chat_id=ADMIN_ID,
                text=text,
                parse_mode='Markdown'
            )
        )
    except Exception as e:
        logger.error(f"Failed to notify admin: {e}")

def notify_user_search_complete(user_id, search_type, query):
    """Notify user when background search completes"""
    try:
        from models import User
        user = User.query.get(user_id)
        if user and user.telegram_id:
            text = f"""
✅ *Search Complete*

Your {search_type} search for "{query}" is complete.
View results: /history
"""
            loop.run_until_complete(
                application.bot.send_message(
                    chat_id=user.telegram_id,
                    text=text,
                    parse_mode='Markdown'
                )
            )
    except Exception as e:
        logger.error(f"Failed to notify user {user_id}: {e}")

# Initialize webhook on module import
try:
    if os.environ.get('REPLIT_DEV_DOMAIN'):
        setup_webhook()
except Exception as e:
    logger.error(f"Failed to setup webhook on import: {e}")

# Cleanup on app shutdown
def cleanup_telegram_bot():
    """Cleanup bot resources"""
    try:
        loop.run_until_complete(application.shutdown())
        executor.shutdown(wait=True)
        loop.close()
    except Exception as e:
        logger.error(f"Error during cleanup: {e}")

# Register cleanup
import atexit
atexit.register(cleanup_telegram_bot)

# Register routes when imported
try:
    register_telegram_routes(app)
except AssertionError:
    # Routes already registered
    pass

if __name__ == '__main__':
    # For testing webhook setup
    if setup_webhook():
        print("Webhook setup successful!")
        print(f"Webhook URL: {WEBHOOK_URL}")
    else:
        print("Webhook setup failed!")