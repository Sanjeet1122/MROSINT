from flask import render_template, request, redirect, url_for, flash, session, jsonify, abort
from functools import wraps
from app import app, db
from models import User, Search, Transaction, Payment, AdminAction, SystemSetting, SystemLog, ProtectedNumber
from forms import LoginForm, RegisterForm, SearchForm, PaymentForm, AdminUserForm, ProfileForm, PaymentSettingsForm, ChangePasswordForm
from api_client import api_client
try:
    from services.api_service import api_service
except ImportError:
    api_service = None
from datetime import datetime
import json
import uuid
import os

def log_search_query_detailed(query, search_type, user_id, ip_address, success):
    """Enhanced search logging system inspired by reference"""
    try:
        # Create logs directory if it doesn't exist
        if not os.path.exists('logs'):
            os.makedirs('logs')
        
        # Load existing queries
        queries_file = 'logs/queries.json'
        if os.path.exists(queries_file):
            with open(queries_file, 'r') as f:
                queries = json.load(f)
        else:
            queries = []
        
        # Add new query log
        query_data = {
            'query': query,
            'search_type': search_type,
            'user_id': user_id,
            'ip_address': ip_address,
            'timestamp': datetime.utcnow().isoformat(),
            'user_agent': request.headers.get('User-Agent', ''),
            'success': success
        }
        
        queries.append(query_data)
        
        # Keep only last 1000 queries to prevent file bloat
        queries = queries[-1000:]
        
        # Save updated queries
        with open(queries_file, 'w') as f:
            json.dump(queries, f, indent=2)
            
    except Exception as e:
        print(f"Enhanced logging error: {e}")

# Dynamic pricing configuration from system settings
def get_pricing():
    return {
        'mobile': SystemSetting.get_value('search.mobile_cost', 99.0),
        'aadhar': SystemSetting.get_value('search.aadhar_cost', 149.0),
        'vehicle': SystemSetting.get_value('search.vehicle_cost', 49.63)
    }

@app.route('/')
def index():
    if 'user_id' in session:
        return redirect(url_for('dashboard'))
    return render_template('index.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    form = LoginForm()
    if form.validate_on_submit():
        user = User.query.filter_by(username=form.username.data).first()
        if user and user.check_password(form.password.data) and user.is_active:
            session['user_id'] = user.id
            session['username'] = user.username
            session['is_admin'] = user.is_admin
            
            # Update last login
            user.last_login = datetime.utcnow()
            db.session.commit()
            
            # Log successful login
            SystemLog.log('INFO', 'auth', f'User logged in: {user.username}', 
                         user.id, request.remote_addr, request.headers.get('User-Agent'))
            
            flash('Logged in successfully!', 'success')
            
            # Redirect admin users to admin dashboard
            if user.is_admin:
                return redirect(url_for('admin_dashboard'))
            return redirect(url_for('dashboard'))
        else:
            # Log failed login attempt
            SystemLog.log('WARNING', 'auth', f'Failed login attempt for username: {form.username.data}', 
                         None, request.remote_addr, request.headers.get('User-Agent'))
            flash('Invalid username or password', 'error')
    return render_template('login.html', form=form)

@app.route('/register', methods=['GET', 'POST'])
def register():
    # Check if registration is enabled
    registration_enabled = SystemSetting.get_value('system.registration_enabled', True)
    if not registration_enabled:
        flash('Registration is currently disabled. Please contact administrator.', 'error')
        return redirect(url_for('login'))
    
    form = RegisterForm()
    if form.validate_on_submit():
        welcome_credits = SystemSetting.get_value('referral.signup_bonus', 500.0)
        referrer = None
        
        # Check referral code if provided
        if form.referral_code.data:
            referrer = User.query.filter_by(referral_code=form.referral_code.data.strip().upper()).first()
            if not referrer:
                flash('Invalid referral code. Registration will continue without referral bonus.', 'warning')
        
        user = User(
            username=form.username.data,
            email=form.email.data,
            full_name=form.full_name.data,
            credits=welcome_credits,
            referred_by_id=referrer.id if referrer else None
        )
        user.set_password(form.password.data)
        
        # Generate referral code for new user
        user.generate_referral_code()
        
        db.session.add(user)
        db.session.flush()  # Get user ID
        
        # Add welcome transaction
        transaction = Transaction(
            user=user,
            transaction_type='credit',
            amount=welcome_credits,
            description='Welcome bonus'
        )
        db.session.add(transaction)
        
        # Process referral bonus if valid referrer
        if referrer:
            referral_bonus = SystemSetting.get_value('referral.referral_bonus', 50.0)
            referral_signup_bonus = SystemSetting.get_value('referral.referral_signup_bonus', 25.0)
            
            # Add bonus to referrer
            referrer.credits += referral_bonus
            referrer.total_referrals += 1
            referrer.referral_earnings += referral_bonus
            
            # Add extra signup bonus to new user for using referral
            user.credits += referral_signup_bonus
            
            # Create referral bonus transaction for referrer
            referral_transaction = Transaction(
                user=referrer,
                transaction_type='credit',
                amount=referral_bonus,
                description=f'Referral bonus for {user.username}'
            )
            db.session.add(referral_transaction)
            
            # Create referral signup bonus transaction for new user
            referral_signup_transaction = Transaction(
                user=user,
                transaction_type='credit',
                amount=referral_signup_bonus,
                description='Referral signup bonus'
            )
            db.session.add(referral_signup_transaction)
            
            # Log referral
            SystemLog.log('INFO', 'referral', f'Referral bonus awarded: {referrer.username} -> {user.username} (Referrer: ₹{referral_bonus}, New User: ₹{referral_signup_bonus})', 
                         referrer.id, request.remote_addr)
            
            # Check for referral fraud (after referral is processed)
            from models import ReferralFraudLog
            try:
                ReferralFraudLog.check_and_log_user(referrer.id)
            except Exception as e:
                SystemLog.log('WARNING', 'referral_fraud', f'Failed to check referral fraud for user {referrer.id}: {e}')
        
        db.session.commit()
        
        # Log new user registration
        SystemLog.log('INFO', 'auth', f'New user registered: {user.username}' + (' (via referral)' if referrer else ''), 
                     user.id, request.remote_addr, request.headers.get('User-Agent'))
        
        success_message = f'Registration successful! You received ₹{welcome_credits} welcome bonus.'
        if referrer:
            total_bonus = welcome_credits + referral_signup_bonus
            success_message = f'Registration successful! You received ₹{total_bonus} total bonus (₹{welcome_credits} welcome + ₹{referral_signup_bonus} referral)!'
        
        flash(success_message, 'success')
        return redirect(url_for('login'))
    return render_template('register.html', form=form)

@app.route('/logout')
def logout():
    session.clear()
    flash('Logged out successfully!', 'info')
    return redirect(url_for('index'))

@app.route('/dashboard')
def dashboard():
    if 'user_id' not in session:
        return redirect(url_for('login'))
    
    user = User.query.get(session['user_id'])
    if not user or not user.is_active:
        session.clear()
        flash('Account deactivated', 'error')
        return redirect(url_for('login'))
    
    stats = user.get_search_stats()
    recent_searches = Search.query.filter_by(user_id=user.id).order_by(Search.created_at.desc()).limit(5).all()
    
    return render_template('dashboard.html', user=user, stats=stats, recent_searches=recent_searches, pricing=get_pricing())

@app.route('/search', methods=['GET', 'POST'])
def search():
    if 'user_id' not in session:
        return redirect(url_for('login'))
    
    user = User.query.get(session['user_id'])
    form = SearchForm()
    
    if form.validate_on_submit():
        search_type = form.search_type.data
        query = form.query.data.upper() if search_type == 'vehicle' else form.query.data
        cost = get_pricing()[search_type]
        
        # Check if user has enough credits
        if user.credits < cost:
            flash(f'Insufficient credits. You need ₹{cost} but have ₹{user.credits:.2f}', 'error')
            return redirect(url_for('credits'))
        
        # Perform secure search based on type
        if search_type == 'mobile':
            result = api_client.search_mobile(query, user.id, request.remote_addr)
        elif search_type == 'aadhar':
            result = api_client.search_aadhar(query, user.id, request.remote_addr)
        else:  # vehicle
            result = api_client.search_vehicle(query, user.id, request.remote_addr)
        
        # Deduct credits
        user.credits -= cost
        
        # Record transaction
        transaction = Transaction(
            user_id=user.id,
            transaction_type='debit',
            amount=cost,
            description=f'{search_type.title()} search: {query}'
        )
        db.session.add(transaction)
        
        # Record search
        search_record = Search(
            user_id=user.id,
            query_type=search_type,
            query_value=query,
            result_data=json.dumps(result),
            credits_used=cost,
            status='completed' if result.get('success') else 'failed',
            ip_address=request.remote_addr,
            user_agent=request.headers.get('User-Agent')
        )
        db.session.add(search_record)
        db.session.commit()
        
        # Enhanced logging system
        log_search_query_detailed(query, search_type, user.id, request.remote_addr, result.get('success', False))
        
        return render_template('search_results.html', 
                             result=result, 
                             search_type=search_type, 
                             query=query, 
                             cost=cost)
    
    return render_template('search.html', form=form, user=user, pricing=get_pricing())

@app.route('/history')
def history():
    if 'user_id' not in session:
        return redirect(url_for('login'))
    
    user = User.query.get(session['user_id'])
    page = request.args.get('page', 1, type=int)
    searches = Search.query.filter_by(user_id=user.id).order_by(Search.created_at.desc()).paginate(
        page=page, per_page=20, error_out=False
    )
    
    return render_template('history.html', searches=searches, user=user)

@app.route('/referrals')
def referrals():
    if 'user_id' not in session:
        return redirect(url_for('login'))
    
    user = User.query.get(session['user_id'])
    referral_stats = user.get_referral_stats()
    
    return render_template('referrals.html', user=user, referral_stats=referral_stats)

@app.route('/protect-number', methods=['GET', 'POST'])
def protect_number():
    if 'user_id' not in session:
        return redirect(url_for('login'))
    
    user = User.query.get(session['user_id'])
    
    if request.method == 'POST':
        phone_number = request.form.get('phone_number', '').strip()
        
        # Validate phone number
        import re
        if not re.match(r'^[6-9]\d{9}$', phone_number):
            flash('Invalid phone number format!', 'error')
            return redirect(url_for('protect_number'))
        
        # Check if already protected
        existing = ProtectedNumber.query.filter_by(phone_number=phone_number).first()
        if existing and existing.is_active:
            flash('This number is already protected!', 'warning')
            return redirect(url_for('protect_number'))
        
        # Check if user has enough credits
        protection_fee = 500.0
        if user.credits < protection_fee:
            flash(f'Insufficient credits. You need ₹{protection_fee} but have ₹{user.credits:.2f}', 'error')
            return redirect(url_for('credits'))
        
        # Deduct credits
        user.credits -= protection_fee
        
        # Create or update protection
        if existing:
            existing.is_active = True
            existing.user_id = user.id
            existing.created_at = datetime.utcnow()
        else:
            protection = ProtectedNumber(
                phone_number=phone_number,
                user_id=user.id,
                protection_fee=protection_fee,
                reason='User protection request'
            )
            db.session.add(protection)
        
        # Record transaction
        transaction = Transaction(
            user_id=user.id,
            transaction_type='debit',
            amount=protection_fee,
            description=f'Number protection: {phone_number}'
        )
        db.session.add(transaction)
        
        # Log the protection
        SystemLog.log('INFO', 'protection', f'User {user.username} protected number {phone_number}', 
                     user.id, request.remote_addr)
        
        db.session.commit()
        
        flash(f'✅ Number {phone_number} is now protected! Your details are safe and secure.', 'success')
        return redirect(url_for('protect_number'))
    
    # Get user's protected numbers
    protected_numbers = ProtectedNumber.query.filter_by(
        user_id=user.id,
        is_active=True
    ).order_by(ProtectedNumber.created_at.desc()).all()
    
    return render_template('protect_number.html', user=user, protected_numbers=protected_numbers)

@app.route('/menu-demo')
def menu_demo():
    return render_template('menu_demo.html')

@app.route('/credits', methods=['GET', 'POST'])
def credits():
    if 'user_id' not in session:
        return redirect(url_for('login'))
    
    user = User.query.get(session['user_id'])
    form = PaymentForm()
    
    if form.validate_on_submit():
        amount = form.amount.data
        credits_to_add = amount  # 1 Rupee = 1 Credit
        
        # Create payment record (UPI only)
        payment = Payment(
            user_id=user.id,
            amount=amount,
            credits=credits_to_add,
            payment_method='upi',
            transaction_id=str(uuid.uuid4()),
            status='pending'
        )
        
        # Generate QR code data for UPI payment
        from utils import generate_upi_string
        upi_id = SystemSetting.get_value('payment.upi_id', 'knoxusdt@paytm')
        payment.qr_code_data = generate_upi_string(
            upi_id=upi_id,
            amount=amount,
            payee_name="MROSINT",
            transaction_note=f"Credit Purchase - {payment.transaction_id}",
            transaction_id=payment.transaction_id
        )
        
        db.session.add(payment)
        db.session.commit()
        
        return redirect(url_for('payment', payment_id=payment.id))
    
    # Get recent transactions
    transactions = Transaction.query.filter_by(user_id=user.id).order_by(Transaction.created_at.desc()).limit(10).all()
    
    return render_template('credits.html', form=form, user=user, transactions=transactions)

@app.route('/payment/<int:payment_id>')
def payment(payment_id):
    if 'user_id' not in session:
        return redirect(url_for('login'))
    
    payment = Payment.query.get_or_404(payment_id)
    if payment.user_id != session['user_id']:
        flash('Access denied', 'error')
        return redirect(url_for('dashboard'))
    
    # Generate QR code for the payment
    from utils import generate_qr_code, generate_upi_string
    
    # Get UPI ID from settings
    upi_id = SystemSetting.get_value('payment.upi_id', '9053407823@mbk')
    
    # Generate UPI string
    upi_string = generate_upi_string(
        upi_id=upi_id,
        amount=payment.amount,
        payee_name="MROSINT",
        transaction_note=f"MROSINT-{payment.transaction_id[:8]}"
    )
    
    # Generate QR code
    qr_code_image = generate_qr_code(upi_string)
    
    return render_template('payment.html', payment=payment, qr_code_image=qr_code_image, upi_id=upi_id)

@app.route('/complete_payment/<int:payment_id>')
def complete_payment(payment_id):
    """Simulate payment completion - in production this would be handled by payment gateway webhook"""
    if 'user_id' not in session:
        return redirect(url_for('login'))
    
    payment = Payment.query.get_or_404(payment_id)
    if payment.user_id != session['user_id']:
        flash('Access denied', 'error')
        return redirect(url_for('dashboard'))
    
    if payment.status == 'pending':
        auto_approve = SystemSetting.get_value('payment.auto_approve', False)
        
        if auto_approve:
            # Auto approve payment
            payment.status = 'completed'
            payment.completed_at = datetime.utcnow()
            payment.admin_approved = True
            payment.admin_approved_by = 1  # System auto-approval
            
            # Add credits to user
            user = User.query.get(payment.user_id)
            user.credits += payment.credits
            
            # Record transaction
            transaction = Transaction(
                user_id=user.id,
                transaction_type='credit',
                amount=payment.credits,
                description=f'Payment auto-approved - {payment.payment_method}',
                reference_id=payment.transaction_id
            )
            db.session.add(transaction)
            db.session.commit()
            
            flash('Payment completed successfully! Credits have been added to your account.', 'success')
        else:
            # Mark payment as pending admin approval
            payment.status = 'pending'
            payment.completed_at = datetime.utcnow()
            db.session.commit()
            
            # Send notification to admin
            from models import SystemLog
            log = SystemLog(
                level='INFO',
                category='payment',
                message=f'New payment pending approval: ₹{payment.amount} from {payment.user.username}',
                user_id=payment.user_id,
                admin_id=None,
                ip_address=request.remote_addr,
                details=json.dumps({
                    'payment_id': payment.id,
                    'amount': float(payment.amount),
                    'transaction_id': payment.transaction_id,
                    'username': payment.user.username
                })
            )
            db.session.add(log)
            db.session.commit()
            
            flash('Payment completed successfully! Awaiting admin approval to activate credits.', 'success')
    
    # Redirect to payment success page instead of dashboard
    return redirect(url_for('payment_success', payment_id=payment.id))

@app.route('/payment/success/<int:payment_id>')
def payment_success(payment_id):
    """Payment success page with auto-redirect"""
    if 'user_id' not in session:
        return redirect(url_for('login'))
    
    payment = Payment.query.filter_by(id=payment_id, user_id=session['user_id']).first()
    if not payment:
        abort(404)
    return render_template('payment_success.html', payment=payment)

@app.route('/api/security-incident', methods=['POST'])
def security_incident():
    """Handle security incident reports from client-side detection"""
    try:
        data = request.get_json()
        if not data:
            return jsonify({'error': 'No data provided'}), 400
        
        # Log security incident
        SystemLog.log('WARNING', 'security', 
                     f'Client-side security incident: {data.get("reason", "Unknown")}',
                     user_id=session.get('user_id'),
                     ip_address=request.remote_addr,
                     user_agent=request.headers.get('User-Agent'),
                     extra_data={
                         'client_fingerprint': data.get('fingerprint'),
                         'incident_url': data.get('url'),
                         'client_timestamp': data.get('timestamp')
                     })
        
        return jsonify({'status': 'logged'}), 200
        
    except Exception as e:
        logger.error(f"Error handling security incident: {e}")
        return jsonify({'error': 'Internal error'}), 500

@app.route('/security-warning')
def security_warning():
    """Display security warning page for detected threats"""
    return render_template('security_warning.html'), 403

@app.route('/profile')
def profile():
    """User profile page"""
    if 'user_id' not in session:
        return redirect(url_for('login'))
    
    user = User.query.get(session['user_id'])
    if not user:
        return redirect(url_for('logout'))
    
    # Get user statistics
    user_stats = {
        'total_searches': Search.query.filter_by(user_id=user.id).count(),
        'total_spent': db.session.query(func.sum(Transaction.amount)).filter(
            Transaction.user_id == user.id,
            Transaction.transaction_type == 'debit'
        ).scalar() or 0.0,
        'referrals_count': user.total_referrals,
        'referral_earnings': user.referral_earnings
    }
    
    # Initialize forms
    form = ProfileForm(obj=user)
    payment_form = PaymentSettingsForm(obj=user)
    password_form = ChangePasswordForm()
    
    return render_template('profile.html', 
                         user=user, 
                         form=form, 
                         payment_form=payment_form, 
                         password_form=password_form,
                         user_stats=user_stats)

@app.route('/account-settings', methods=['GET', 'POST'])
def account_settings():
    if 'user_id' not in session:
        return redirect(url_for('login'))
    
    user = User.query.get(session['user_id'])
    
    if request.method == 'POST':
        # Update notification preferences
        user.email_notifications = 'email_notifications' in request.form
        user.sms_notifications = 'sms_notifications' in request.form
        
        # Update privacy settings
        user.profile_public = 'profile_public' in request.form
        
        db.session.commit()
        flash('Settings updated successfully!', 'success')
        return redirect(url_for('account_settings'))
    
    return render_template('account_settings.html', user=user)

@app.route('/change-password', methods=['GET', 'POST'])
def change_password():
    if 'user_id' not in session:
        return redirect(url_for('login'))
    
    user = User.query.get(session['user_id'])
    
    if request.method == 'POST':
        current_password = request.form.get('current_password')
        new_password = request.form.get('new_password')
        confirm_password = request.form.get('confirm_password')
        
        # Verify current password
        if not user.check_password(current_password):
            flash('Current password is incorrect!', 'error')
            return redirect(url_for('change_password'))
        
        # Validate new password
        if len(new_password) < 6:
            flash('New password must be at least 6 characters long!', 'error')
            return redirect(url_for('change_password'))
        
        if new_password != confirm_password:
            flash('New passwords do not match!', 'error')
            return redirect(url_for('change_password'))
        
        # Update password
        user.set_password(new_password)
        db.session.commit()
        
        # Log the password change
        SystemLog.log('INFO', 'account', f'Password changed for user {user.username}', 
                     user.id, request.remote_addr)
        
        flash('Password changed successfully!', 'success')
        return redirect(url_for('profile'))
    
    return render_template('change_password.html', user=user)

@app.route('/delete-account', methods=['GET', 'POST'])
def delete_account():
    if 'user_id' not in session:
        return redirect(url_for('login'))
    
    user = User.query.get(session['user_id'])
    
    if request.method == 'POST':
        password = request.form.get('password')
        confirmation = request.form.get('confirmation')
        
        # Verify password
        if not user.check_password(password):
            flash('Password is incorrect!', 'error')
            return redirect(url_for('delete_account'))
        
        # Verify confirmation
        if confirmation != 'DELETE':
            flash('Please type DELETE to confirm account deletion!', 'error')
            return redirect(url_for('delete_account'))
        
        # Log the account deletion
        SystemLog.log('WARNING', 'account', f'Account deleted by user {user.username}', 
                     user.id, request.remote_addr)
        
        # Soft delete - deactivate account
        user.is_active = False
        user.username = f"deleted_{user.id}_{user.username}"
        user.email = f"deleted_{user.id}_{user.email}"
        
        db.session.commit()
        
        # Clear session
        session.clear()
        
        flash('Your account has been deleted successfully.', 'info')
        return redirect(url_for('index'))
    
    return render_template('delete_account.html', user=user)

@app.route('/profile/update', methods=['POST'])
def update_profile():
    """Update user profile information"""
    if 'user_id' not in session:
        return redirect(url_for('login'))
    
    user = User.query.get(session['user_id'])
    if not user:
        return redirect(url_for('logout'))
    
    form = ProfileForm()
    if form.validate_on_submit():
        user.full_name = form.full_name.data
        user.email = form.email.data
        user.mobile = form.mobile.data
        user.last_active = datetime.utcnow()
        
        db.session.commit()
        flash('Profile updated successfully!', 'success')
    else:
        for field, errors in form.errors.items():
            for error in errors:
                flash(f'{field}: {error}', 'error')
    
    return redirect(url_for('profile'))

@app.route('/profile/payment-settings', methods=['POST'])
def update_payment_settings():
    """Update user payment settings"""
    if 'user_id' not in session:
        return redirect(url_for('login'))
    
    user = User.query.get(session['user_id'])
    if not user:
        return redirect(url_for('logout'))
    
    form = PaymentSettingsForm()
    if form.validate_on_submit():
        user.upi_id = form.upi_id.data
        user.last_active = datetime.utcnow()
        
        db.session.commit()
        flash('Payment settings updated successfully!', 'success')
    else:
        for field, errors in form.errors.items():
            for error in errors:
                flash(f'{field}: {error}', 'error')
    
    return redirect(url_for('profile'))

@app.route('/profile/change-password', methods=['POST'])
def profile_change_password():
    """Change user password from profile page"""
    if 'user_id' not in session:
        return redirect(url_for('login'))
    
    user = User.query.get(session['user_id'])
    if not user:
        return redirect(url_for('logout'))
    
    form = ChangePasswordForm()
    if form.validate_on_submit():
        if user.check_password(form.current_password.data):
            if form.new_password.data == form.confirm_password.data:
                user.set_password(form.new_password.data)
                user.last_active = datetime.utcnow()
                
                db.session.commit()
                flash('Password changed successfully!', 'success')
            else:
                flash('New passwords do not match!', 'error')
        else:
            flash('Current password is incorrect!', 'error')
    else:
        for field, errors in form.errors.items():
            for error in errors:
                flash(f'{field}: {error}', 'error')
    
    return redirect(url_for('profile'))
