from app import db
from werkzeug.security import generate_password_hash, check_password_hash
from datetime import datetime, timedelta
from sqlalchemy import func
import secrets
import string
import json
import os

class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(64), unique=True, nullable=False, index=True)
    email = db.Column(db.String(120), unique=True, nullable=False, index=True)
    full_name = db.Column(db.String(100), nullable=False)
    password_hash = db.Column(db.String(256), nullable=False)
    credits = db.Column(db.Float, default=0.0)
    is_admin = db.Column(db.Boolean, default=False)
    is_active = db.Column(db.Boolean, default=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    last_login = db.Column(db.DateTime)
    
    # Referral system
    referral_code = db.Column(db.String(10), unique=True, index=True)
    referred_by_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=True)
    total_referrals = db.Column(db.Integer, default=0)
    referral_earnings = db.Column(db.Float, default=0.0)
    
    # Telegram integration
    telegram_id = db.Column(db.String(20), unique=True, nullable=True, index=True)
    telegram_username = db.Column(db.String(64), nullable=True)
    
    # Payment settings
    upi_id = db.Column(db.String(100), nullable=True)
    mobile = db.Column(db.String(15), nullable=True)
    last_active = db.Column(db.DateTime)
    
    # Relationships
    searches = db.relationship('Search', backref='user', lazy='dynamic', cascade='all, delete-orphan')
    transactions = db.relationship('Transaction', backref='user', lazy='dynamic', cascade='all, delete-orphan')
    payments = db.relationship('Payment', foreign_keys='Payment.user_id', backref='user', lazy='dynamic', cascade='all, delete-orphan')
    approved_payments = db.relationship('Payment', foreign_keys='Payment.admin_approved_by', backref='approver', lazy='dynamic')
    referred_users = db.relationship('User', backref=db.backref('referrer', remote_side=[id]), lazy='dynamic')

    def set_password(self, password):
        self.password_hash = generate_password_hash(password)

    def check_password(self, password):
        return check_password_hash(self.password_hash, password)
    
    def generate_referral_code(self):
        """Generate a unique referral code"""
        while True:
            code = ''.join(secrets.choice(string.ascii_uppercase + string.digits) for _ in range(8))
            if not User.query.filter_by(referral_code=code).first():
                self.referral_code = code
                break
    
    def get_search_stats(self):
        """Get user search statistics"""
        today = datetime.utcnow().date()
        this_month = datetime.utcnow().replace(day=1).date()
        
        return {
            'today': Search.query.filter_by(user_id=self.id).filter(
                func.date(Search.created_at) == today
            ).count(),
            'this_month': Search.query.filter_by(user_id=self.id).filter(
                func.date(Search.created_at) >= this_month
            ).count(),
            'total': Search.query.filter_by(user_id=self.id).count()
        }
    
    def get_referral_stats(self):
        """Get referral statistics"""
        return {
            'total_referrals': self.total_referrals,
            'referral_earnings': self.referral_earnings,
            'referral_code': self.referral_code,
            'recent_referrals': self.referred_users.order_by(User.created_at.desc()).limit(10).all()
        }
    
    def check_referral_fraud_risk(self):
        """Check for potential referral fraud indicators"""
        from datetime import datetime, timedelta
        
        risk_score = 0
        flags = []
        
        # Check signup patterns from same IP within 24 hours
        recent_signups = db.session.query(func.count(SystemLog.id)).filter(
            SystemLog.category == 'auth',
            SystemLog.message.like('%registration%'),
            SystemLog.created_at >= datetime.utcnow() - timedelta(hours=24)
        ).scalar() or 0
        
        if recent_signups > 3:
            risk_score += 30
            flags.append(f'Multiple signups from same IP: {recent_signups}')
        
        # Check rapid referrals
        if self.total_referrals > 5:
            recent_referrals = self.referred_users.filter(
                User.created_at >= datetime.utcnow() - timedelta(hours=1)
            ).count()
            
            if recent_referrals >= 3:
                risk_score += 40
                flags.append(f'Rapid referrals: {recent_referrals} in 1 hour')
        
        # Check email patterns
        referred_emails = [u.email for u in self.referred_users.all()]
        if len(referred_emails) > 2:
            # Check for similar email patterns
            domains = [email.split('@')[1] for email in referred_emails]
            if len(set(domains)) <= len(domains) / 3:  # Too many from same domains
                risk_score += 25
                flags.append('Similar email domains in referrals')
        
        # Determine risk level
        if risk_score >= 70:
            risk_level = 'HIGH'
        elif risk_score >= 40:
            risk_level = 'MEDIUM'
        elif risk_score >= 20:
            risk_level = 'LOW'
        else:
            risk_level = 'CLEAN'
        
        return {
            'risk_score': risk_score,
            'risk_level': risk_level,
            'flags': flags,
            'requires_review': risk_score >= 40
        }

class ReferralFraudLog(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    risk_score = db.Column(db.Integer, nullable=False)
    risk_level = db.Column(db.String(10), nullable=False)  # LOW, MEDIUM, HIGH
    flags = db.Column(db.JSON, nullable=False)  # List of fraud indicators
    action_taken = db.Column(db.String(50), nullable=True)  # blocked, reviewed, cleared
    reviewed_by = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=True)
    reviewed_at = db.Column(db.DateTime, nullable=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow, index=True)
    
    # Relationships
    user = db.relationship('User', foreign_keys=[user_id], backref='fraud_logs')
    reviewer = db.relationship('User', foreign_keys=[reviewed_by])
    
    @staticmethod
    def check_and_log_user(user_id):
        """Check user for referral fraud and log results"""
        user = User.query.get(user_id)
        if not user:
            return None
            
        fraud_check = user.check_referral_fraud_risk()
        
        # Only log if there's some risk
        if fraud_check['risk_score'] > 0:
            fraud_log = ReferralFraudLog(
                user_id=user_id,
                risk_score=fraud_check['risk_score'],
                risk_level=fraud_check['risk_level'],
                flags=fraud_check['flags']
            )
            db.session.add(fraud_log)
            
            # Log security event
            SystemLog.log(
                'WARNING' if fraud_check['risk_level'] == 'HIGH' else 'INFO',
                'referral_fraud',
                f'Referral fraud check: {fraud_check["risk_level"]} risk for user {user.username}',
                user_id=user_id,
                extra_data={
                    'risk_score': fraud_check['risk_score'],
                    'flags': fraud_check['flags']
                }
            )
            
            try:
                db.session.commit()
                return fraud_log
            except Exception as e:
                db.session.rollback()
                SystemLog.log('ERROR', 'system', f'Failed to log referral fraud check: {e}')
        
        return None
    
    @staticmethod
    def get_pending_reviews():
        """Get fraud cases that need admin review"""
        return ReferralFraudLog.query.filter(
            ReferralFraudLog.risk_level.in_(['MEDIUM', 'HIGH']),
            ReferralFraudLog.reviewed_at.is_(None)
        ).order_by(ReferralFraudLog.created_at.desc()).all()

class ProtectedNumber(db.Model):
    __tablename__ = 'protected_numbers'
    
    id = db.Column(db.Integer, primary_key=True)
    phone_number = db.Column(db.String(10), unique=True, nullable=False)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=True)  # User who protected it
    protected_by_admin = db.Column(db.Boolean, default=False)
    protection_fee = db.Column(db.Float, default=500.0)
    reason = db.Column(db.String(200))
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    expires_at = db.Column(db.DateTime, nullable=True)  # Optional expiry
    is_active = db.Column(db.Boolean, default=True)
    
    # Relationships
    user = db.relationship('User', foreign_keys=[user_id], backref='protected_numbers')
    
    @staticmethod
    def is_protected(phone_number):
        """Check if a phone number is protected"""
        protected = ProtectedNumber.query.filter_by(
            phone_number=phone_number,
            is_active=True
        ).first()
        
        if protected:
            # Check if protection has expired
            if protected.expires_at and protected.expires_at < datetime.utcnow():
                protected.is_active = False
                db.session.commit()
                return False
            return True
        return False

class Search(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    query_type = db.Column(db.String(20), nullable=False)  # mobile, aadhar, vehicle
    query_value = db.Column(db.String(100), nullable=False)
    result_data = db.Column(db.Text)  # JSON string
    credits_used = db.Column(db.Float, nullable=False)
    status = db.Column(db.String(20), default='pending')  # pending, completed, failed
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    ip_address = db.Column(db.String(45))  # Support IPv6
    user_agent = db.Column(db.String(500))

class Transaction(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    transaction_type = db.Column(db.String(20), nullable=False)  # credit, debit
    amount = db.Column(db.Float, nullable=False)
    description = db.Column(db.String(200), nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    reference_id = db.Column(db.String(100))  # Payment ID, Search ID, etc.

class Payment(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    amount = db.Column(db.Float, nullable=False)
    credits = db.Column(db.Float, nullable=False)
    payment_method = db.Column(db.String(50), nullable=False)
    transaction_id = db.Column(db.String(100), unique=True, nullable=False)
    gateway_response = db.Column(db.Text)  # JSON response from payment gateway
    status = db.Column(db.String(20), default='pending')  # pending, completed, failed, cancelled
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    completed_at = db.Column(db.DateTime)
    admin_approved = db.Column(db.Boolean, default=False)
    admin_approved_by = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=True)
    admin_approved_at = db.Column(db.DateTime)
    approval_number = db.Column(db.String(20), unique=True, nullable=True)  # Unique approval number
    qr_code_data = db.Column(db.Text)  # QR code data for UPI payments
    admin_notified = db.Column(db.Boolean, default=False)  # Track if admin has been notified
    
    def generate_approval_number(self):
        """Generate a unique approval number"""
        import random
        import string
        from datetime import datetime
        
        # Format: APR-YYYYMMDD-XXXX (APR-20250731-A1B2)
        date_str = datetime.utcnow().strftime('%Y%m%d')
        random_str = ''.join(random.choices(string.ascii_uppercase + string.digits, k=4))
        approval_number = f"APR-{date_str}-{random_str}"
        
        # Ensure uniqueness
        while Payment.query.filter_by(approval_number=approval_number).first():
            random_str = ''.join(random.choices(string.ascii_uppercase + string.digits, k=4))
            approval_number = f"APR-{date_str}-{random_str}"
        
        self.approval_number = approval_number
        return approval_number

class APIKey(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    service = db.Column(db.String(50), nullable=False)  # mobile_api, aadhar_api, vehicle_api
    key_value = db.Column(db.Text, nullable=False)  # Encrypted API key
    endpoint_url = db.Column(db.String(500))
    is_active = db.Column(db.Boolean, default=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    created_by = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    last_used = db.Column(db.DateTime)
    usage_count = db.Column(db.Integer, default=0)

class SystemSetting(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    key = db.Column(db.String(100), unique=True, nullable=False)
    value = db.Column(db.Text)
    data_type = db.Column(db.String(20), default='string')  # string, int, float, bool, json
    description = db.Column(db.String(500))
    category = db.Column(db.String(50), default='general')
    is_public = db.Column(db.Boolean, default=False)  # Can be accessed by non-admin users
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    @classmethod
    def get_value(cls, key, default=None):
        """Get a system setting value with proper type conversion"""
        setting = cls.query.filter_by(key=key).first()
        if not setting:
            return default
        
        try:
            if setting.data_type == 'int':
                return int(setting.value)
            elif setting.data_type == 'float':
                return float(setting.value)
            elif setting.data_type == 'bool':
                return setting.value.lower() in ('true', '1', 'yes', 'on')
            elif setting.data_type == 'json':
                return json.loads(setting.value)
            else:
                return setting.value
        except (ValueError, json.JSONDecodeError):
            return default

    @classmethod
    def set_value(cls, key, value, data_type='string', description=None, category='general'):
        """Set a system setting value"""
        setting = cls.query.filter_by(key=key).first()
        if not setting:
            setting = cls(key=key, data_type=data_type, description=description, category=category)
            db.session.add(setting)
        
        if data_type == 'json':
            setting.value = json.dumps(value)
        else:
            setting.value = str(value)
        
        setting.data_type = data_type
        setting.updated_at = datetime.utcnow()
        if description:
            setting.description = description
        if category:
            setting.category = category
        
        db.session.commit()
        return setting

class SystemLog(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    level = db.Column(db.String(20), nullable=False)  # INFO, WARNING, ERROR, SECURITY
    category = db.Column(db.String(50), nullable=False)  # auth, search, payment, admin, security
    message = db.Column(db.Text, nullable=False)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=True)
    ip_address = db.Column(db.String(45))
    user_agent = db.Column(db.String(500))
    extra_data = db.Column(db.Text)  # JSON string for additional data
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    user = db.relationship('User', backref='system_logs')

    @classmethod
    def log(cls, level, category, message, user_id=None, ip_address=None, user_agent=None, extra_data=None):
        """Create a system log entry"""
        log_entry = cls(
            level=level,
            category=category,
            message=message,
            user_id=user_id,
            ip_address=ip_address,
            user_agent=user_agent,
            extra_data=json.dumps(extra_data) if extra_data else None
        )
        db.session.add(log_entry)
        db.session.commit()
        return log_entry

class AdminAction(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    admin_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    action_type = db.Column(db.String(50), nullable=False)  # user_edit, credit_add, payment_approve, etc.
    target_user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=True)
    description = db.Column(db.Text, nullable=False)
    old_values = db.Column(db.Text)  # JSON string of old values
    new_values = db.Column(db.Text)  # JSON string of new values
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    ip_address = db.Column(db.String(45))

    admin = db.relationship('User', foreign_keys=[admin_id], backref='admin_actions')
    target_user = db.relationship('User', foreign_keys=[target_user_id])
    
    @classmethod
    def log_action(cls, admin_id, action_type, description, ip_address, target_user_id=None, old_values=None, new_values=None, notes=None):
        """Log an admin action"""
        # Include notes in description if provided
        if notes:
            description = f"{description} - Notes: {notes}"
            
        action = cls(
            admin_id=admin_id,
            action_type=action_type,
            description=description,
            target_user_id=target_user_id,
            old_values=json.dumps(old_values) if old_values else None,
            new_values=json.dumps(new_values) if new_values else None,
            ip_address=ip_address
        )
        db.session.add(action)
        db.session.commit()
        return action

class SupportTicket(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    subject = db.Column(db.String(200), nullable=False)
    description = db.Column(db.Text, nullable=False)
    category = db.Column(db.String(50), nullable=False)  # billing, technical, account, other
    priority = db.Column(db.String(20), default='medium')  # low, medium, high
    status = db.Column(db.String(20), default='open')  # open, waiting, answered, closed
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    closed_at = db.Column(db.DateTime)
    closed_by = db.Column(db.Integer, db.ForeignKey('user.id'))
    last_user_reply = db.Column(db.DateTime)
    last_admin_reply = db.Column(db.DateTime)
    
    user = db.relationship('User', foreign_keys=[user_id], backref='support_tickets')
    closer = db.relationship('User', foreign_keys=[closed_by])
    messages = db.relationship('SupportMessage', backref='ticket', lazy='dynamic', cascade='all, delete-orphan')

class SupportMessage(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    ticket_id = db.Column(db.Integer, db.ForeignKey('support_ticket.id'), nullable=False)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    message = db.Column(db.Text, nullable=False)
    is_admin = db.Column(db.Boolean, default=False)
    is_read = db.Column(db.Boolean, default=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    attachments = db.Column(db.Text)  # JSON list of attachment URLs
    
    user = db.relationship('User', backref='support_messages')

class GiftCard(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    code = db.Column(db.String(20), unique=True, nullable=False, index=True)
    amount = db.Column(db.Float, nullable=False)
    is_redeemed = db.Column(db.Boolean, default=False)
    is_active = db.Column(db.Boolean, default=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    expires_at = db.Column(db.DateTime, nullable=True)
    redeemed_at = db.Column(db.DateTime, nullable=True)
    
    # Creator and redeemer relationships
    created_by = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    redeemed_by = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=True)
    
    # Batch generation tracking
    batch_id = db.Column(db.String(20), nullable=True, index=True)
    notes = db.Column(db.Text, nullable=True)
    
    # Relationships
    creator = db.relationship('User', foreign_keys=[created_by], backref='created_gift_cards')
    redeemer = db.relationship('User', foreign_keys=[redeemed_by], backref='redeemed_gift_cards')
    
    def generate_code(self):
        """Generate a unique gift card code"""
        while True:
            # Generate code in format: GIFT-XXXX-XXXX-XXXX
            parts = []
            for _ in range(3):
                part = ''.join(secrets.choice(string.ascii_uppercase + string.digits) for _ in range(4))
                parts.append(part)
            code = f"GIFT-{'-'.join(parts)}"
            
            # Check if code already exists
            if not GiftCard.query.filter_by(code=code).first():
                self.code = code
                break
    
    def is_valid(self):
        """Check if gift card is valid for redemption"""
        if self.is_redeemed:
            return False, "Gift card has already been redeemed"
        if not self.is_active:
            return False, "Gift card is not active"
        if self.expires_at and datetime.utcnow() > self.expires_at:
            return False, "Gift card has expired"
        return True, "Valid"

def init_default_data():
    """Initialize default data if not exists"""
    # Create default admin user
    if not User.query.filter_by(username='admin').first():
        admin = User(
            username='admin',
            email='admin@mrosint.com',
            full_name='System Administrator',
            is_admin=True,
            credits=1000.0
        )
        admin.set_password('admin123')
        admin.generate_referral_code()
        db.session.add(admin)
    
    # Default system settings
    default_settings = [
        ('system.site_name', 'MROSINT', 'string', 'Site name', 'general'),
        ('system.registration_enabled', 'true', 'bool', 'Allow user registration', 'general'),
        ('system.welcome_credits', '25.0', 'float', 'Welcome bonus credits for new users', 'general'),
        ('system.maintenance_mode', 'false', 'bool', 'Maintenance mode status', 'general'),
        
        ('search.mobile_cost', '99.0', 'float', 'Cost per mobile search', 'pricing'),
        ('search.aadhar_cost', '149.0', 'float', 'Cost per Aadhar search', 'pricing'),
        ('search.vehicle_cost', '49.63', 'float', 'Cost per vehicle search', 'pricing'),
        
        ('referral.enabled', 'true', 'bool', 'Enable referral system', 'referral'),
        ('referral.bonus_amount', '5.0', 'float', 'Referral bonus amount', 'referral'),
        
        ('payment.upi_id', 'knoxusdt@paytm', 'string', 'UPI ID for payments', 'payment'),
        ('payment.min_amount', '100.0', 'float', 'Minimum payment amount', 'payment'),
        ('payment.max_amount', '10000.0', 'float', 'Maximum payment amount', 'payment'),
        ('payment.auto_approve', 'false', 'bool', 'Auto approve payments', 'payment'),
        
        ('telegram.bot_token', '', 'string', 'Telegram bot token', 'telegram'),
        ('telegram.webhook_url', '', 'string', 'Telegram webhook URL', 'telegram'),
        ('telegram.admin_chat_id', '', 'string', 'Telegram admin chat ID', 'telegram'),
        
        ('api.mobile_endpoint', '', 'string', 'Mobile search API endpoint', 'api'),
        ('api.aadhar_endpoint', '', 'string', 'Aadhar search API endpoint', 'api'),
        ('api.vehicle_endpoint', '', 'string', 'Vehicle search API endpoint', 'api'),
        ('api.timeout', '30', 'int', 'API request timeout in seconds', 'api'),
        ('api.rate_limit', '60', 'int', 'API rate limit per minute per user', 'api'),
    ]
    
    for key, value, data_type, description, category in default_settings:
        if not SystemSetting.query.filter_by(key=key).first():
            SystemSetting.set_value(key, value, data_type, description, category)
    
    db.session.commit()
