#!/usr/bin/env python3
"""
MROSINT Telegram Bot
A fully functional Telegram bot that mirrors all website features
"""

import logging
import os
import json
import re
from datetime import datetime
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup, ReplyKeyboardMarkup, KeyboardButton, ReplyKeyboardRemove
from telegram.ext import Application, CommandHandler, MessageHandler, filters, ContextTypes, CallbackQueryHandler, ConversationHandler
from telegram.constants import ParseMode
import qrcode
from io import BytesIO
import base64

# Import database models and utilities
import sys
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from app import app, db
from models import User, Search, Transaction, Payment, SystemSetting, ProtectedNumber
from api_client import OSINTAPIClient

# Enable logging
logging.basicConfig(
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    level=logging.INFO
)
logger = logging.getLogger(__name__)

# Bot configuration
BOT_TOKEN = os.environ.get('TELEGRAM_BOT_TOKEN', '7577806882:AAHPzM8GY8bSpAqp2hd75hw6cgV5f6jf0zM')
ADMIN_ID = 7597633895

# Conversation states
MOBILE_SEARCH, AADHAR_SEARCH, VEHICLE_SEARCH = range(3)
PAYMENT_AMOUNT = 4
PROTECT_NUMBER = 5

class MROSINTBot:
    """Main bot class handling all MROSINT features"""
    
    def __init__(self):
        self.application = Application.builder().token(BOT_TOKEN).build()
        self._setup_handlers()
    
    def _setup_handlers(self):
        """Set up all command and message handlers"""
        # Command handlers
        self.application.add_handler(CommandHandler("start", self.start_command))
        self.application.add_handler(CommandHandler("help", self.help_command))
        self.application.add_handler(CommandHandler("balance", self.balance_command))
        self.application.add_handler(CommandHandler("search", self.search_command))
        self.application.add_handler(CommandHandler("history", self.history_command))
        self.application.add_handler(CommandHandler("referral", self.referral_command))
        self.application.add_handler(CommandHandler("payment", self.payment_command))
        self.application.add_handler(CommandHandler("protect", self.protect_command))
        self.application.add_handler(CommandHandler("support", self.support_command))
        self.application.add_handler(CommandHandler("admin", self.admin_command))
        
        # Callback query handler
        self.application.add_handler(CallbackQueryHandler(self.button_callback))
        
        # Conversation handlers for searches
        mobile_conv = ConversationHandler(
            entry_points=[CallbackQueryHandler(self.mobile_search_start, pattern='^search_mobile$')],
            states={
                MOBILE_SEARCH: [MessageHandler(filters.TEXT & ~filters.COMMAND, self.mobile_search_process)]
            },
            fallbacks=[CommandHandler('cancel', self.cancel)]
        )
        
        aadhar_conv = ConversationHandler(
            entry_points=[CallbackQueryHandler(self.aadhar_search_start, pattern='^search_aadhar$')],
            states={
                AADHAR_SEARCH: [MessageHandler(filters.TEXT & ~filters.COMMAND, self.aadhar_search_process)]
            },
            fallbacks=[CommandHandler('cancel', self.cancel)]
        )
        
        vehicle_conv = ConversationHandler(
            entry_points=[CallbackQueryHandler(self.vehicle_search_start, pattern='^search_vehicle$')],
            states={
                VEHICLE_SEARCH: [MessageHandler(filters.TEXT & ~filters.COMMAND, self.vehicle_search_process)]
            },
            fallbacks=[CommandHandler('cancel', self.cancel)]
        )
        
        payment_conv = ConversationHandler(
            entry_points=[CallbackQueryHandler(self.payment_start, pattern='^add_credits$')],
            states={
                PAYMENT_AMOUNT: [MessageHandler(filters.TEXT & ~filters.COMMAND, self.payment_process)]
            },
            fallbacks=[CommandHandler('cancel', self.cancel)]
        )
        
        protect_conv = ConversationHandler(
            entry_points=[CommandHandler("protect", self.protect_command)],
            states={
                PROTECT_NUMBER: [MessageHandler(filters.TEXT & ~filters.COMMAND, self.protect_process)]
            },
            fallbacks=[CommandHandler('cancel', self.cancel)]
        )
        
        self.application.add_handler(mobile_conv)
        self.application.add_handler(aadhar_conv)
        self.application.add_handler(vehicle_conv)
        self.application.add_handler(payment_conv)
        self.application.add_handler(protect_conv)
        
        # Error handler
        self.application.add_error_handler(self.error_handler)
    
    async def start_command(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle /start command - register or welcome user"""
        if not update.effective_user:
            return
        
        user_id = update.effective_user.id
        username = update.effective_user.username or f"tg_{user_id}"
        first_name = update.effective_user.first_name or "User"
        
        with app.app_context():
            # Check if user exists
            user = User.query.filter_by(telegram_id=str(user_id)).first()
            
            if not user:
                # Check for referral code
                referral_code = None
                if context.args:
                    referral_code = context.args[0]
                
                # Create new user
                user = User()
                user.username = f"tg_{user_id}"
                user.email = f"tg_{user_id}@telegram.user"
                user.telegram_id = str(user_id)
                user.telegram_username = username
                user.is_active = True
                user.created_via = 'telegram'
                user.set_password(str(user_id))  # Default password is Telegram ID
                
                # Get signup bonus from settings
                signup_bonus_setting = SystemSetting.query.filter_by(key='signup_bonus').first()
                signup_bonus = float(signup_bonus_setting.value) if signup_bonus_setting else 500.0
                user.credits = signup_bonus
                
                # Handle referral
                if referral_code:
                    referrer = User.query.filter_by(referral_code=referral_code).first()
                    if referrer and referrer.id != user.id:
                        user.referred_by = referrer.id
                        
                        # Add referral bonuses
                        referral_bonus_setting = SystemSetting.query.filter_by(key='referral_bonus').first()
                        referral_signup_bonus_setting = SystemSetting.query.filter_by(key='referral_signup_bonus').first()
                        
                        referral_bonus = float(referral_bonus_setting.value) if referral_bonus_setting else 50.0
                        referral_signup_bonus = float(referral_signup_bonus_setting.value) if referral_signup_bonus_setting else 25.0
                        
                        # Add bonus to referrer
                        referrer.referral_earnings += referral_bonus
                        referrer.credits += referral_bonus
                        
                        # Add bonus to new user
                        user.credits += referral_signup_bonus
                        
                        # Create transactions
                        referrer_transaction = Transaction()
                        referrer_transaction.user_id = referrer.id
                        referrer_transaction.transaction_type = 'credit'
                        referrer_transaction.amount = referral_bonus
                        referrer_transaction.description = f'Referral bonus for {username}'
                        
                        user_transaction = Transaction()
                        user_transaction.user_id = user.id
                        user_transaction.transaction_type = 'credit'
                        user_transaction.amount = referral_signup_bonus
                        user_transaction.description = 'Referral signup bonus'
                        
                        db.session.add(referrer_transaction)
                        db.session.add(user_transaction)
                
                db.session.add(user)
                db.session.commit()
                
                welcome_text = f"""
🎉 *Welcome to MROSINT Bot, {first_name}!*

✅ Your account has been created successfully!
💰 You've received *₹{user.credits:.2f}* as signup bonus!

*Your Login Credentials:*
📧 Username: `{user.username}`
🔑 Password: `{user_id}` (your Telegram ID)

You can use these credentials to login on our website too!

Use /help to see all available commands.
"""
            else:
                welcome_text = f"""
👋 *Welcome back, {first_name}!*

💰 Current Balance: *₹{user.credits:.2f}*
🔍 Total Searches: *{user.searches.count()}*

Use /help to see all available commands.
"""
        
        # Main menu keyboard
        keyboard = [
            [InlineKeyboardButton("🔍 Search", callback_data='search_menu'),
             InlineKeyboardButton("💰 Add Credits", callback_data='add_credits')],
            [InlineKeyboardButton("📊 My History", callback_data='history'),
             InlineKeyboardButton("👥 Referrals", callback_data='referrals')],
            [InlineKeyboardButton("🛡️ Protect Number", callback_data='protect_number'),
             InlineKeyboardButton("💬 Support", callback_data='support')],
            [InlineKeyboardButton("🌐 Open Website", url='https://mrosint.com')]
        ]
        reply_markup = InlineKeyboardMarkup(keyboard)
        
        if update.message:
            await update.message.reply_text(
                welcome_text,
                parse_mode=ParseMode.MARKDOWN,
                reply_markup=reply_markup
            )
    
    async def help_command(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Show help message with all commands"""
        if not update.message:
            return
            
        help_text = """
*MROSINT Bot Commands:*

🔍 *Search Commands:*
/search - Start a new OSINT search
/history - View your search history

💰 *Account Commands:*
/balance - Check your credit balance
/payment - Add credits to your account
/referral - Get your referral link & stats

🛡️ *Protection:*
/protect - Protect your phone number

💬 *Support:*
/support - Contact support team

👤 *General:*
/start - Start the bot
/help - Show this help message

*Search Pricing:*
📱 Mobile Search: ₹99
🆔 Aadhar Search: ₹149
🚗 Vehicle Search: ₹49.63

*Tips:*
• Share your referral link to earn ₹50 per signup
• Protect your number for ₹500 (one-time)
• All searches are secure and confidential
"""
        
        await update.message.reply_text(help_text, parse_mode=ParseMode.MARKDOWN)
    
    async def balance_command(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Check user balance"""
        if not update.effective_user or not update.message:
            return
            
        user_id = update.effective_user.id
        
        with app.app_context():
            user = User.query.filter_by(telegram_id=str(user_id)).first()
            if not user:
                await update.message.reply_text("❌ Please start the bot first with /start")
                return
            
            balance_text = f"""
💰 *Your Account Balance*

Current Credits: *₹{user.credits:.2f}*
Total Searches: *{user.searches.count()}*
Referral Earnings: *₹{user.referral_earnings:.2f}*

Use /payment to add more credits.
"""
            
            keyboard = [[InlineKeyboardButton("💳 Add Credits", callback_data='add_credits')]]
            reply_markup = InlineKeyboardMarkup(keyboard)
            
            await update.message.reply_text(
                balance_text,
                parse_mode=ParseMode.MARKDOWN,
                reply_markup=reply_markup
            )
    
    async def search_command(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Show search menu"""
        if not update.message:
            return
            
        keyboard = [
            [InlineKeyboardButton("📱 Mobile Number", callback_data='search_mobile')],
            [InlineKeyboardButton("🆔 Aadhar Number", callback_data='search_aadhar')],
            [InlineKeyboardButton("🚗 Vehicle Number", callback_data='search_vehicle')],
            [InlineKeyboardButton("◀️ Back to Menu", callback_data='main_menu')]
        ]
        reply_markup = InlineKeyboardMarkup(keyboard)
        
        await update.message.reply_text(
            "*Select Search Type:*\n\nChoose what you want to search for:",
            parse_mode=ParseMode.MARKDOWN,
            reply_markup=reply_markup
        )
    
    async def mobile_search_start(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Start mobile number search"""
        query = update.callback_query
        if not query:
            return
        await query.answer()
        
        await query.edit_message_text(
            "📱 *Mobile Number Search*\n\n"
            "Please enter the 10-digit mobile number you want to search:\n\n"
            "Example: `9876543210`\n\n"
            "Type /cancel to cancel the search.",
            parse_mode=ParseMode.MARKDOWN
        )
        
        return MOBILE_SEARCH
    
    async def mobile_search_process(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Process mobile number search"""
        if not update.message or not update.effective_user:
            return ConversationHandler.END
            
        mobile_number = update.message.text.strip()
        user_id = update.effective_user.id
        
        # Validate mobile number
        if not re.match(r'^[6-9]\d{9}$', mobile_number):
            await update.message.reply_text(
                "❌ Invalid mobile number! Please enter a valid 10-digit mobile number starting with 6-9."
            )
            return MOBILE_SEARCH
        
        # Show searching message
        searching_msg = await update.message.reply_text("🔍 Searching... Please wait...")
        
        with app.app_context():
            user = User.query.filter_by(telegram_id=str(user_id)).first()
            if not user:
                await searching_msg.edit_text("❌ Please start the bot first with /start")
                return ConversationHandler.END
            
            # Check if number is protected
            protected = ProtectedNumber.query.filter_by(
                number=mobile_number,
                number_type='mobile',
                is_active=True
            ).first()
            
            if protected:
                await searching_msg.edit_text(
                    "🛡️ *Protected Number*\n\n"
                    "This number has been protected by its owner and cannot be searched.",
                    parse_mode=ParseMode.MARKDOWN
                )
                return ConversationHandler.END
            
            # Get pricing
            mobile_price_setting = SystemSetting.query.filter_by(key='mobile_search_price').first()
            search_cost = float(mobile_price_setting.value) if mobile_price_setting else 99.0
            
            # Check balance
            if user.credits < search_cost:
                keyboard = [[InlineKeyboardButton("💳 Add Credits", callback_data='add_credits')]]
                reply_markup = InlineKeyboardMarkup(keyboard)
                
                await searching_msg.edit_text(
                    f"❌ *Insufficient Credits*\n\n"
                    f"You need ₹{search_cost} for this search.\n"
                    f"Your balance: ₹{user.credits:.2f}\n\n"
                    f"Please add credits to continue.",
                    parse_mode=ParseMode.MARKDOWN,
                    reply_markup=reply_markup
                )
                return ConversationHandler.END
            
            # Perform search
            api_client_instance = OSINTAPIClient()
            result = api_client_instance.search('mobile', mobile_number)
            
            # Deduct credits
            user.credits -= search_cost
            
            # Create search record
            search = Search()
            search.user_id = user.id
            search.query_type = 'mobile'
            search.query_value = mobile_number
            search.credits_used = search_cost
            search.status = 'completed' if result['success'] else 'failed'
            search.result_data = json.dumps(result)
            db.session.add(search)
            
            # Create transaction
            transaction = Transaction()
            transaction.user_id = user.id
            transaction.transaction_type = 'debit'
            transaction.amount = search_cost
            transaction.description = f'Mobile search: {mobile_number}'
            db.session.add(transaction)
            
            db.session.commit()
            
            # Format and send result
            if result['success'] and result.get('data'):
                result_text = f"✅ *Mobile Search Results*\n\n📱 Number: `{mobile_number}`\n\n"
                
                if isinstance(result['data'], list):
                    for i, record in enumerate(result['data'], 1):
                        result_text += f"*Record {i}:*\n"
                        if record.get('name'):
                            result_text += f"👤 Name: {record['name']}\n"
                        if record.get('fname'):
                            result_text += f"👨 Father: {record['fname']}\n"
                        if record.get('address'):
                            result_text += f"📍 Address: {record['address']}\n"
                        if record.get('circle'):
                            result_text += f"📡 Operator: {record['circle']}\n"
                        if record.get('alt'):
                            result_text += f"📞 Alt Number: {record['alt']}\n"
                        result_text += "\n"
                else:
                    # Single record
                    data = result['data']
                    if data.get('name'):
                        result_text += f"👤 Name: {data['name']}\n"
                    if data.get('operator'):
                        result_text += f"📡 Operator: {data['operator']}\n"
                    if data.get('circle'):
                        result_text += f"📍 Circle: {data['circle']}\n"
                    if data.get('address'):
                        result_text += f"🏠 Address: {data['address']}\n"
                
                result_text += f"\n💰 Credits Used: ₹{search_cost}\n"
                result_text += f"💳 Remaining Balance: ₹{user.credits:.2f}"
            else:
                result_text = (
                    f"❌ *Search Failed*\n\n"
                    f"Could not find information for: `{mobile_number}`\n\n"
                    f"Credits have been deducted.\n"
                    f"💳 Remaining Balance: ₹{user.credits:.2f}"
                )
            
            keyboard = [
                [InlineKeyboardButton("🔍 New Search", callback_data='search_menu')],
                [InlineKeyboardButton("📊 View History", callback_data='history')],
                [InlineKeyboardButton("🏠 Main Menu", callback_data='main_menu')]
            ]
            reply_markup = InlineKeyboardMarkup(keyboard)
            
            await searching_msg.edit_text(
                result_text,
                parse_mode=ParseMode.MARKDOWN,
                reply_markup=reply_markup
            )
        
        return ConversationHandler.END
    
    async def aadhar_search_start(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Start Aadhar search"""
        query = update.callback_query
        await query.answer()
        
        await query.edit_message_text(
            "🆔 *Aadhar Number Search*\n\n"
            "Please enter the 12-digit Aadhar number you want to search:\n\n"
            "Example: `123456789012`\n\n"
            "Type /cancel to cancel the search.",
            parse_mode=ParseMode.MARKDOWN
        )
        
        return AADHAR_SEARCH
    
    async def aadhar_search_process(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Process Aadhar search"""
        aadhar_number = update.message.text.strip()
        user_id = update.effective_user.id
        
        # Validate Aadhar number
        if not re.match(r'^\d{12}$', aadhar_number):
            await update.message.reply_text(
                "❌ Invalid Aadhar number! Please enter a valid 12-digit Aadhar number."
            )
            return AADHAR_SEARCH
        
        # Process similar to mobile search
        searching_msg = await update.message.reply_text("🔍 Searching... Please wait...")
        
        with app.app_context():
            user = User.query.filter_by(telegram_id=str(user_id)).first()
            if not user:
                await searching_msg.edit_text("❌ Please start the bot first with /start")
                return ConversationHandler.END
            
            # Get pricing
            aadhar_price_setting = SystemSetting.query.filter_by(key='aadhar_search_price').first()
            search_cost = float(aadhar_price_setting.value) if aadhar_price_setting else 149.0
            
            # Check balance
            if user.credits < search_cost:
                keyboard = [[InlineKeyboardButton("💳 Add Credits", callback_data='add_credits')]]
                reply_markup = InlineKeyboardMarkup(keyboard)
                
                await searching_msg.edit_text(
                    f"❌ *Insufficient Credits*\n\n"
                    f"You need ₹{search_cost} for this search.\n"
                    f"Your balance: ₹{user.credits:.2f}\n\n"
                    f"Please add credits to continue.",
                    parse_mode=ParseMode.MARKDOWN,
                    reply_markup=reply_markup
                )
                return ConversationHandler.END
            
            # Perform search and process results
            api_client_instance = OSINTAPIClient()
            result = api_client_instance.search('aadhar', aadhar_number)
            
            # Rest of the implementation similar to mobile search...
            # [Similar implementation as mobile search with appropriate modifications]
        
        return ConversationHandler.END
    
    async def vehicle_search_start(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Start vehicle search"""
        query = update.callback_query
        await query.answer()
        
        await query.edit_message_text(
            "🚗 *Vehicle Number Search*\n\n"
            "Please enter the vehicle registration number:\n\n"
            "Examples:\n"
            "• `DL01AB1234`\n"
            "• `MH12CD5678`\n\n"
            "Type /cancel to cancel the search.",
            parse_mode=ParseMode.MARKDOWN
        )
        
        return VEHICLE_SEARCH
    
    async def vehicle_search_process(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Process vehicle search"""
        # Similar implementation to mobile/aadhar search
        # with vehicle-specific validation and pricing
        pass
    
    async def history_command(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Show search history"""
        user_id = update.effective_user.id
        
        with app.app_context():
            user = User.query.filter_by(telegram_id=str(user_id)).first()
            if not user:
                await update.message.reply_text("❌ Please start the bot first with /start")
                return
            
            # Get recent searches
            recent_searches = Search.query.filter_by(user_id=user.id)\
                .order_by(Search.created_at.desc()).limit(10).all()
            
            if not recent_searches:
                await update.message.reply_text(
                    "📊 *Search History*\n\n"
                    "You haven't performed any searches yet.\n\n"
                    "Use /search to start searching!",
                    parse_mode=ParseMode.MARKDOWN
                )
                return
            
            history_text = "📊 *Your Recent Searches:*\n\n"
            
            for search in recent_searches:
                icon = "📱" if search.query_type == "mobile" else "🆔" if search.query_type == "aadhar" else "🚗"
                status = "✅" if search.status == "completed" else "❌"
                
                # Mask sensitive data
                if search.query_type == "aadhar":
                    display_value = f"{search.query_value[:4]}****{search.query_value[-4:]}"
                else:
                    display_value = search.query_value
                
                history_text += (
                    f"{icon} {display_value} {status}\n"
                    f"   💰 ₹{search.credits_used:.2f} | "
                    f"📅 {search.created_at.strftime('%d/%m/%Y %H:%M')}\n\n"
                )
            
            keyboard = [
                [InlineKeyboardButton("🔍 New Search", callback_data='search_menu')],
                [InlineKeyboardButton("🏠 Main Menu", callback_data='main_menu')]
            ]
            reply_markup = InlineKeyboardMarkup(keyboard)
            
            await update.message.reply_text(
                history_text,
                parse_mode=ParseMode.MARKDOWN,
                reply_markup=reply_markup
            )
    
    async def referral_command(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Show referral information"""
        user_id = update.effective_user.id
        
        with app.app_context():
            user = User.query.filter_by(telegram_id=str(user_id)).first()
            if not user:
                await update.message.reply_text("❌ Please start the bot first with /start")
                return
            
            # Generate referral link
            referral_link = f"https://t.me/MROSINT1bot?start={user.referral_code}"
            
            # Get referral stats
            referral_count = User.query.filter_by(referred_by=user.id).count()
            
            referral_text = f"""
👥 *Your Referral Program*

🔗 *Your Referral Link:*
`{referral_link}`

📊 *Statistics:*
• Total Referrals: *{referral_count}*
• Total Earnings: *₹{user.referral_earnings:.2f}*

💰 *Rewards:*
• You get: ₹50 per referral
• They get: ₹25 signup bonus + ₹500 credits

Share your link with friends and earn!
"""
            
            keyboard = [
                [InlineKeyboardButton("📤 Share Link", switch_inline_query=f"Join MROSINT and get ₹525 bonus! {referral_link}")],
                [InlineKeyboardButton("🏠 Main Menu", callback_data='main_menu')]
            ]
            reply_markup = InlineKeyboardMarkup(keyboard)
            
            await update.message.reply_text(
                referral_text,
                parse_mode=ParseMode.MARKDOWN,
                reply_markup=reply_markup
            )
    
    async def payment_command(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Start payment process"""
        keyboard = [
            [InlineKeyboardButton("💳 Add Credits", callback_data='add_credits')],
            [InlineKeyboardButton("📊 View Transactions", callback_data='transactions')],
            [InlineKeyboardButton("🏠 Main Menu", callback_data='main_menu')]
        ]
        reply_markup = InlineKeyboardMarkup(keyboard)
        
        await update.message.reply_text(
            "*💰 Payment Options*\n\n"
            "Add credits to your account to perform searches.",
            parse_mode=ParseMode.MARKDOWN,
            reply_markup=reply_markup
        )
    
    async def payment_start(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Start payment amount selection"""
        query = update.callback_query
        await query.answer()
        
        keyboard = [
            [InlineKeyboardButton("₹100", callback_data='pay_100'),
             InlineKeyboardButton("₹250", callback_data='pay_250')],
            [InlineKeyboardButton("₹500", callback_data='pay_500'),
             InlineKeyboardButton("₹1000", callback_data='pay_1000')],
            [InlineKeyboardButton("💵 Custom Amount", callback_data='pay_custom')],
            [InlineKeyboardButton("◀️ Back", callback_data='main_menu')]
        ]
        reply_markup = InlineKeyboardMarkup(keyboard)
        
        await query.edit_message_text(
            "*Select Amount to Add:*\n\n"
            "Choose a preset amount or enter custom amount:",
            parse_mode=ParseMode.MARKDOWN,
            reply_markup=reply_markup
        )
    
    async def payment_process(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Process payment amount and generate QR code"""
        # Implementation for payment processing with QR code generation
        pass
    
    async def protect_command(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Start phone number protection"""
        await update.message.reply_text(
            "🛡️ *Protect Your Phone Number*\n\n"
            "Protect your phone number from OSINT searches.\n"
            "Cost: ₹500 (one-time payment)\n\n"
            "Please enter the 10-digit mobile number you want to protect:\n\n"
            "Type /cancel to cancel.",
            parse_mode=ParseMode.MARKDOWN
        )
        
        return PROTECT_NUMBER
    
    async def protect_process(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Process phone number protection"""
        # Implementation for number protection
        pass
    
    async def support_command(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Show support options"""
        support_text = """
💬 *MROSINT Support*

Need help? We're here for you!

*Contact Options:*
• Admin: @mrmac_admin
• Email: support@mrosint.com
• Website: https://mrosint.com/support

*Common Issues:*
• Payment not credited
• Search not working
• Account issues
• Feature requests

*Business Hours:*
Mon-Sat: 9 AM - 6 PM IST
"""
        
        keyboard = [
            [InlineKeyboardButton("👤 Contact Admin", url="https://t.me/mrmac_admin")],
            [InlineKeyboardButton("📧 Email Support", url="mailto:support@mrosint.com")],
            [InlineKeyboardButton("🏠 Main Menu", callback_data='main_menu')]
        ]
        reply_markup = InlineKeyboardMarkup(keyboard)
        
        await update.message.reply_text(
            support_text,
            parse_mode=ParseMode.MARKDOWN,
            reply_markup=reply_markup
        )
    
    async def admin_command(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Admin panel - only for admin users"""
        user_id = update.effective_user.id
        
        if user_id != ADMIN_ID:
            await update.message.reply_text("❌ You don't have permission to access admin panel.")
            return
        
        with app.app_context():
            # Get statistics
            total_users = User.query.count()
            total_searches = Search.query.count()
            total_revenue = db.session.query(db.func.sum(Payment.amount))\
                .filter_by(status='completed').scalar() or 0
            
            admin_text = f"""
👑 *Admin Dashboard*

📊 *Statistics:*
• Total Users: *{total_users}*
• Total Searches: *{total_searches}*
• Total Revenue: *₹{total_revenue:.2f}*

*Admin Actions:*
"""
            
            keyboard = [
                [InlineKeyboardButton("👥 Manage Users", callback_data='admin_users')],
                [InlineKeyboardButton("💰 Manage Payments", callback_data='admin_payments')],
                [InlineKeyboardButton("📊 View Analytics", callback_data='admin_analytics')],
                [InlineKeyboardButton("⚙️ System Settings", callback_data='admin_settings')],
                [InlineKeyboardButton("📢 Broadcast Message", callback_data='admin_broadcast')],
                [InlineKeyboardButton("🏠 Main Menu", callback_data='main_menu')]
            ]
            reply_markup = InlineKeyboardMarkup(keyboard)
            
            await update.message.reply_text(
                admin_text,
                parse_mode=ParseMode.MARKDOWN,
                reply_markup=reply_markup
            )
    
    async def _generate_payment_qr(self, query, amount):
        """Generate UPI QR code for payment"""
        user_id = query.from_user.id
        
        with app.app_context():
            user = User.query.filter_by(telegram_id=str(user_id)).first()
            if not user:
                await query.edit_message_text("❌ Please start the bot first with /start")
                return
            
            # Get UPI ID from settings
            upi_id_setting = SystemSetting.query.filter_by(key='upi_id').first()
            upi_id = upi_id_setting.value if upi_id_setting else '9053407823@mbk'
            
            # Generate UPI string
            upi_string = f"upi://pay?pa={upi_id}&pn=MROSINT&am={amount:.2f}&cu=INR&tn=Add%20Credits%20{user.username}"
            
            # Generate QR code
            qr = qrcode.QRCode(version=1, box_size=10, border=4)
            qr.add_data(upi_string)
            qr.make(fit=True)
            
            img = qr.make_image(fill_color="black", back_color="white")
            bio = BytesIO()
            img.save(bio, 'PNG')
            bio.seek(0)
            
            # Create payment record
            payment = Payment()
            payment.user_id = user.id
            payment.amount = amount
            payment.payment_method = 'UPI'
            payment.status = 'pending'
            payment.payment_details = json.dumps({
                'upi_id': upi_id,
                'telegram_id': str(user_id),
                'telegram_username': query.from_user.username
            })
            db.session.add(payment)
            db.session.commit()
            
            # Send QR code with instructions
            caption = f"""
💰 *Add Credits - ₹{amount:.2f}*

📱 *Step 1:* Scan this QR code with any UPI app
💳 *Step 2:* Complete the payment
⏳ *Step 3:* Wait for admin approval

*Payment ID:* #{payment.id}
*UPI ID:* `{upi_id}`

⚠️ *Important:*
• Save payment screenshot
• Credits added after approval
• Usually within 30 minutes

Having issues? Contact @mrmac_admin
"""
            
            keyboard = [
                [InlineKeyboardButton("✅ I've Paid", callback_data=f'paid_{payment.id}')],
                [InlineKeyboardButton("❌ Cancel", callback_data='main_menu')]
            ]
            reply_markup = InlineKeyboardMarkup(keyboard)
            
            # Edit message to remove old content
            await query.edit_message_text("Generating QR code...")
            
            # Send QR code as photo
            await query.message.reply_photo(
                photo=bio,
                caption=caption,
                parse_mode=ParseMode.MARKDOWN,
                reply_markup=reply_markup
            )
            
            # Notify admin
            from telegram_bot.webhook import notify_admin_new_payment
            notify_admin_new_payment(payment.id, user.username, amount)
    
    async def button_callback(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle all button callbacks"""
        query = update.callback_query
        if not query:
            return
        await query.answer()
        
        # Route to appropriate handler based on callback data
        if query.data == 'main_menu':
            await self.show_main_menu(query)
        elif query.data == 'search_menu':
            await self.show_search_menu(query)
        elif query.data == 'history':
            await self.show_history_inline(query)
        elif query.data == 'referrals':
            await self.show_referrals_inline(query)
        elif query.data == 'support':
            await self.show_support_inline(query)
        elif query.data.startswith('pay_'):
            await self.handle_payment_selection(query)
        elif query.data == 'add_credits':
            await self.payment_start(query, context)
        elif query.data == 'protect_number':
            await self.protect_start_inline(query)
        elif query.data == 'transactions':
            await self.show_transactions(query)
        elif query.data.startswith('paid_'):
            await self.handle_payment_confirmation(query)
        # Add more callback handlers as needed
    
    async def protect_start_inline(self, query):
        """Start protection process from inline button"""
        await query.edit_message_text(
            "🛡️ *Protect Your Phone Number*\n\n"
            "Protect your phone number from OSINT searches.\n"
            "Cost: ₹500 (one-time payment)\n\n"
            "Please enter the 10-digit mobile number you want to protect:\n\n"
            "Type /cancel to cancel.",
            parse_mode=ParseMode.MARKDOWN
        )
        return PROTECT_NUMBER
    
    async def show_transactions(self, query):
        """Show user transactions"""
        user_id = query.from_user.id
        
        with app.app_context():
            user = User.query.filter_by(telegram_id=str(user_id)).first()
            if not user:
                await query.edit_message_text("❌ Please start the bot first with /start")
                return
            
            # Get recent transactions
            transactions = Transaction.query.filter_by(user_id=user.id)\
                .order_by(Transaction.created_at.desc()).limit(10).all()
            
            if not transactions:
                await query.edit_message_text(
                    "💸 *Transaction History*\n\n"
                    "No transactions found.",
                    parse_mode=ParseMode.MARKDOWN
                )
                return
            
            trans_text = "💸 *Recent Transactions:*\n\n"
            
            for trans in transactions:
                icon = "➕" if trans.transaction_type == "credit" else "➖"
                trans_text += (
                    f"{icon} ₹{trans.amount:.2f}\n"
                    f"   {trans.description}\n"
                    f"   📅 {trans.created_at.strftime('%d/%m/%Y %H:%M')}\n\n"
                )
            
            keyboard = [[InlineKeyboardButton("🏠 Main Menu", callback_data='main_menu')]]
            reply_markup = InlineKeyboardMarkup(keyboard)
            
            await query.edit_message_text(
                trans_text,
                parse_mode=ParseMode.MARKDOWN,
                reply_markup=reply_markup
            )
    
    async def handle_payment_confirmation(self, query):
        """Handle payment confirmation"""
        payment_id = query.data.split('_')[1]
        
        await query.edit_message_text(
            "✅ *Payment Notification Sent*\n\n"
            f"Payment ID: #{payment_id}\n\n"
            "Admin has been notified about your payment.\n"
            "You'll receive credits once payment is verified.\n\n"
            "This usually takes 10-30 minutes.",
            parse_mode=ParseMode.MARKDOWN
        )
    
    async def show_main_menu(self, query):
        """Show main menu"""
        keyboard = [
            [InlineKeyboardButton("🔍 Search", callback_data='search_menu'),
             InlineKeyboardButton("💰 Add Credits", callback_data='add_credits')],
            [InlineKeyboardButton("📊 My History", callback_data='history'),
             InlineKeyboardButton("👥 Referrals", callback_data='referrals')],
            [InlineKeyboardButton("🛡️ Protect Number", callback_data='protect_number'),
             InlineKeyboardButton("💬 Support", callback_data='support')],
            [InlineKeyboardButton("🌐 Open Website", url='https://mrosint.com')]
        ]
        reply_markup = InlineKeyboardMarkup(keyboard)
        
        await query.edit_message_text(
            "*MROSINT Main Menu*\n\n"
            "Select an option:",
            parse_mode=ParseMode.MARKDOWN,
            reply_markup=reply_markup
        )
    
    async def show_search_menu(self, query):
        """Show search type selection menu"""
        keyboard = [
            [InlineKeyboardButton("📱 Mobile Number", callback_data='search_mobile')],
            [InlineKeyboardButton("🆔 Aadhar Number", callback_data='search_aadhar')],
            [InlineKeyboardButton("🚗 Vehicle Number", callback_data='search_vehicle')],
            [InlineKeyboardButton("◀️ Back to Menu", callback_data='main_menu')]
        ]
        reply_markup = InlineKeyboardMarkup(keyboard)
        
        await query.edit_message_text(
            "*Select Search Type:*\n\n"
            "Choose what you want to search for:",
            parse_mode=ParseMode.MARKDOWN,
            reply_markup=reply_markup
        )
    
    async def cancel(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Cancel current operation"""
        await update.message.reply_text(
            "❌ Operation cancelled.\n\n"
            "Use /help to see available commands.",
            reply_markup=ReplyKeyboardRemove()
        )
        return ConversationHandler.END
    
    async def error_handler(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle errors"""
        logger.error(f"Update {update} caused error {context.error}")
        
        if update and update.effective_message:
            await update.effective_message.reply_text(
                "❌ An error occurred while processing your request.\n"
                "Please try again or contact support."
            )
    
    def run(self):
        """Run the bot"""
        logger.info("Starting MROSINT Bot...")
        self.application.run_polling(allowed_updates=Update.ALL_TYPES)


if __name__ == '__main__':
    bot = MROSINTBot()
    bot.run()