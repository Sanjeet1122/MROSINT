"""
Gift Card Management Routes for Admin and User
"""

from flask import render_template, redirect, url_for, flash, request, jsonify
from models import User, GiftCard, Transaction, db
from utils import admin_required
from utils import login_required
from flask import session as flask_session
from app import app
from datetime import datetime, timedelta
from forms import GiftCardRedeemForm
import secrets
import string

@app.route('/admin/gift-cards')
@admin_required
def admin_gift_cards():
    """View and manage gift cards"""
    # Get filter parameters
    filter_type = request.args.get('filter', 'all')
    search_query = request.args.get('search', '')
    
    # Base query
    query = GiftCard.query
    
    # Apply filters
    if filter_type == 'active':
        query = query.filter_by(is_active=True, is_redeemed=False)
    elif filter_type == 'redeemed':
        query = query.filter_by(is_redeemed=True)
    elif filter_type == 'expired':
        query = query.filter(
            GiftCard.expires_at.isnot(None),
            GiftCard.expires_at < datetime.utcnow()
        )
    
    # Apply search
    if search_query:
        query = query.filter(
            db.or_(
                GiftCard.code.like(f'%{search_query}%'),
                GiftCard.batch_id.like(f'%{search_query}%')
            )
        )
    
    # Get paginated results
    page = request.args.get('page', 1, type=int)
    per_page = 20
    pagination = query.order_by(GiftCard.created_at.desc()).paginate(
        page=page, per_page=per_page, error_out=False
    )
    
    gift_cards = pagination.items
    
    # Get statistics
    total_cards = GiftCard.query.count()
    active_cards = GiftCard.query.filter_by(is_active=True, is_redeemed=False).count()
    redeemed_cards = GiftCard.query.filter_by(is_redeemed=True).count()
    total_value = db.session.query(db.func.sum(GiftCard.amount)).filter_by(is_active=True, is_redeemed=False).scalar() or 0
    redeemed_value = db.session.query(db.func.sum(GiftCard.amount)).filter_by(is_redeemed=True).scalar() or 0
    
    return render_template('admin/gift_cards.html',
                         gift_cards=gift_cards,
                         pagination=pagination,
                         filter_type=filter_type,
                         search_query=search_query,
                         total_cards=total_cards,
                         active_cards=active_cards,
                         redeemed_cards=redeemed_cards,
                         total_value=total_value,
                         redeemed_value=redeemed_value,
                         now=datetime.utcnow())

@app.route('/admin/gift-cards/create', methods=['GET', 'POST'])
@admin_required
def admin_create_gift_card():
    """Create a single gift card"""
    if request.method == 'POST':
        amount = float(request.form.get('amount', 0))
        expires_days = int(request.form.get('expires_days', 0))
        notes = request.form.get('notes', '')
        
        if amount <= 0:
            flash('Amount must be greater than 0', 'danger')
            return redirect(url_for('admin_create_gift_card'))
        
        # Create gift card
        gift_card = GiftCard()
        gift_card.amount = amount
        gift_card.created_by = flask_session['user_id']
        gift_card.notes = notes
        gift_card.generate_code()
        
        # Set expiration if specified
        if expires_days > 0:
            gift_card.expires_at = datetime.utcnow() + timedelta(days=expires_days)
        
        db.session.add(gift_card)
        db.session.commit()
        
        flash(f'Gift card created successfully! Code: {gift_card.code}', 'success')
        return redirect(url_for('admin_gift_cards'))
    
    return render_template('admin/create_gift_card.html')

@app.route('/admin/gift-cards/bulk-create', methods=['GET', 'POST'])
@admin_required
def admin_bulk_create_gift_cards():
    """Bulk create gift cards"""
    if request.method == 'POST':
        quantity = int(request.form.get('quantity', 0))
        amount = float(request.form.get('amount', 0))
        expires_days = int(request.form.get('expires_days', 0))
        notes = request.form.get('notes', '')
        
        if quantity <= 0 or quantity > 100:
            flash('Quantity must be between 1 and 100', 'danger')
            return redirect(url_for('admin_bulk_create_gift_cards'))
        
        if amount <= 0:
            flash('Amount must be greater than 0', 'danger')
            return redirect(url_for('admin_bulk_create_gift_cards'))
        
        # Generate batch ID
        batch_id = 'BATCH-' + ''.join(secrets.choice(string.ascii_uppercase + string.digits) for _ in range(8))
        
        # Create gift cards
        created_codes = []
        for _ in range(quantity):
            gift_card = GiftCard()
            gift_card.amount = amount
            gift_card.created_by = flask_session['user_id']
            gift_card.batch_id = batch_id
            gift_card.notes = notes
            gift_card.generate_code()
            
            # Set expiration if specified
            if expires_days > 0:
                gift_card.expires_at = datetime.utcnow() + timedelta(days=expires_days)
            
            db.session.add(gift_card)
            created_codes.append(gift_card.code)
        
        db.session.commit()
        
        flash(f'Successfully created {quantity} gift cards! Batch ID: {batch_id}', 'success')
        return render_template('admin/bulk_gift_cards_result.html', codes=created_codes, batch_id=batch_id, amount=amount)
    
    return render_template('admin/bulk_create_gift_cards.html')

@app.route('/admin/gift-cards/<int:card_id>/toggle-status', methods=['POST'])
@admin_required
def toggle_gift_card_status(card_id):
    """Toggle gift card active status"""
    gift_card = GiftCard.query.get_or_404(card_id)
    
    if gift_card.is_redeemed:
        flash('Cannot change status of redeemed gift card', 'warning')
    else:
        gift_card.is_active = not gift_card.is_active
        db.session.commit()
        status = 'activated' if gift_card.is_active else 'deactivated'
        flash(f'Gift card {status} successfully', 'success')
    
    return redirect(url_for('admin_gift_cards'))

@app.route('/gift-cards', methods=['GET', 'POST'])
@login_required
def user_gift_cards():
    """User gift card redemption page"""
    form = GiftCardRedeemForm()
    
    if request.method == 'POST' and form.validate_on_submit():
        code = form.code.data.strip().upper() if form.code.data else ''
        
        # Find gift card
        gift_card = GiftCard.query.filter_by(code=code).first()
        
        if not gift_card:
            flash('Invalid gift card code', 'danger')
            return render_template('gift_cards.html', form=form)
        
        # Validate gift card
        is_valid, message = gift_card.is_valid()
        if not is_valid:
            flash(message, 'danger')
            return render_template('gift_cards.html', form=form)
        
        # Check if user is trying to redeem their own gift card
        if gift_card.created_by == flask_session['user_id']:
            flash('You cannot redeem your own gift card', 'warning')
            return render_template('gift_cards.html', form=form)
        
        # Get current user
        user = User.query.get(flask_session['user_id'])
        
        # Redeem gift card
        gift_card.is_redeemed = True
        gift_card.redeemed_by = flask_session['user_id']
        gift_card.redeemed_at = datetime.utcnow()
        
        # Add credits to user
        user.credits += gift_card.amount
        
        # Create transaction record
        transaction = Transaction()
        transaction.user_id = flask_session['user_id']
        transaction.transaction_type = 'credit'
        transaction.amount = gift_card.amount
        transaction.description = f'Gift Card Redemption - {gift_card.code}'
        
        db.session.add(transaction)
        db.session.commit()
        
        flash(f'Successfully redeemed gift card! ₹{gift_card.amount} added to your account', 'success')
        return redirect(url_for('dashboard'))
    
    # Get user's gift card history
    redeemed_cards = GiftCard.query.filter_by(redeemed_by=flask_session['user_id']).order_by(GiftCard.redeemed_at.desc()).limit(10).all()
    
    return render_template('gift_cards.html', form=form, redeemed_cards=redeemed_cards)

@app.route('/api/gift-cards/validate', methods=['POST'])
@login_required
def validate_gift_card():
    """API endpoint to validate gift card"""
    code = request.json.get('code', '').strip().upper() if request.json and request.json.get('code') else ''
    
    gift_card = GiftCard.query.filter_by(code=code).first()
    
    if not gift_card:
        return jsonify({'valid': False, 'message': 'Invalid gift card code'})
    
    is_valid, message = gift_card.is_valid()
    
    if is_valid and gift_card.created_by == flask_session.get('user_id'):
        return jsonify({'valid': False, 'message': 'You cannot redeem your own gift card'})
    
    return jsonify({
        'valid': is_valid,
        'message': message,
        'amount': gift_card.amount if is_valid else None
    })