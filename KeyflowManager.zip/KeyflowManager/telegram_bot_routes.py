"""
Telegram Bot Management Routes for Admin Panel
"""

from flask import render_template, redirect, url_for, flash, request, jsonify
from models import User, Payment, Search, Transaction, db
from utils import admin_required
from app import app
import json
from datetime import datetime
from telegram_bot.webhook import notify_user_payment_approved

@app.route('/admin/telegram-users')
@admin_required
def admin_telegram_users():
    """View and manage Telegram bot users"""
    # Get filter parameters
    filter_type = request.args.get('filter', 'all')
    search_query = request.args.get('search', '')
    
    # Base query for Telegram users
    query = User.query.filter(User.telegram_id.isnot(None))
    
    # Apply filters
    if filter_type == 'active':
        query = query.filter_by(is_active=True)
    elif filter_type == 'inactive':
        query = query.filter_by(is_active=False)
    elif filter_type == 'today':
        today = datetime.utcnow().date()
        query = query.filter(db.func.date(User.created_at) == today)
    
    # Apply search
    if search_query:
        query = query.filter(
            db.or_(
                User.telegram_username.ilike(f'%{search_query}%'),
                User.telegram_id.ilike(f'%{search_query}%'),
                User.username.ilike(f'%{search_query}%')
            )
        )
    
    # Get paginated results
    page = request.args.get('page', 1, type=int)
    per_page = 20
    pagination = query.order_by(User.created_at.desc()).paginate(
        page=page, per_page=per_page, error_out=False
    )
    
    telegram_users = pagination.items
    
    # Get statistics
    total_telegram_users = User.query.filter(User.telegram_id.isnot(None)).count()
    active_telegram_users = User.query.filter(
        User.telegram_id.isnot(None),
        User.is_active == True
    ).count()
    
    # Calculate total searches and revenue from Telegram users
    telegram_searches = db.session.query(db.func.count(Search.id))\
        .join(User).filter(User.telegram_id.isnot(None)).scalar() or 0
    
    telegram_revenue = db.session.query(db.func.sum(Payment.amount))\
        .join(User, Payment.user_id == User.id).filter(
            User.telegram_id.isnot(None),
            Payment.status == 'completed'
        ).scalar() or 0
    
    return render_template('admin/telegram_users.html',
                         users=telegram_users,
                         pagination=pagination,
                         filter_type=filter_type,
                         search_query=search_query,
                         total_users=total_telegram_users,
                         active_users=active_telegram_users,
                         total_searches=telegram_searches,
                         total_revenue=telegram_revenue)

@app.route('/admin/telegram-payments')
@admin_required
def admin_telegram_payments():
    """View and manage Telegram bot payments"""
    # Get filter parameters
    status_filter = request.args.get('status', 'pending')
    
    # Base query for Telegram payments
    query = Payment.query.join(User, Payment.user_id == User.id).filter(User.telegram_id.isnot(None))
    
    # Apply status filter
    if status_filter != 'all':
        query = query.filter(Payment.status == status_filter)
    
    # Get paginated results
    page = request.args.get('page', 1, type=int)
    per_page = 20
    pagination = query.order_by(Payment.created_at.desc()).paginate(
        page=page, per_page=per_page, error_out=False
    )
    
    payments = pagination.items
    
    # Get statistics
    pending_count = Payment.query.join(User, Payment.user_id == User.id).filter(
        User.telegram_id.isnot(None),
        Payment.status == 'pending'
    ).count()
    
    completed_count = Payment.query.join(User, Payment.user_id == User.id).filter(
        User.telegram_id.isnot(None),
        Payment.status == 'completed'
    ).count()
    
    failed_count = Payment.query.join(User, Payment.user_id == User.id).filter(
        User.telegram_id.isnot(None),
        Payment.status == 'failed'
    ).count()
    
    total_amount = db.session.query(db.func.sum(Payment.amount))\
        .join(User, Payment.user_id == User.id).filter(
            User.telegram_id.isnot(None),
            Payment.status == 'completed'
        ).scalar() or 0
    
    return render_template('admin/telegram_payments.html',
                         payments=payments,
                         pagination=pagination,
                         status_filter=status_filter,
                         pending_count=pending_count,
                         completed_count=completed_count,
                         failed_count=failed_count,
                         total_amount=total_amount)

@app.route('/admin/telegram-payment/<int:payment_id>/approve', methods=['POST'])
@admin_required
def approve_telegram_payment(payment_id):
    """Approve a Telegram payment"""
    payment = Payment.query.get_or_404(payment_id)
    
    if payment.status != 'pending':
        flash('Payment has already been processed.', 'warning')
        return redirect(url_for('admin_telegram_payments'))
    
    # Update payment status
    payment.status = 'completed'
    payment.approved_at = datetime.utcnow()
    
    # Add credits to user
    user = payment.user
    user.credits += payment.amount
    
    # Create transaction record
    transaction = Transaction()
    transaction.user_id = user.id
    transaction.transaction_type = 'credit'
    transaction.amount = payment.amount
    transaction.description = f'Payment #{payment.id} - UPI (Telegram)'
    
    db.session.add(transaction)
    db.session.commit()
    
    # Notify user via Telegram if they have telegram_id
    if user.telegram_id:
        try:
            notify_user_payment_approved(user.id, payment.amount)
        except Exception as e:
            app.logger.error(f"Failed to notify Telegram user: {e}")
    
    flash(f'Payment of ₹{payment.amount} approved for {user.username}', 'success')
    return redirect(url_for('admin_telegram_payments'))

@app.route('/admin/telegram-payment/<int:payment_id>/reject', methods=['POST'])
@admin_required
def reject_telegram_payment(payment_id):
    """Reject a Telegram payment"""
    payment = Payment.query.get_or_404(payment_id)
    
    if payment.status != 'pending':
        flash('Payment has already been processed.', 'warning')
        return redirect(url_for('admin_telegram_payments'))
    
    # Update payment status
    payment.status = 'failed'
    payment.notes = request.form.get('reason', 'Payment verification failed')
    
    db.session.commit()
    
    # Notify user via Telegram if they have telegram_id
    if payment.user.telegram_id:
        try:
            from telegram_bot.webhook import application
            import asyncio
            
            text = f"""
❌ *Payment Rejected*

Your payment of ₹{payment.amount:.2f} was not verified.
Reason: {payment.notes}

Please contact @mrmac_admin if you believe this is an error.
"""
            
            loop = asyncio.new_event_loop()
            asyncio.set_event_loop(loop)
            loop.run_until_complete(
                application.bot.send_message(
                    chat_id=payment.user.telegram_id,
                    text=text,
                    parse_mode='Markdown'
                )
            )
        except Exception as e:
            app.logger.error(f"Failed to notify Telegram user: {e}")
    
    flash(f'Payment rejected for {payment.user.username}', 'warning')
    return redirect(url_for('admin_telegram_payments'))

@app.route('/admin/telegram-payments/bulk-approve', methods=['POST'])
@admin_required
def bulk_approve_telegram_payments():
    """Bulk approve multiple Telegram payments"""
    payment_ids = request.form.getlist('payment_ids')
    
    if not payment_ids:
        flash('No payments selected for approval.', 'warning')
        return redirect(url_for('admin_telegram_payments'))
    
    approved_count = 0
    total_amount = 0
    
    for payment_id in payment_ids:
        try:
            payment = Payment.query.get(int(payment_id))
            if payment and payment.status == 'pending':
                # Update payment status
                payment.status = 'completed'
                payment.approved_at = datetime.utcnow()
                
                # Add credits to user
                user = payment.user
                user.credits += payment.amount
                
                # Create transaction record
                transaction = Transaction()
                transaction.user_id = user.id
                transaction.transaction_type = 'credit'
                transaction.amount = payment.amount
                transaction.description = f'Payment #{payment.id} - UPI (Telegram) - Bulk Approved'
                
                db.session.add(transaction)
                
                # Notify user via Telegram if they have telegram_id
                if user.telegram_id:
                    try:
                        notify_user_payment_approved(user.id, payment.amount)
                    except Exception as e:
                        app.logger.error(f"Failed to notify Telegram user: {e}")
                
                approved_count += 1
                total_amount += payment.amount
                
        except Exception as e:
            app.logger.error(f"Error approving payment {payment_id}: {e}")
    
    db.session.commit()
    
    flash(f'Successfully approved {approved_count} payments totaling ₹{total_amount:.2f}', 'success')
    return redirect(url_for('admin_telegram_payments'))

@app.route('/admin/telegram-payments/bulk-reject', methods=['POST'])
@admin_required
def bulk_reject_telegram_payments():
    """Bulk reject multiple Telegram payments"""
    payment_ids = request.form.getlist('payment_ids')
    reason = request.form.get('reason', 'Bulk rejection by admin')
    
    if not payment_ids:
        flash('No payments selected for rejection.', 'warning')
        return redirect(url_for('admin_telegram_payments'))
    
    rejected_count = 0
    
    for payment_id in payment_ids:
        try:
            payment = Payment.query.get(int(payment_id))
            if payment and payment.status == 'pending':
                # Update payment status
                payment.status = 'failed'
                payment.notes = reason
                rejected_count += 1
                
        except Exception as e:
            app.logger.error(f"Error rejecting payment {payment_id}: {e}")
    
    db.session.commit()
    
    flash(f'Successfully rejected {rejected_count} payments', 'info')
    return redirect(url_for('admin_telegram_payments'))

@app.route('/admin/telegram-stats')
@admin_required
def admin_telegram_stats():
    """Get Telegram bot statistics"""
    # Get date range
    days = request.args.get('days', 7, type=int)
    
    from datetime import timedelta
    start_date = datetime.utcnow() - timedelta(days=days)
    
    # Get statistics
    stats = {
        'total_users': User.query.filter(User.telegram_id.isnot(None)).count(),
        'new_users': User.query.filter(
            User.telegram_id.isnot(None),
            User.created_at >= start_date
        ).count(),
        'active_users': User.query.filter(
            User.telegram_id.isnot(None),
            User.last_login >= start_date
        ).count(),
        'total_searches': db.session.query(db.func.count(Search.id))\
            .join(User).filter(
                User.telegram_id.isnot(None),
                Search.created_at >= start_date
            ).scalar() or 0,
        'total_revenue': db.session.query(db.func.sum(Payment.amount))\
            .join(User).filter(
                User.telegram_id.isnot(None),
                Payment.status == 'completed',
                Payment.created_at >= start_date
            ).scalar() or 0,
        'pending_payments': Payment.query.join(User).filter(
            User.telegram_id.isnot(None),
            Payment.status == 'pending'
        ).count()
    }
    
    # Get daily stats
    daily_stats = []
    for i in range(days):
        date = (datetime.utcnow() - timedelta(days=i)).date()
        
        day_stats = {
            'date': date.strftime('%Y-%m-%d'),
            'users': User.query.filter(
                User.telegram_id.isnot(None),
                db.func.date(User.created_at) == date
            ).count(),
            'searches': db.session.query(db.func.count(Search.id))\
                .join(User).filter(
                    User.telegram_id.isnot(None),
                    db.func.date(Search.created_at) == date
                ).scalar() or 0,
            'revenue': db.session.query(db.func.sum(Payment.amount))\
                .join(User).filter(
                    User.telegram_id.isnot(None),
                    Payment.status == 'completed',
                    db.func.date(Payment.created_at) == date
                ).scalar() or 0
        }
        
        daily_stats.append(day_stats)
    
    return jsonify({
        'stats': stats,
        'daily': daily_stats
    })

@app.route('/admin/telegram-broadcast', methods=['GET', 'POST'])
@admin_required
def admin_telegram_broadcast():
    """Broadcast message to Telegram users"""
    if request.method == 'POST':
        message = request.form.get('message')
        target = request.form.get('target', 'all')  # all, active, premium
        
        if not message:
            flash('Please enter a message', 'error')
            return redirect(url_for('admin_telegram_broadcast'))
        
        # Get target users
        query = User.query.filter(User.telegram_id.isnot(None))
        
        if target == 'active':
            # Active in last 7 days
            from datetime import timedelta
            week_ago = datetime.utcnow() - timedelta(days=7)
            query = query.filter(User.last_login >= week_ago)
        elif target == 'premium':
            # Users with credits > 1000
            query = query.filter(User.credits > 1000)
        
        users = query.all()
        
        # Send messages
        success_count = 0
        fail_count = 0
        
        from telegram_bot.webhook import application
        import asyncio
        
        for user in users:
            try:
                loop = asyncio.new_event_loop()
                asyncio.set_event_loop(loop)
                loop.run_until_complete(
                    application.bot.send_message(
                        chat_id=user.telegram_id,
                        text=message,
                        parse_mode='Markdown'
                    )
                )
                success_count += 1
            except Exception as e:
                app.logger.error(f"Failed to send to {user.telegram_id}: {e}")
                fail_count += 1
        
        flash(f'Broadcast sent! Success: {success_count}, Failed: {fail_count}', 'success')
        return redirect(url_for('admin_telegram_users'))
    
    # GET request
    total_users = User.query.filter(User.telegram_id.isnot(None)).count()
    
    from datetime import timedelta
    week_ago = datetime.utcnow() - timedelta(days=7)
    active_users = User.query.filter(
        User.telegram_id.isnot(None),
        User.last_login >= week_ago
    ).count()
    
    premium_users = User.query.filter(
        User.telegram_id.isnot(None),
        User.credits > 1000
    ).count()
    
    return render_template('admin/telegram_broadcast.html',
                         total_users=total_users,
                         active_users=active_users,
                         premium_users=premium_users)

@app.route('/admin/telegram-settings', methods=['GET', 'POST'])
@admin_required
def admin_telegram_settings():
    """Manage Telegram bot settings"""
    if request.method == 'POST':
        # Update telegram settings
        SystemSetting.set_value('telegram.bot_enabled', 'bot_enabled' in request.form, 'bool', 'Enable/disable Telegram bot', 'telegram')
        SystemSetting.set_value('telegram.welcome_message', request.form.get('welcome_message', ''), 'string', 'Welcome message for new users', 'telegram')
        SystemSetting.set_value('telegram.help_message', request.form.get('help_message', ''), 'string', 'Help message for users', 'telegram')
        SystemSetting.set_value('telegram.maintenance_mode', 'maintenance_mode' in request.form, 'bool', 'Maintenance mode for bot', 'telegram')
        SystemSetting.set_value('telegram.auto_approve_payments', 'auto_approve_payments' in request.form, 'bool', 'Auto approve telegram payments', 'telegram')
        
        db.session.commit()
        flash('Telegram settings updated successfully!', 'success')
        return redirect(url_for('admin_telegram_settings'))
    
    # Load current settings
    settings = {
        'bot_enabled': SystemSetting.get_value('telegram.bot_enabled', True),
        'welcome_message': SystemSetting.get_value('telegram.welcome_message', 'Welcome to MROSINT! 🔍\n\nUse /help to see available commands.'),
        'help_message': SystemSetting.get_value('telegram.help_message', '/search - Search mobile/aadhar/vehicle\n/balance - Check credits\n/history - View search history\n/payment - Add credits\n/referral - Referral info\n/support - Get help'),
        'maintenance_mode': SystemSetting.get_value('telegram.maintenance_mode', False),
        'auto_approve_payments': SystemSetting.get_value('telegram.auto_approve_payments', False)
    }
    
    return render_template('admin/telegram_settings.html', settings=settings)

@app.route('/admin/telegram-commands')
@admin_required
def admin_telegram_commands():
    """View and manage Telegram bot commands"""
    # Get command usage statistics
    commands_stats = [
        {'command': '/start', 'description': 'Start the bot', 'usage_count': 150, 'last_used': '2 minutes ago'},
        {'command': '/help', 'description': 'Show help message', 'usage_count': 89, 'last_used': '5 minutes ago'},
        {'command': '/search', 'description': 'Perform OSINT search', 'usage_count': 234, 'last_used': '1 minute ago'},
        {'command': '/balance', 'description': 'Check credit balance', 'usage_count': 167, 'last_used': '3 minutes ago'},
        {'command': '/payment', 'description': 'Add credits', 'usage_count': 98, 'last_used': '10 minutes ago'},
        {'command': '/history', 'description': 'View search history', 'usage_count': 76, 'last_used': '7 minutes ago'},
        {'command': '/referral', 'description': 'Referral information', 'usage_count': 45, 'last_used': '15 minutes ago'},
        {'command': '/support', 'description': 'Get support', 'usage_count': 23, 'last_used': '20 minutes ago'},
        {'command': '/admin', 'description': 'Admin commands', 'usage_count': 12, 'last_used': '30 minutes ago'}
    ]
    
    return render_template('admin/telegram_commands.html', commands_stats=commands_stats)

@app.route('/admin/telegram-webhook')
@admin_required
def admin_telegram_webhook():
    """View and manage Telegram webhook status"""
    try:
        from telegram_bot.webhook import get_webhook_info
        webhook_info = get_webhook_info()
        
        # Get webhook statistics
        webhook_stats = {
            'total_updates': 1234,
            'successful_updates': 1220,
            'failed_updates': 14,
            'last_update': '2 minutes ago',
            'uptime': '99.8%',
            'avg_response_time': '45ms'
        }
        
    except Exception as e:
        webhook_info = {'error': str(e)}
        webhook_stats = {}
    
    return render_template('admin/telegram_webhook.html', 
                         webhook_info=webhook_info, 
                         webhook_stats=webhook_stats)