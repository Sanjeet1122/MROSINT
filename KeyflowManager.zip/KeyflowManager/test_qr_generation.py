#!/usr/bin/env python3
"""
Test QR code generation for UPI payments
"""
from utils import generate_qr_code, generate_upi_string

# Test data
upi_id = "9053407823@mbk"
amount = 100.00
payee_name = "MROSINT"
transaction_note = "MROSINT-TEST123"

# Generate UPI string
upi_string = generate_upi_string(
    upi_id=upi_id,
    amount=amount,
    payee_name=payee_name,
    transaction_note=transaction_note
)

print(f"Generated UPI String: {upi_string}")

# Generate QR code
try:
    qr_code_image = generate_qr_code(upi_string)
    print(f"\nQR Code generated successfully!")
    print(f"Data URL Length: {len(qr_code_image)}")
    print(f"First 100 chars: {qr_code_image[:100]}...")
except Exception as e:
    print(f"\nError generating QR code: {e}")