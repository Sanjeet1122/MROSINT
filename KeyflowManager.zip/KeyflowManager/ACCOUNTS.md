# MROSINT Platform Test Accounts

## Admin Account
- **Username**: mrmac
- **Password**: 953146563
- **Role**: Administrator
- **Credits**: 10,000
- **Access**: Full admin panel, user management, settings, security, API management

### Admin Features:
- User management and credit adjustments
- Payment processing and approval
- System settings and pricing configuration
- API key management with encryption
- Security monitoring and fraud detection
- Referral fraud review panel
- Search logs and system monitoring

## Test User Account
- **Username**: testuser
- **Password**: test123
- **Role**: Regular User
- **Credits**: 1,000
- **Referral Code**: SDES3KHZ
- **Access**: Standard user features

## Existing User Account
- **Username**: user1
- **Email**: god63252@gmail.com
- **Credits**: 5.0
- **Role**: Regular User

### User Features:
- Mobile number search (₹99 per search)
- Aadhar verification (₹149 per search)
- Vehicle information lookup (₹49.63 per search)
- UPI payment system for credit top-ups
- Referral system with bonus earnings
- Search history and transaction logs

## How to Access

1. **Admin Panel**: Login with admin credentials, then visit `/admin` or click "Admin Panel" in the dashboard
2. **User Dashboard**: Login with user credentials to access the main platform features
3. **Payment Testing**: Use the UPI payment system with QR codes for exact amounts
4. **Referral Testing**: Use the test user's referral code to test the referral fraud detection system

## Quick Start

1. Login as **testuser** to experience the user interface
2. Try searching for mobile numbers, Aadhar, or vehicle information
3. Test the UPI payment system to add credits
4. Login as **mrmac** to access admin features and manage the platform
5. Check referral fraud detection by creating multiple test registrations

## Security Features to Test

- Military-grade API encryption
- HMAC-SHA256 request signing
- Referral fraud detection system
- Comprehensive security logging
- Admin action tracking