"""
Admin routes for dashboard, API management, and system configuration
"""
from flask import render_template, request, redirect, url_for, flash, session, jsonify
from app import app, db
from models import User, Search, Transaction, Payment, AdminAction, APIKey, SystemSetting, SystemLog, ProtectedNumber, GiftCard
from forms import (APIKeyForm, SystemSettingForm, PaymentApprovalForm, VehicleSearchForm, 
                   PricingForm, UPISettingsForm, AdminUserForm, BonusSettingsForm, SupportReplyForm, AdminEditUserForm)
from security import secure_client
from api_client import api_client
from utils import generate_qr_code, admin_required
from datetime import datetime, timedelta
import json
import os

@app.route('/admin')
@admin_required
def admin_dashboard():
    """Admin dashboard with system overview"""
    # Get system statistics
    total_users = User.query.count()
    active_users = User.query.filter_by(is_active=True).count()
    total_searches = Search.query.count()
    total_revenue = db.session.query(db.func.sum(Payment.amount)).filter_by(status='completed').scalar() or 0
    pending_payments = Payment.query.filter_by(status='pending').count()
    
    # Recent activity
    recent_users = User.query.order_by(User.created_at.desc()).limit(10).all()
    recent_searches = Search.query.order_by(Search.created_at.desc()).limit(10).all()
    recent_payments = Payment.query.order_by(Payment.created_at.desc()).limit(10).all()
    
    # Search statistics by type
    search_stats = db.session.query(
        Search.query_type,
        db.func.count(Search.id).label('count'),
        db.func.sum(Search.credits_used).label('revenue')
    ).group_by(Search.query_type).all()
    
    stats = {
        'total_users': total_users,
        'active_users': active_users,
        'total_searches': total_searches,
        'total_revenue': total_revenue,
        'pending_payments': pending_payments,
        'search_stats': [{'type': s[0], 'count': s[1], 'revenue': s[2] or 0} for s in search_stats]
    }
    
    # Get pending payment notifications
    pending_notifications = Payment.query.filter_by(
        status='pending',
        admin_notified=False
    ).order_by(Payment.created_at.desc()).limit(5).all()
    
    # Mark notifications as seen
    for payment in pending_notifications:
        payment.admin_notified = True
    db.session.commit()
    
    return render_template('admin/dashboard.html', 
                         stats=stats,
                         recent_users=recent_users,
                         recent_searches=recent_searches,
                         recent_payments=recent_payments,
                         pending_notifications=pending_notifications)

@app.route('/admin/api-keys', methods=['GET', 'POST'])
@admin_required
def admin_api_keys():
    """Manage encrypted API keys"""
    form = APIKeyForm()
    
    if form.validate_on_submit():
        try:
            # Encrypt the API key before storing
            encrypted_key = secure_client.encrypt_api_key(form.key_value.data)
            
            api_key = APIKey(
                name=form.name.data,
                service=form.service.data,
                key_value=encrypted_key,
                endpoint_url=form.endpoint_url.data,
                created_by=session['user_id']
            )
            
            db.session.add(api_key)
            db.session.commit()
            
            # Log admin action
            AdminAction.log_action(
                admin_id=session['user_id'],
                action_type='api_key_create',
                description=f'Created API key: {form.name.data} for service {form.service.data}',
                ip_address=request.remote_addr,
                new_values={
                    'name': form.name.data,
                    'service': form.service.data,
                    'endpoint_url': form.endpoint_url.data
                }
            )
            
            # Reload secure client keys
            secure_client._load_encrypted_keys()
            
            flash('API key added successfully and encrypted!', 'success')
            return redirect(url_for('admin_api_keys'))
            
        except Exception as e:
            flash(f'Error encrypting API key: {str(e)}', 'error')
    
    # Get all API keys (without decrypted values)
    api_keys = APIKey.query.order_by(APIKey.created_at.desc()).all()
    
    return render_template('admin/api_keys.html', form=form, api_keys=api_keys)

@app.route('/admin/api-endpoints', methods=['GET', 'POST'])
@admin_required
def admin_api_endpoints():
    """Manage API endpoints configuration"""
    if request.method == 'POST':
        endpoint_type = request.form.get('endpoint_type')
        endpoint_url = request.form.get('endpoint_url')
        
        if endpoint_type and endpoint_url:
            setting = SystemSetting.query.filter_by(key=f'api.{endpoint_type}_endpoint').first()
            if setting:
                setting.value = endpoint_url
            else:
                setting = SystemSetting()
                setting.key = f'api.{endpoint_type}_endpoint'
                setting.value = endpoint_url
                setting.data_type = 'string'
                db.session.add(setting)
            
            db.session.commit()
            flash(f'{endpoint_type.title()} API endpoint updated successfully!', 'success')
        else:
            flash('Please fill all required fields', 'error')
    
    # Get current endpoints
    endpoints = {
        'mobile': SystemSetting.get_value('api.mobile_endpoint', ''),
        'aadhar': SystemSetting.get_value('api.aadhar_endpoint', ''),
        'vehicle': SystemSetting.get_value('api.vehicle_endpoint', '')
    }
    
    return render_template('admin/api_endpoints.html', endpoints=endpoints)

@app.route('/admin/api-test', methods=['GET', 'POST'])
@admin_required
def admin_api_test():
    """Test API connections and functionality"""
    results = {}
    
    if request.method == 'POST':
        test_type = request.form.get('test_type')
        test_query = request.form.get('test_query')
        
        if test_type and test_query:
            try:
                if test_type == 'mobile':
                    results = api_client.search_mobile(test_query, session['user_id'], request.remote_addr)
                elif test_type == 'aadhar':
                    results = api_client.search_aadhar(test_query, session['user_id'], request.remote_addr)
                elif test_type == 'vehicle':
                    results = api_client.search_vehicle(test_query, session['user_id'], request.remote_addr)
                    
                # Log admin test
                AdminAction.log_action(
                    session['user_id'],
                    f'api_test_{test_type}',
                    f'Tested {test_type} API with query: {test_query}',
                    request.remote_addr
                )
                
            except Exception as e:
                results = {
                    'success': False,
                    'error': f'Test failed: {str(e)}'
                }
    
    return render_template('admin/api_test.html', results=results)

@app.route('/admin/account-info')
@admin_required
def admin_account_info():
    """Show admin account information and credentials"""
    return render_template('admin/admin_info.html')

@app.route('/admin/referral-fraud')
@admin_required
def admin_referral_fraud():
    """Manage referral fraud detection"""
    from models import ReferralFraudLog
    
    # Get pending reviews
    pending_reviews = ReferralFraudLog.get_pending_reviews()
    
    # Get recent fraud logs
    recent_logs = ReferralFraudLog.query.order_by(ReferralFraudLog.created_at.desc()).limit(50).all()
    
    # Get fraud statistics
    high_risk_count = ReferralFraudLog.query.filter_by(risk_level='HIGH').filter(ReferralFraudLog.reviewed_at.is_(None)).count()
    medium_risk_count = ReferralFraudLog.query.filter_by(risk_level='MEDIUM').filter(ReferralFraudLog.reviewed_at.is_(None)).count()
    
    return render_template('admin/referral_fraud.html', 
                         pending_reviews=pending_reviews,
                         recent_logs=recent_logs,
                         high_risk_count=high_risk_count,
                         medium_risk_count=medium_risk_count)

@app.route('/admin/referral-fraud/<int:log_id>/review', methods=['POST'])
@admin_required
def admin_review_fraud(log_id):
    """Review and take action on referral fraud case"""
    from models import ReferralFraudLog, AdminAction
    
    fraud_log = ReferralFraudLog.query.get_or_404(log_id)
    action = request.form.get('action')  # cleared, blocked, needs_investigation
    notes = request.form.get('notes', '')
    
    if action in ['cleared', 'blocked', 'needs_investigation']:
        fraud_log.action_taken = action
        fraud_log.reviewed_by = session['user_id']
        fraud_log.reviewed_at = datetime.utcnow()
        
        # If blocking user, deactivate account
        if action == 'blocked':
            user = fraud_log.user
            user.is_active = False
            flash(f'User {user.username} has been blocked for referral fraud.', 'warning')
        
        # Log admin action
        AdminAction.log_action(
            session['user_id'],
            'referral_fraud_review',
            f'Reviewed referral fraud case for user {fraud_log.user.username}: {action}',
            request.remote_addr,
            target_user_id=fraud_log.user_id,
            notes=notes
        )
        
        db.session.commit()
        flash(f'Fraud case reviewed and marked as {action}.', 'success')
    else:
        flash('Invalid action selected.', 'error')
    
    return redirect(url_for('admin_referral_fraud'))

@app.route('/admin/referral-fraud/check-user/<int:user_id>')
@admin_required
def admin_check_user_fraud(user_id):
    """Manually check a user for referral fraud"""
    from models import ReferralFraudLog
    
    fraud_log = ReferralFraudLog.check_and_log_user(user_id)
    
    if fraud_log:
        flash(f'Fraud check completed. Risk level: {fraud_log.risk_level}', 'info')
    else:
        flash('No fraud indicators found for this user.', 'success')
    
    return redirect(url_for('admin_users'))

@app.route('/admin/api-keys/<int:key_id>/toggle')
@admin_required
def toggle_api_key(key_id):
    """Toggle API key active status"""
    api_key = APIKey.query.get_or_404(key_id)
    api_key.is_active = not api_key.is_active
    
    # Log admin action  
    AdminAction.log_action(
        admin_id=session['user_id'],
        action_type='api_key_toggle',
        description=f'{"Activated" if api_key.is_active else "Deactivated"} API key: {api_key.name}',
        ip_address=request.remote_addr,
        old_values={'is_active': not api_key.is_active},
        new_values={'is_active': api_key.is_active}
    )
    db.session.commit()
    
    # Reload secure client keys
    secure_client._load_encrypted_keys()
    
    flash(f'API key {"activated" if api_key.is_active else "deactivated"} successfully!', 'success')
    return redirect(url_for('admin_api_keys'))

@app.route('/admin/api-keys/<int:key_id>/delete')
@admin_required
def delete_api_key(key_id):
    """Delete API key"""
    api_key = APIKey.query.get_or_404(key_id)
    
    # Log admin action
    AdminAction.log_action(
        admin_id=session['user_id'],
        action_type='api_key_delete',
        description=f'Deleted API key: {api_key.name}',
        ip_address=request.remote_addr,
        old_values={
            'name': api_key.name,
            'service': api_key.service,
            'is_active': api_key.is_active
        }
    )
    
    db.session.delete(api_key)
    db.session.commit()
    
    # Reload secure client keys
    secure_client._load_encrypted_keys()
    
    flash('API key deleted successfully!', 'success')
    return redirect(url_for('admin_api_keys'))

@app.route('/admin/pricing', methods=['GET', 'POST'])
@admin_required
def admin_pricing():
    """Manage service pricing"""
    form = PricingForm()
    
    # Load current values
    if request.method == 'GET':
        form.mobile_cost.data = SystemSetting.get_value('search.mobile_cost', 99.0)
        form.aadhar_cost.data = SystemSetting.get_value('search.aadhar_cost', 149.0)
        form.vehicle_cost.data = SystemSetting.get_value('search.vehicle_cost', 49.63)
    
    if form.validate_on_submit():
        old_values = {
            'mobile_cost': SystemSetting.get_value('search.mobile_cost', 99.0),
            'aadhar_cost': SystemSetting.get_value('search.aadhar_cost', 149.0),
            'vehicle_cost': SystemSetting.get_value('search.vehicle_cost', 49.63)
        }
        
        # Update pricing
        SystemSetting.set_value('search.mobile_cost', form.mobile_cost.data, 'float', 'Cost per mobile search', 'pricing')
        SystemSetting.set_value('search.aadhar_cost', form.aadhar_cost.data, 'float', 'Cost per Aadhar search', 'pricing')
        SystemSetting.set_value('search.vehicle_cost', form.vehicle_cost.data, 'float', 'Cost per vehicle search', 'pricing')
        
        new_values = {
            'mobile_cost': form.mobile_cost.data,
            'aadhar_cost': form.aadhar_cost.data,
            'vehicle_cost': form.vehicle_cost.data
        }
        
        # Log admin action
        AdminAction.log_action(
            admin_id=session['user_id'],
            action_type='pricing_update',
            description='Updated service pricing',
            ip_address=request.remote_addr,
            old_values=old_values,
            new_values=new_values
        )
        db.session.commit()
        
        flash('Pricing updated successfully!', 'success')
        return redirect(url_for('admin_pricing'))
    
    return render_template('admin/pricing.html', form=form)

@app.route('/admin/payments', methods=['GET', 'POST'])
@admin_required
def admin_payments():
    """Manage payment approvals"""
    from flask_wtf.csrf import validate_csrf
    from forms import PaymentApprovalForm
    
    # Initialize the form for GET requests
    approval_form = PaymentApprovalForm()
    
    # Debug form submission
    if request.method == 'POST':
        app.logger.info(f"POST request received to /admin/payments")
        app.logger.info(f"Form data: {dict(request.form)}")
        app.logger.info(f"Request headers: {dict(request.headers)}")
        
        # Manually process the form since WTForms might be having issues
        payment_id = request.form.get('payment_id')
        action = request.form.get('action')
        admin_notes = request.form.get('admin_notes', '')
        csrf_token = request.form.get('csrf_token')
        
        app.logger.info(f"Extracted - Payment ID: {payment_id}, Action: {action}, Notes: {admin_notes}")
        
        # Validate CSRF token
        try:
            validate_csrf(csrf_token)
        except Exception as e:
            app.logger.error(f"CSRF validation failed: {e}")
            flash('Security validation failed. Please try again.', 'error')
            return redirect(url_for('admin_payments'))
        
        if payment_id and action in ['approve', 'reject']:
            try:
                payment_id = int(payment_id)
                payment = Payment.query.get_or_404(payment_id)
                
                if action == 'approve' and payment.status == 'pending':
                    # Get user before making changes
                    user = User.query.get(payment.user_id)
                    if not user:
                        flash('User not found for this payment.', 'error')
                        return redirect(url_for('admin_payments'))
                    
                    old_balance = user.credits
                    
                    # Approve payment
                    payment.status = 'completed'
                    payment.completed_at = datetime.utcnow()
                    payment.admin_approved = True
                    payment.admin_approved_by = session['user_id']
                    payment.admin_approved_at = datetime.utcnow()
                    
                    # Generate approval number
                    approval_number = payment.generate_approval_number()
                    
                    # Add credits to user
                    user.credits += payment.credits
                    new_balance = user.credits
                    
                    # Record transaction
                    transaction = Transaction()
                    transaction.user_id = user.id
                    transaction.transaction_type = 'credit'
                    transaction.amount = payment.credits
                    transaction.description = f'Payment approved by admin - {payment.payment_method}'
                    transaction.reference_id = payment.transaction_id
                    db.session.add(transaction)
                    
                    # Log admin action
                    AdminAction.log_action(
                        admin_id=session['user_id'],
                        action_type='payment_approve',
                        target_user_id=payment.user_id,
                        description=f'Approved payment of ₹{payment.amount} for user {user.username}',
                        ip_address=request.remote_addr,
                        old_values={'status': 'pending', 'user_credits': old_balance},
                        new_values={'status': 'completed', 'admin_notes': admin_notes, 'user_credits': new_balance}
                    )
                    
                    # Commit all changes
                    db.session.commit()
                
                    flash(f'Payment approved! ₹{payment.credits} credits added to {user.username}\'s account. Balance: ₹{old_balance} → ₹{new_balance}. Approval Number: {approval_number}', 'success')
                    
                elif action == 'reject' and payment.status == 'pending':
                    user = User.query.get(payment.user_id)
                    
                    # Reject payment
                    payment.status = 'rejected'
                    payment.admin_approved = False
                    payment.admin_approved_by = session['user_id']
                    payment.admin_approved_at = datetime.utcnow()
                    
                    # Log admin action
                    AdminAction.log_action(
                        admin_id=session['user_id'],
                        action_type='payment_reject',
                        target_user_id=payment.user_id,
                        description=f'Rejected payment of ₹{payment.amount} for user {user.username if user else "Unknown"}',
                        ip_address=request.remote_addr,
                        old_values={'status': 'pending'},
                        new_values={'status': 'rejected', 'admin_notes': admin_notes}
                    )
                    
                    # Commit changes
                    db.session.commit()
                
                    flash('Payment rejected.', 'info')
                else:
                    flash(f'Invalid action or payment status. Current status: {payment.status}', 'error')
                    
            except Exception as e:
                db.session.rollback()
                flash(f'Error processing payment: {str(e)}', 'error')
            
        return redirect(url_for('admin_payments'))
    
    # Get payments for approval
    page = request.args.get('page', 1, type=int)
    status_filter = request.args.get('status', 'pending')
    
    payments_query = Payment.query
    if status_filter != 'all':
        payments_query = payments_query.filter_by(status=status_filter)
    
    payments = payments_query.order_by(Payment.created_at.desc()).paginate(
        page=page, per_page=20, error_out=False
    )
    
    return render_template('admin/payments_simple.html', 
                         payments=payments, 
                         approval_form=approval_form,
                         status_filter=status_filter)

@app.route('/admin/payment/<int:payment_id>')
@admin_required
def admin_payment_details(payment_id):
    """View payment details"""
    payment = Payment.query.get_or_404(payment_id)
    return render_template('admin/payment_details.html', payment=payment)

@app.route('/admin/payments/approve/<int:payment_id>')
@admin_required
def admin_approve_payment(payment_id):
    """Approve a single payment"""
    try:
        payment = Payment.query.get_or_404(payment_id)
        
        if payment.status != 'pending':
            flash(f'Payment is already {payment.status}', 'warning')
            return redirect(url_for('admin_payments'))
        
        # Get user
        user = User.query.get(payment.user_id)
        if not user:
            flash('User not found for this payment.', 'error')
            return redirect(url_for('admin_payments'))
        
        old_balance = user.credits
        
        # Approve payment
        payment.status = 'completed'
        payment.completed_at = datetime.utcnow()
        payment.admin_approved = True
        payment.admin_approved_by = session['user_id']
        payment.admin_approved_at = datetime.utcnow()
        
        # Generate approval number
        approval_number = payment.generate_approval_number()
        
        # Add credits to user
        user.credits += payment.credits
        new_balance = user.credits
        
        # Record transaction
        transaction = Transaction()
        transaction.user_id = user.id
        transaction.transaction_type = 'credit'
        transaction.amount = payment.credits
        transaction.description = f'Payment approved by admin - {payment.payment_method}'
        transaction.reference_id = payment.transaction_id
        db.session.add(transaction)
        
        # Log admin action
        AdminAction.log_action(
            admin_id=session['user_id'],
            action_type='payment_approve',
            target_user_id=payment.user_id,
            description=f'Approved payment of ₹{payment.amount} for user {user.username}',
            ip_address=request.remote_addr,
            old_values={'status': 'pending', 'user_credits': old_balance},
            new_values={'status': 'completed', 'user_credits': new_balance}
        )
        
        # Commit all changes
        db.session.commit()
        
        flash(f'✅ Payment approved! ₹{payment.credits} credits added to {user.username}. Balance: ₹{old_balance} → ₹{new_balance}. Approval Number: {approval_number}', 'success')
        
    except Exception as e:
        db.session.rollback()
        flash(f'Error approving payment: {str(e)}', 'error')
    
    return redirect(url_for('admin_payments'))

@app.route('/admin/payments/reject/<int:payment_id>')
@admin_required
def admin_reject_payment(payment_id):
    """Reject a single payment"""
    try:
        payment = Payment.query.get_or_404(payment_id)
        
        if payment.status != 'pending':
            flash(f'Payment is already {payment.status}', 'warning')
            return redirect(url_for('admin_payments'))
        
        user = User.query.get(payment.user_id)
        
        # Reject payment
        payment.status = 'rejected'
        payment.admin_approved = False
        payment.admin_approved_by = session['user_id']
        payment.admin_approved_at = datetime.utcnow()
        
        # Log admin action
        AdminAction.log_action(
            admin_id=session['user_id'],
            action_type='payment_reject',
            target_user_id=payment.user_id,
            description=f'Rejected payment of ₹{payment.amount} for user {user.username if user else "Unknown"}',
            ip_address=request.remote_addr,
            old_values={'status': 'pending'},
            new_values={'status': 'rejected'}
        )
        
        # Commit changes
        db.session.commit()
        
        flash(f'❌ Payment rejected for {user.username if user else "Unknown"}', 'info')
        
    except Exception as e:
        db.session.rollback()
        flash(f'Error rejecting payment: {str(e)}', 'error')
    
    return redirect(url_for('admin_payments'))

@app.route('/admin/payments/bulk-approve', methods=['POST'])
@admin_required
def admin_bulk_approve_payments():
    """Bulk approve all pending payments"""
    try:
        # Get all pending payments
        pending_payments = Payment.query.filter_by(status='pending').all()
        
        if not pending_payments:
            return jsonify({'success': False, 'message': 'No pending payments found.'})
        
        approved_count = 0
        total_credits = 0
        
        for payment in pending_payments:
            # Approve payment
            payment.status = 'completed'
            payment.completed_at = datetime.utcnow()
            payment.admin_approved = True
            payment.admin_approved_by = session['user_id']
            payment.admin_approved_at = datetime.utcnow()
            
            # Generate approval number
            payment.generate_approval_number()
            
            # Add credits to user
            user = User.query.get(payment.user_id)
            if user:
                user.credits += payment.credits
                total_credits += payment.credits
                
                # Record transaction
                transaction = Transaction()
                transaction.user_id = user.id
                transaction.transaction_type = 'credit'
                transaction.amount = payment.credits
                transaction.description = f'Payment approved by admin (bulk) - {payment.payment_method}'
                transaction.reference_id = payment.transaction_id
                db.session.add(transaction)
                
                # Log admin action
                AdminAction.log_action(
                    admin_id=session['user_id'],
                    action_type='payment_bulk_approve',
                    target_user_id=payment.user_id,
                    description=f'Bulk approved payment of ₹{payment.amount} for user {user.username}',
                    ip_address=request.remote_addr,
                    old_values={'status': 'pending'},
                    new_values={'status': 'completed', 'bulk_approval': True}
                )
                
                approved_count += 1
        
        db.session.commit()
        
        return jsonify({
            'success': True, 
            'message': f'Successfully approved {approved_count} payments. Total ₹{total_credits} credits distributed.',
            'approved_count': approved_count,
            'total_credits': total_credits
        })
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'success': False, 'message': f'Error during bulk approval: {str(e)}'})

@app.route('/admin/users', methods=['GET', 'POST'])
@admin_required
def admin_users():
    """Manage users and credits"""
    user_form = AdminUserForm()
    
    if user_form.validate_on_submit():
        user = User.query.get_or_404(user_form.user_id.data)
        action = user_form.action.data
        credits = user_form.credits.data
        reason = user_form.reason.data
        
        old_values = {
            'credits': user.credits,
            'is_active': user.is_active
        }
        
        if action == 'add':
            user.credits += credits
            # Record transaction
            transaction = Transaction()
            transaction.user_id = user.id
            transaction.transaction_type = 'credit'
            transaction.amount = credits
            transaction.description = f'Admin credit addition: {reason}'
            transaction.reference_id = f'admin_{session["user_id"]}_{datetime.utcnow().timestamp()}'
            db.session.add(transaction)
            flash(f'Added ₹{credits} credits to {user.username}\'s account.', 'success')
            
        elif action == 'remove':
            user.credits = max(0, user.credits - credits)
            # Record transaction
            transaction = Transaction()
            transaction.user_id = user.id
            transaction.transaction_type = 'debit'
            transaction.amount = credits
            transaction.description = f'Admin credit deduction: {reason}'
            transaction.reference_id = f'admin_{session["user_id"]}_{datetime.utcnow().timestamp()}'
            db.session.add(transaction)
            flash(f'Removed ₹{credits} credits from {user.username}\'s account.', 'success')
            
        elif action == 'activate':
            user.is_active = True
            flash(f'Activated user {user.username}.', 'success')
            
        elif action == 'deactivate':
            user.is_active = False
            flash(f'Deactivated user {user.username}.', 'warning')
        
        new_values = {
            'credits': user.credits,
            'is_active': user.is_active
        }
        
        # Log admin action
        AdminAction.log_action(
            admin_id=session['user_id'],
            action_type=f'user_{action}',
            target_user_id=user.id,
            description=f'{action.title()} action on user {user.username}: {reason}',
            ip_address=request.remote_addr,
            old_values=old_values,
            new_values=new_values
        )
        db.session.commit()
        
        return redirect(url_for('admin_users'))
    
    # Get users with pagination
    page = request.args.get('page', 1, type=int)
    search = request.args.get('search', '')
    
    users_query = User.query
    if search:
        search_filter = f'%{search}%'
        users_query = users_query.filter(
            db.or_(
                User.username.ilike(search_filter),
                User.email.ilike(search_filter),
                User.full_name.ilike(search_filter)
            )
        )
    
    users = users_query.order_by(User.created_at.desc()).paginate(
        page=page, per_page=20, error_out=False
    )
    
    return render_template('admin/users.html', 
                         users=users, 
                         user_form=user_form,
                         search=search)

@app.route('/admin/users/edit/<int:user_id>', methods=['GET', 'POST'])
@admin_required
def admin_edit_user(user_id):
    """Edit user details including password, credits, and status"""
    user = User.query.get_or_404(user_id)
    form = AdminEditUserForm(user_id=user_id)
    
    if request.method == 'GET':
        # Pre-populate form with current user data
        form.username.data = user.username
        form.email.data = user.email
        form.full_name.data = user.full_name
        form.credits.data = user.credits
        form.is_active.data = user.is_active
        form.is_admin.data = user.is_admin
    
    if form.validate_on_submit():
        # Store old values for logging
        old_values = {
            'username': user.username,
            'email': user.email,
            'full_name': user.full_name,
            'credits': user.credits,
            'is_active': user.is_active,
            'is_admin': user.is_admin
        }
        
        # Update user data
        user.username = form.username.data
        user.email = form.email.data
        user.full_name = form.full_name.data
        old_credits = user.credits
        user.credits = form.credits.data
        user.is_active = form.is_active.data
        user.is_admin = form.is_admin.data
        
        # Update password if provided
        password_changed = False
        if form.new_password.data:
            user.set_password(form.new_password.data)
            password_changed = True
        
        # Create transaction if credits changed
        if old_credits != user.credits:
            credit_diff = user.credits - old_credits
            transaction = Transaction()
            transaction.user_id = user.id
            transaction.transaction_type = 'credit' if credit_diff > 0 else 'debit'
            transaction.amount = abs(credit_diff)
            transaction.description = f'Admin adjustment by {session["username"]} - {form.reason.data}'
            db.session.add(transaction)
        
        # Log admin action
        new_values = {
            'username': user.username,
            'email': user.email,
            'full_name': user.full_name,
            'credits': user.credits,
            'is_active': user.is_active,
            'is_admin': user.is_admin,
            'password_changed': password_changed
        }
        
        AdminAction.log_action(
            admin_id=session['user_id'],
            action_type='user_edit',
            description=f'Edited user {user.username}',
            ip_address=request.remote_addr,
            target_user_id=user.id,
            old_values=old_values,
            new_values=new_values,
            notes=form.reason.data
        )
        
        # Log system event
        SystemLog.log('INFO', 'admin', f'User {user.username} edited by admin {session["username"]}', 
                     session['user_id'], request.remote_addr)
        
        db.session.commit()
        
        flash(f'User {user.username} updated successfully!', 'success')
        return redirect(url_for('admin_view_user', user_id=user.id))
    
    return render_template('admin/edit_user.html', form=form, user=user)

@app.route('/admin/users/view/<int:user_id>')
@admin_required
def admin_view_user(user_id):
    """View complete user details and history"""
    user = User.query.get_or_404(user_id)
    
    # Get user's transaction history
    transactions = Transaction.query.filter_by(user_id=user.id).order_by(Transaction.created_at.desc()).limit(50).all()
    
    # Get user's search history
    searches = Search.query.filter_by(user_id=user.id).order_by(Search.created_at.desc()).limit(50).all()
    
    # Get user's payment history
    payments = Payment.query.filter_by(user_id=user.id).order_by(Payment.created_at.desc()).limit(50).all()
    
    # Get user's gift card redemptions
    gift_cards = GiftCard.query.filter_by(redeemed_by=user.id).order_by(GiftCard.redeemed_at.desc()).all()
    
    # Get admin actions related to this user
    admin_actions = AdminAction.query.filter_by(target_user_id=user.id).order_by(AdminAction.created_at.desc()).limit(20).all()
    
    # Get user's login history and IP addresses from system logs
    login_logs = SystemLog.query.filter_by(
        user_id=user.id,
        category='auth'
    ).filter(
        SystemLog.message.like('%login%')
    ).order_by(SystemLog.created_at.desc()).limit(50).all()
    
    # Get all IP addresses used by the user
    ip_addresses = db.session.query(SystemLog.ip_address, db.func.count(SystemLog.id).label('count')).filter(
        SystemLog.user_id == user.id,
        SystemLog.ip_address.isnot(None)
    ).group_by(SystemLog.ip_address).all()
    
    # Get user's security events
    security_logs = SystemLog.query.filter_by(
        user_id=user.id,
        category='security'
    ).order_by(SystemLog.created_at.desc()).limit(20).all()
    
    # Get user's all system activities
    all_activities = SystemLog.query.filter_by(user_id=user.id).order_by(SystemLog.created_at.desc()).limit(100).all()
    
    # Get user's referral stats
    referral_stats = user.get_referral_stats() if hasattr(user, 'get_referral_stats') else {
        'total_referrals': User.query.filter_by(referred_by_id=user.id).count(),
        'total_earnings': 0
    }
    
    # Get referred users list
    referred_users = User.query.filter_by(referred_by_id=user.id).order_by(User.created_at.desc()).all()
    
    # Calculate total spent and earned
    total_spent = sum(t.amount for t in transactions if t.transaction_type == 'debit')
    total_earned = sum(t.amount for t in transactions if t.transaction_type == 'credit')
    total_searches = len(searches)
    total_paid = sum(p.amount for p in payments if p.status == 'completed')
    
    # Get search statistics by type
    search_stats_by_type = db.session.query(
        Search.query_type,
        db.func.count(Search.id).label('count'),
        db.func.sum(Search.credits_used).label('credits')
    ).filter_by(user_id=user.id).group_by(Search.query_type).all()
    
    # Get user's protected numbers
    protected_numbers = ProtectedNumber.query.filter_by(user_id=user.id).all()
    
    stats = {
        'total_spent': total_spent,
        'total_earned': total_earned,
        'total_searches': total_searches,
        'total_paid': total_paid,
        'referral_count': referral_stats['total_referrals'],
        'referral_earnings': referral_stats.get('total_earnings', 0),
        'search_by_type': [{'type': s[0], 'count': s[1], 'credits': s[2] or 0} for s in search_stats_by_type]
    }
    
    return render_template('admin/view_user.html', 
                         user=user, 
                         transactions=transactions,
                         searches=searches,
                         payments=payments,
                         gift_cards=gift_cards,
                         admin_actions=admin_actions,
                         stats=stats,
                         login_logs=login_logs,
                         ip_addresses=ip_addresses,
                         security_logs=security_logs,
                         all_activities=all_activities,
                         referred_users=referred_users,
                         protected_numbers=protected_numbers)

@app.route('/admin/users/delete/<int:user_id>', methods=['POST'])
@admin_required
def admin_delete_user(user_id):
    """Delete user account (soft delete)"""
    user = User.query.get_or_404(user_id)
    
    if user.is_admin:
        flash('Cannot delete admin users!', 'error')
        return redirect(url_for('admin_users'))
    
    reason = request.form.get('reason', '')
    if not reason:
        flash('Deletion reason is required!', 'error')
        return redirect(url_for('admin_view_user', user_id=user_id))
    
    # Soft delete - deactivate user
    user.is_active = False
    user.username = f"deleted_{user.id}_{user.username}"
    user.email = f"deleted_{user.id}_{user.email}"
    
    # Log admin action
    AdminAction.log_action(
        admin_id=session['user_id'],
        action_type='user_delete',
        description=f'Deleted user {user.username}',
        ip_address=request.remote_addr,
        target_user_id=user.id,
        notes=reason
    )
    
    # Log system event
    SystemLog.log('WARNING', 'admin', f'User {user.username} deleted by admin {session["username"]}', 
                 session['user_id'], request.remote_addr)
    
    db.session.commit()
    
    flash(f'User account deleted successfully!', 'success')
    return redirect(url_for('admin_users'))

@app.route('/admin/settings', methods=['GET', 'POST'])
@admin_required
def admin_settings():
    """System settings management"""
    setting_form = SystemSettingForm()
    upi_form = UPISettingsForm()
    bonus_form = BonusSettingsForm()
    
    # Handle UPI settings form
    if upi_form.validate_on_submit() and request.form.get('form_type') == 'upi':
        old_values = {
            'upi_id': SystemSetting.get_value('payment.upi_id', ''),
            'min_amount': SystemSetting.get_value('payment.min_amount', 100.0),
            'max_amount': SystemSetting.get_value('payment.max_amount', 10000.0),
            'auto_approve': SystemSetting.get_value('payment.auto_approve', False)
        }
        
        # Update UPI settings
        SystemSetting.set_value('payment.upi_id', upi_form.upi_id.data, 'string', 'UPI ID for payments', 'payment')
        SystemSetting.set_value('payment.min_amount', upi_form.min_amount.data, 'float', 'Minimum payment amount', 'payment')
        SystemSetting.set_value('payment.max_amount', upi_form.max_amount.data, 'float', 'Maximum payment amount', 'payment')
        SystemSetting.set_value('payment.auto_approve', upi_form.auto_approve.data, 'bool', 'Auto approve payments', 'payment')
        
        new_values = {
            'upi_id': upi_form.upi_id.data,
            'min_amount': upi_form.min_amount.data,
            'max_amount': upi_form.max_amount.data,
            'auto_approve': upi_form.auto_approve.data
        }
        
        # Log admin action
        AdminAction.log_action(
            admin_id=session['user_id'],
            action_type='upi_settings_update',
            description='Updated UPI payment settings',
            ip_address=request.remote_addr,
            old_values=old_values,
            new_values=new_values
        )
        db.session.commit()
        
        flash('UPI settings updated successfully!', 'success')
        return redirect(url_for('admin_settings'))
    
    # Handle bonus settings form
    if bonus_form.validate_on_submit() and request.form.get('form_type') == 'bonus':
        old_values = {
            'signup_bonus': SystemSetting.get_value('referral.signup_bonus', 500.0),
            'referral_bonus': SystemSetting.get_value('referral.referral_bonus', 50.0),
            'referral_signup_bonus': SystemSetting.get_value('referral.referral_signup_bonus', 25.0)
        }
        
        # Update bonus settings
        SystemSetting.set_value('referral.signup_bonus', bonus_form.signup_bonus.data, 'float', 
                               'Welcome bonus for new users', 'referral')
        SystemSetting.set_value('referral.referral_bonus', bonus_form.referral_bonus.data, 'float',
                               'Bonus for referring new users', 'referral')
        SystemSetting.set_value('referral.referral_signup_bonus', bonus_form.referral_signup_bonus.data, 'float',
                               'Bonus for new users who use referral code', 'referral')
        
        new_values = {
            'signup_bonus': bonus_form.signup_bonus.data,
            'referral_bonus': bonus_form.referral_bonus.data,
            'referral_signup_bonus': bonus_form.referral_signup_bonus.data
        }
        
        # Log admin action
        AdminAction.log_action(
            admin_id=session['user_id'],
            action_type='bonus_settings_update',
            description='Updated bonus settings',
            ip_address=request.remote_addr,
            old_values=old_values,
            new_values=new_values
        )
        db.session.commit()
        
        flash('💰 Bonus settings updated successfully!', 'success')
        return redirect(url_for('admin_settings'))
    
    # Handle system setting form
    if setting_form.validate_on_submit() and request.form.get('form_type') == 'setting':
        old_value = SystemSetting.get_value(setting_form.key.data, '')
        
        SystemSetting.set_value(
            setting_form.key.data,
            setting_form.value.data,
            setting_form.data_type.data,
            setting_form.description.data,
            setting_form.category.data
        )
        
        # Log admin action
        AdminAction.log_action(
            admin_id=session['user_id'],
            action_type='system_setting_update',
            description=f'Updated system setting: {setting_form.key.data}',
            ip_address=request.remote_addr,
            old_values={'value': old_value},
            new_values={'value': setting_form.value.data}
        )
        db.session.commit()
        
        flash('System setting updated successfully!', 'success')
        return redirect(url_for('admin_settings'))
    
    # Load current settings
    if request.method == 'GET':
        # UPI settings
        upi_form.upi_id.data = SystemSetting.get_value('payment.upi_id', 'knoxusdt@paytm')
        upi_form.min_amount.data = SystemSetting.get_value('payment.min_amount', 100.0)
        upi_form.max_amount.data = SystemSetting.get_value('payment.max_amount', 10000.0)
        upi_form.auto_approve.data = SystemSetting.get_value('payment.auto_approve', False)
        
        # Bonus settings
        bonus_form.signup_bonus.data = SystemSetting.get_value('referral.signup_bonus', 500.0)
        bonus_form.referral_bonus.data = SystemSetting.get_value('referral.referral_bonus', 50.0)
        bonus_form.referral_signup_bonus.data = SystemSetting.get_value('referral.referral_signup_bonus', 25.0)
    
    # Get all system settings
    settings = SystemSetting.query.order_by(SystemSetting.category, SystemSetting.key).all()
    settings_by_category = {}
    for setting in settings:
        if setting.category not in settings_by_category:
            settings_by_category[setting.category] = []
        settings_by_category[setting.category].append(setting)
    
    return render_template('admin/settings.html', 
                         setting_form=setting_form,
                         upi_form=upi_form,
                         bonus_form=bonus_form,
                         settings_by_category=settings_by_category)

@app.route('/admin/vehicle-search', methods=['GET', 'POST'])
@admin_required
def admin_vehicle_search():
    """Admin vehicle search interface"""
    form = VehicleSearchForm()
    result = None
    
    if form.validate_on_submit():
        vehicle_number = form.vehicle_number.data.upper()
        result = api_client.search_vehicle(vehicle_number, session['user_id'], request.remote_addr)
        
        # Log admin search
        SystemLog.log('INFO', 'admin', f'Admin vehicle search: {vehicle_number}', 
                     session['user_id'], request.remote_addr)
    
    return render_template('admin/vehicle_search.html', form=form, result=result)

@app.route('/admin/protected-numbers', methods=['GET', 'POST'])
@admin_required
def admin_protected_numbers():
    """Manage protected phone numbers"""
    if request.method == 'POST':
        action = request.form.get('action')
        
        if action == 'add':
            phone_number = request.form.get('phone_number', '').strip()
            reason = request.form.get('reason', '')
            
            # Validate phone number
            import re
            if not re.match(r'^[6-9]\d{9}$', phone_number):
                flash('Invalid phone number format!', 'error')
                return redirect(url_for('admin_protected_numbers'))
            
            # Check if already protected
            existing = ProtectedNumber.query.filter_by(phone_number=phone_number).first()
            if existing:
                existing.is_active = True
                existing.reason = reason
                existing.protected_by_admin = True
                db.session.commit()
                flash(f'Phone number {phone_number} protection updated!', 'success')
            else:
                # Add new protected number
                protected = ProtectedNumber()
                protected.phone_number = phone_number
                protected.protected_by_admin = True
                protected.reason = reason
                protected.protection_fee = 0  # Admin doesn't pay
                db.session.add(protected)
                db.session.commit()
                flash(f'Phone number {phone_number} added to protection list!', 'success')
            
            # Log admin action
            AdminAction.log_action(
                admin_id=session['user_id'],
                action_type='protected_number_add',
                description=f'Added phone {phone_number} to protection list',
                ip_address=request.remote_addr
            )
            
        elif action == 'remove':
            number_id = request.form.get('number_id', type=int)
            protected = ProtectedNumber.query.get(number_id)
            if protected:
                protected.is_active = False
                db.session.commit()
                flash(f'Protection removed for {protected.phone_number}!', 'info')
                
                # Log admin action
                AdminAction.log_action(
                    admin_id=session['user_id'],
                    action_type='protected_number_remove',
                    description=f'Removed protection for {protected.phone_number}',
                    ip_address=request.remote_addr
                )
    
    # Get all protected numbers
    page = request.args.get('page', 1, type=int)
    protected_numbers = ProtectedNumber.query.filter_by(is_active=True).order_by(
        ProtectedNumber.created_at.desc()
    ).paginate(page=page, per_page=50, error_out=False)
    
    return render_template('admin/protected_numbers.html', protected_numbers=protected_numbers)

@app.route('/admin/logs')
@admin_required
def admin_logs():
    """View system logs"""
    page = request.args.get('page', 1, type=int)
    level_filter = request.args.get('level', '')
    category_filter = request.args.get('category', '')
    
    logs_query = SystemLog.query
    
    if level_filter:
        logs_query = logs_query.filter_by(level=level_filter)
    if category_filter:
        logs_query = logs_query.filter_by(category=category_filter)
    
    logs = logs_query.order_by(SystemLog.created_at.desc()).paginate(
        page=page, per_page=50, error_out=False
    )
    
    # Get available filters
    levels = db.session.query(SystemLog.level.distinct()).all()
    categories = db.session.query(SystemLog.category.distinct()).all()
    
    return render_template('admin/logs.html', 
                         logs=logs,
                         levels=[l[0] for l in levels],
                         categories=[c[0] for c in categories],
                         level_filter=level_filter,
                         category_filter=category_filter)

@app.route('/admin/search-logs')
@admin_required 
def admin_search_logs():
    """View detailed search query logs inspired by reference system"""
    try:
        queries_file = 'logs/queries.json'
        queries = []
        if os.path.exists(queries_file):
            with open(queries_file, 'r') as f:
                queries = json.load(f)
        
        # Sort by timestamp descending
        queries.sort(key=lambda x: x.get('timestamp', ''), reverse=True)
        
        return render_template('admin/search_logs.html', queries=queries[:100])
    except Exception as e:
        flash(f'Error loading search logs: {str(e)}', 'error')
        return redirect(url_for('admin_dashboard'))

@app.route('/admin/generate-qr/<int:payment_id>')
@admin_required
def admin_generate_qr(payment_id):
    """Generate QR code for payment"""
    payment = Payment.query.get_or_404(payment_id)
    
    # Use the configured UPI ID (9053407823@mbk)
    upi_id = '9053407823@mbk'
    
    # Format amount to 2 decimal places
    formatted_amount = "{:.2f}".format(float(payment.amount))
    
    # Generate UPI string
    upi_string = f"upi://pay?pa={upi_id}&pn=MROSINT&am={formatted_amount}&cu=INR&tn=MROSINT-{payment.transaction_id[:8]}"
    
    # Generate QR code URL using the free API
    import urllib.parse
    encoded_upi = urllib.parse.quote(upi_string)
    qr_code_url = f"https://api.qrserver.com/v1/create-qr-code/?data={encoded_upi}&size=300x300&color=0-0-0&bgcolor=255-255-255&format=png"
    
    return jsonify({
        'success': True,
        'qr_code_url': qr_code_url,
        'upi_string': upi_string,
        'amount': formatted_amount
    })

@app.route('/admin/api-config')
@admin_required
def admin_api_config():
    """API Configuration Management"""
    import json
    import os
    
    # Load API configuration
    config_path = os.path.join('config', 'api_config.json')
    services = {}
    
    try:
        with open(config_path, 'r') as f:
            services = json.load(f)
    except FileNotFoundError:
        # Create default config if not exists
        os.makedirs('config', exist_ok=True)
        default_config = {
            "mobile_api": {
                "name": "Mobile Number Search",
                "description": "Search mobile number information",
                "base_url": "https://software-jpeg-brochure-knowledgestorm.trycloudflare.com",
                "endpoint": "/search",
                "method": "GET",
                "requires_key": False,
                "active": True,
                "cost": 99.0
            }
        }
        with open(config_path, 'w') as f:
            json.dump(default_config, f, indent=2)
        services = default_config
    
    return render_template('admin/api_config.html', services=services)

@app.route('/admin/api/test', methods=['POST'])
@admin_required
def admin_test_api():
    """Test API service"""
    try:
        from services.api_service import api_service
        
        data = request.get_json()
        service_name = data.get('service')
        test_param = data.get('param')
        
        if not service_name or not test_param:
            return jsonify({
                'success': False,
                'error': 'Service name and test parameter required'
            })
        
        # Prepare test parameters based on service
        if service_name == 'mobile':
            test_params = {'mobile': test_param}
        elif service_name == 'aadhar':
            test_params = {'aadhar': test_param}
        elif service_name == 'vehicle':
            test_params = {'vehicle_number': test_param}
        else:
            test_params = {'query': test_param}
        
        # Test the service
        result = api_service.test_service(service_name, test_params)
        
        return jsonify(result)
        
    except Exception as e:
        return jsonify({
            'success': False,
            'error': f'Test failed: {str(e)}'
        })

@app.route('/admin/api/new-payments')
@admin_required
def admin_api_new_payments():
    """API endpoint to check for new pending payments"""
    from datetime import datetime, timedelta
    
    # Get payments created in the last minute that haven't been notified
    one_minute_ago = datetime.utcnow() - timedelta(minutes=1)
    new_payments = Payment.query.filter(
        Payment.status == 'pending',
        Payment.admin_notified == False,
        Payment.created_at >= one_minute_ago
    ).order_by(Payment.created_at.desc()).all()
    
    # Format payment data
    payment_data = []
    for payment in new_payments:
        # Calculate time ago
        time_diff = datetime.utcnow() - payment.created_at
        if time_diff.seconds < 60:
            time_ago = "Just now"
        else:
            time_ago = f"{time_diff.seconds // 60} minutes ago"
        
        payment_data.append({
            'id': payment.id,
            'username': payment.user.username,
            'amount': float(payment.amount),
            'credits': payment.credits,
            'time_ago': time_ago,
            'transaction_id': payment.transaction_id[:16] + '...'
        })
    
    return jsonify({
        'new_payments': payment_data,
        'count': len(payment_data)
    })
