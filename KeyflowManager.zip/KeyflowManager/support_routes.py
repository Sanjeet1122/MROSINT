"""
Support system routes for user support tickets and Telegram bot integration
"""
from flask import render_template, request, redirect, url_for, flash, session, jsonify
from app import app, db
from models import User, SupportTicket, SupportMessage, SystemSetting, AdminAction
from forms import SupportTicketForm, SupportReplyForm
from datetime import datetime
import requests
import json
import logging

# Telegram Bot configuration
TELEGRAM_BOT_TOKEN = "7577806882:AAHPzM8GY8bSpAqp2hd75hw6cgV5f6jf0zM"
TELEGRAM_BOT_USERNAME = "MROSINT1bot"
TELEGRAM_API_URL = f"https://api.telegram.org/bot{TELEGRAM_BOT_TOKEN}"

def send_telegram_notification(chat_id, message):
    """Send notification via Telegram bot"""
    try:
        url = f"{TELEGRAM_API_URL}/sendMessage"
        data = {
            "chat_id": chat_id,
            "text": message,
            "parse_mode": "HTML"
        }
        response = requests.post(url, data=data, timeout=10)
        return response.json()
    except Exception as e:
        logging.error(f"Telegram notification error: {e}")
        return None

@app.route('/support')
def support_home():
    """Support home page"""
    if 'user_id' not in session:
        flash('Please login to access support.', 'warning')
        return redirect(url_for('login'))
    
    user = User.query.get(session['user_id'])
    if not user:
        flash('User not found.', 'error')
        return redirect(url_for('login'))
    
    tickets = SupportTicket.query.filter_by(user_id=user.id).order_by(SupportTicket.created_at.desc()).all()
    
    return render_template('support/home.html', user=user, tickets=tickets)

@app.route('/support/new', methods=['GET', 'POST'])
def support_new_ticket():
    """Create new support ticket"""
    if 'user_id' not in session:
        flash('Please login to create a support ticket.', 'warning')
        return redirect(url_for('login'))
    
    form = SupportTicketForm()
    
    if form.validate_on_submit():
        user = User.query.get(session['user_id'])
        if not user:
            flash('User not found.', 'error')
            return redirect(url_for('login'))
        
        ticket = SupportTicket(
            user_id=user.id,
            subject=form.subject.data,
            category=form.category.data,
            priority=form.priority.data,
            description=form.description.data,
            status='open'
        )
        
        db.session.add(ticket)
        db.session.commit()
        
        # Create initial message
        message = SupportMessage(
            ticket_id=ticket.id,
            user_id=user.id,
            message=form.description.data,
            is_admin=False
        )
        
        db.session.add(message)
        db.session.commit()
        
        # Notify admins via Telegram
        admin_chat_id = SystemSetting.get_value('telegram.admin_chat_id', '')
        if admin_chat_id:
            notification = f"""🎫 <b>New Support Ticket</b>
            
📋 Ticket #{ticket.id}
👤 User: {user.username}
📧 Email: {user.email}
🏷 Category: {ticket.category}
⚡ Priority: {ticket.priority}
📝 Subject: {ticket.subject}

💬 Message:
{ticket.description[:500]}{'...' if len(ticket.description) > 500 else ''}

🔗 View: https://mrosint.com/admin/support/{ticket.id}
"""
            send_telegram_notification(admin_chat_id, notification)
        
        flash('Support ticket created successfully! We will respond soon.', 'success')
        return redirect(url_for('support_view_ticket', ticket_id=ticket.id))
    
    return render_template('support/new_ticket.html', form=form)

@app.route('/support/ticket/<int:ticket_id>')
def support_view_ticket(ticket_id):
    """View support ticket"""
    if 'user_id' not in session:
        flash('Please login to view support tickets.', 'warning')
        return redirect(url_for('login'))
    
    ticket = SupportTicket.query.get_or_404(ticket_id)
    
    # Check if user owns the ticket or is admin
    if ticket.user_id != session['user_id'] and not session.get('is_admin'):
        flash('You do not have permission to view this ticket.', 'error')
        return redirect(url_for('support_home'))
    
    # Mark as read if user viewing
    if not session.get('is_admin'):
        unread_messages = SupportMessage.query.filter_by(
            ticket_id=ticket.id,
            is_admin=True,
            is_read=False
        ).all()
        
        for msg in unread_messages:
            msg.is_read = True
        
        db.session.commit()
    
    form = SupportReplyForm()
    messages = SupportMessage.query.filter_by(ticket_id=ticket.id).order_by(SupportMessage.created_at).all()
    
    return render_template('support/view_ticket.html', ticket=ticket, messages=messages, form=form)

@app.route('/support/ticket/<int:ticket_id>/reply', methods=['POST'])
def support_reply_ticket(ticket_id):
    """Reply to support ticket"""
    if 'user_id' not in session:
        return jsonify({'error': 'Not authenticated'}), 401
    
    ticket = SupportTicket.query.get_or_404(ticket_id)
    
    # Check permissions
    if ticket.user_id != session['user_id'] and not session.get('is_admin'):
        return jsonify({'error': 'Permission denied'}), 403
    
    form = SupportReplyForm()
    
    if form.validate_on_submit():
        user = User.query.get(session['user_id'])
        if not user:
            return jsonify({'error': 'User not found'}), 404
        
        message = SupportMessage(
            ticket_id=ticket.id,
            user_id=user.id,
            message=form.message.data,
            is_admin=session.get('is_admin', False)
        )
        
        db.session.add(message)
        
        # Update ticket status
        if session.get('is_admin'):
            ticket.status = 'answered'
            ticket.last_admin_reply = datetime.utcnow()
            
            # Notify user via Telegram if connected
            if ticket.user.telegram_id:
                notification = f"""💬 <b>Support Reply</b>

Your ticket #{ticket.id} has a new response from support.

📝 Subject: {ticket.subject}

💭 Reply:
{message.message[:300]}{'...' if len(message.message) > 300 else ''}

🔗 View: https://mrosint.com/support/ticket/{ticket.id}
"""
                send_telegram_notification(ticket.user.telegram_id, notification)
        else:
            ticket.status = 'waiting'
            ticket.last_user_reply = datetime.utcnow()
            
            # Notify admins
            admin_chat_id = SystemSetting.get_value('telegram.admin_chat_id', '')
            if admin_chat_id:
                notification = f"""💬 <b>Ticket Reply</b>

Ticket #{ticket.id} has a new reply from user.

👤 User: {user.username}
📝 Subject: {ticket.subject}

💭 Reply:
{message.message[:300]}{'...' if len(message.message) > 300 else ''}

🔗 View: https://mrosint.com/admin/support/{ticket.id}
"""
                send_telegram_notification(admin_chat_id, notification)
        
        db.session.commit()
        
        return jsonify({
            'success': True,
            'message': {
                'id': message.id,
                'user': user.username,
                'message': message.message,
                'created_at': message.created_at.strftime('%Y-%m-%d %H:%M:%S'),
                'is_admin': message.is_admin
            }
        })
    
    return jsonify({'error': 'Invalid form data'}), 400

@app.route('/support/ticket/<int:ticket_id>/close', methods=['POST'])
def support_close_ticket(ticket_id):
    """Close support ticket"""
    if 'user_id' not in session:
        flash('Please login to manage tickets.', 'warning')
        return redirect(url_for('login'))
    
    ticket = SupportTicket.query.get_or_404(ticket_id)
    
    # Check permissions
    if ticket.user_id != session['user_id'] and not session.get('is_admin'):
        flash('You do not have permission to close this ticket.', 'error')
        return redirect(url_for('support_home'))
    
    ticket.status = 'closed'
    ticket.closed_at = datetime.utcnow()
    ticket.closed_by = session['user_id']
    
    # Log action if admin
    if session.get('is_admin'):
        AdminAction.log_action(
            admin_id=session['user_id'],
            action_type='support_ticket_close',
            description=f'Closed support ticket #{ticket.id}',
            ip_address=request.remote_addr,
            target_user_id=ticket.user_id
        )
    
    db.session.commit()
    
    flash('Ticket closed successfully.', 'success')
    return redirect(url_for('support_view_ticket', ticket_id=ticket.id))

@app.route('/admin/support')
def admin_support_tickets():
    """Admin view all support tickets"""
    if not session.get('is_admin'):
        flash('Admin access required.', 'error')
        return redirect(url_for('login'))
    
    status_filter = request.args.get('status', 'all')
    priority_filter = request.args.get('priority', 'all')
    
    query = SupportTicket.query
    
    if status_filter != 'all':
        query = query.filter_by(status=status_filter)
    
    if priority_filter != 'all':
        query = query.filter_by(priority=priority_filter)
    
    tickets = query.order_by(SupportTicket.created_at.desc()).all()
    
    # Get statistics
    stats = {
        'open': SupportTicket.query.filter_by(status='open').count(),
        'waiting': SupportTicket.query.filter_by(status='waiting').count(),
        'answered': SupportTicket.query.filter_by(status='answered').count(),
        'closed': SupportTicket.query.filter_by(status='closed').count(),
        'high_priority': SupportTicket.query.filter_by(priority='high', status='open').count()
    }
    
    return render_template('admin/support_tickets.html', tickets=tickets, stats=stats)

@app.route('/admin/support/<int:ticket_id>')
def admin_view_support_ticket(ticket_id):
    """Admin view specific support ticket"""
    if not session.get('is_admin'):
        flash('Admin access required.', 'error')
        return redirect(url_for('login'))
    
    ticket = SupportTicket.query.get_or_404(ticket_id)
    
    # Mark admin messages as read
    unread_messages = SupportMessage.query.filter_by(
        ticket_id=ticket.id,
        is_admin=False,
        is_read=False
    ).all()
    
    for msg in unread_messages:
        msg.is_read = True
    
    db.session.commit()
    
    form = SupportReplyForm()
    messages = SupportMessage.query.filter_by(ticket_id=ticket.id).order_by(SupportMessage.created_at).all()
    
    return render_template('admin/view_support_ticket.html', ticket=ticket, messages=messages, form=form)

@app.route('/support/telegram/connect')
def connect_telegram():
    """Connect user account to Telegram"""
    if 'user_id' not in session:
        flash('Please login to connect Telegram.', 'warning')
        return redirect(url_for('login'))
    
    user = User.query.get(session['user_id'])
    
    # Generate connection link
    connect_url = f"https://t.me/{TELEGRAM_BOT_USERNAME}?start={user.id}_{user.referral_code}"
    
    return render_template('support/telegram_connect.html', user=user, connect_url=connect_url)

@app.route('/telegram/webhook', methods=['POST'])
def telegram_webhook():
    """Handle Telegram bot webhook"""
    try:
        data = request.get_json()
        
        if 'message' in data:
            message = data['message']
            chat_id = message['chat']['id']
            text = message.get('text', '')
            
            # Handle /start command
            if text.startswith('/start'):
                parts = text.split(' ')
                if len(parts) > 1:
                    # Connection attempt
                    connection_data = parts[1].split('_')
                    if len(connection_data) == 2:
                        user_id, referral_code = connection_data
                        try:
                            user = User.query.filter_by(id=int(user_id), referral_code=referral_code).first()
                            
                            if user:
                                user.telegram_id = str(chat_id)
                                user.telegram_username = message['from'].get('username', '')
                                db.session.commit()
                                
                                reply = f"""✅ <b>Account Connected!</b>

Your MROSINT account has been successfully connected to Telegram.

👤 Username: {user.username}
📧 Email: {user.email}
💰 Credits: ₹{user.credits}

You will now receive:
• Support ticket updates
• Payment confirmations
• Important notifications

Type /help to see available commands."""
                            else:
                                reply = "❌ Invalid connection link. Please use the link from your MROSINT account."
                        except Exception as e:
                            logging.error(f"Error connecting user: {e}")
                            reply = "❌ Error connecting account. Please try again."
                    else:
                        reply = "❌ Invalid connection format."
                else:
                    reply = """👋 <b>Welcome to MROSINT Support Bot!</b>

To connect your account, please visit:
https://mrosint.com/support/telegram/connect

Available commands:
/help - Show this help message
/balance - Check your credit balance
/tickets - View your support tickets"""
            
            elif text == '/help':
                reply = """📚 <b>MROSINT Support Bot Commands</b>

/start - Start the bot
/help - Show this help message
/balance - Check your credit balance
/tickets - View your support tickets
/support - Create a new support ticket

To connect your account, visit:
https://mrosint.com/support/telegram/connect"""
            
            elif text == '/balance':
                user = User.query.filter_by(telegram_id=str(chat_id)).first()
                if user:
                    reply = f"""💰 <b>Account Balance</b>

Username: {user.username}
Credits: ₹{user.credits}
Total Searches: {user.searches.count()}

Visit https://mrosint.com to add more credits."""
                else:
                    reply = "❌ Please connect your MROSINT account first using /start"
            
            else:
                reply = "❓ Unknown command. Type /help for available commands."
            
            # Send reply
            send_telegram_notification(chat_id, reply)
        
        return jsonify({'ok': True})
    
    except Exception as e:
        logging.error(f"Telegram webhook error: {e}")
        return jsonify({'ok': False, 'error': str(e)}), 500

# Initialize Telegram webhook on startup
def setup_telegram_webhook():
    """Setup Telegram webhook"""
    try:
        # Set webhook URL
        webhook_url = SystemSetting.get_value('telegram.webhook_url', '')
        if webhook_url:
            url = f"{TELEGRAM_API_URL}/setWebhook"
            data = {
                "url": f"{webhook_url}/telegram/webhook",
                "allowed_updates": ["message", "callback_query"]
            }
            response = requests.post(url, data=data)
            if response.json().get('ok'):
                logging.info("Telegram webhook configured successfully")
            else:
                logging.error(f"Failed to set webhook: {response.json()}")
    except Exception as e:
        logging.error(f"Webhook setup error: {e}")

# Call this when app starts
# setup_telegram_webhook()