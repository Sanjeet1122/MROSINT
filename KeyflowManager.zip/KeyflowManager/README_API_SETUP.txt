🔌 SIMPLE API SERVICE SETUP FOR MROSINT

This system allows you to easily add new API services without writing code!

📋 QUICK SETUP STEPS:

1. OPEN CONFIG FILE:
   - Open: config/api_config.json
   - This file contains all API service settings

2. ADD YOUR API SERVICE:
   Copy this template and replace with your details:

   "your_service_api": {
     "name": "Your Service Name",
     "description": "What your service does",
     "base_url": "https://your-api-website.com",
     "endpoint": "/search",
     "method": "GET",
     "requires_key": true,
     "key_header": "X-API-Key",
     "timeout": 30,
     "parameters": {
       "mobile": "phone_number"
     },
     "response_format": "json",
     "cost": 99.0,
     "active": true
   }

3. IF YOUR API NEEDS A KEY:
   - Go to Admin Panel → Settings → System Settings
   - Add new setting:
     * Key: api.your_service.key
     * Value: YOUR_API_KEY_HERE
     * Category: api

4. TEST YOUR API:
   - Go to Admin Panel → API Services
   - Click "Test" button for your service
   - Enter test data to verify it works

5. ACTIVATE SERVICE:
   - Set "active": true in the config file
   - Your service is now ready!

🛠️ API CONFIGURATION EXPLAINED:

- name: Display name shown to users
- base_url: Main website URL of the API
- endpoint: Specific path for the API call
- method: GET or POST
- requires_key: true if API needs authentication
- key_header: Where to put the API key (X-API-Key, Authorization, etc.)
- parameters: Map your search terms to API parameters
- cost: Price in rupees for each search
- active: Set to true to enable the service

📝 EXAMPLES:

MOBILE API (No Key Needed):
{
  "mobile_api": {
    "name": "Mobile Search",
    "base_url": "https://mobile-api.com",
    "endpoint": "/search",
    "method": "GET",
    "requires_key": false,
    "parameters": {
      "mobile": "phone"
    },
    "cost": 99.0,
    "active": true
  }
}

AADHAR API (With Key):
{
  "aadhar_api": {
    "name": "Aadhar Verification",
    "base_url": "https://aadhar-api.com",
    "endpoint": "/verify",
    "method": "POST",
    "requires_key": true,
    "key_header": "Authorization",
    "key_prefix": "Bearer ",
    "parameters": {
      "aadhar": "aadhar_number"
    },
    "cost": 149.0,
    "active": true
  }
}

🔧 NO CODE CHANGES NEEDED!

The system automatically:
- Loads your configuration
- Handles API calls
- Manages authentication
- Processes responses
- Deducts user credits
- Logs all activities

📊 ADMIN FEATURES:

- View all services status
- Test APIs before activation
- Monitor API usage
- Check error logs
- Manage API keys securely

🆘 TROUBLESHOOTING:

❌ API not working?
- Check API key is correct
- Verify endpoint URL
- Test with API provider's documentation
- Check system logs for errors

❌ Wrong response format?
- Verify parameter names match API docs  
- Check if API returns JSON
- Test with small data first

❌ Authentication failed?
- Double-check API key
- Verify key_header setting
- Some APIs use "Bearer " prefix

🔗 HELPFUL LINKS:

- Admin Panel: /admin/api-config
- System Settings: /admin/settings  
- API Testing: /admin/api-config (Test buttons)
- Error Logs: /admin/logs

📞 NEED HELP?

Check the detailed guide in API_SETUP.md for more information!

💡 TIP: Always test your API with small data before making it active!