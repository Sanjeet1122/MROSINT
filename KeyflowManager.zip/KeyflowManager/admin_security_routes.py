"""
Admin security panel routes for monitoring and managing security features
"""
from flask import render_template, request, redirect, url_for, flash, session, jsonify
from app import app, db
from models import User, SystemLog, AdminAction, APIKey, ProtectedNumber
from utils import admin_required
from datetime import datetime, timedelta
from sqlalchemy import desc, func
import json

@app.route('/admin/security')
@admin_required
def admin_security():
    """Security dashboard with monitoring and controls"""
    # Get security statistics
    failed_logins = SystemLog.query.filter_by(log_type='failed_login').count()
    security_incidents = SystemLog.query.filter_by(log_type='security_incident').count()
    api_errors = SystemLog.query.filter_by(log_type='api_error').count()
    
    # Recent security events
    recent_events = db.session.query(SystemLog).filter(
        SystemLog.log_type.in_(['failed_login', 'security_incident', 'api_error'])
    ).order_by(SystemLog.created_at.desc()).limit(20).all()
    
    # Failed login attempts by IP
    failed_by_ip = db.session.query(
        SystemLog.ip_address,
        func.count(SystemLog.id).label('count')
    ).filter_by(log_type='failed_login').group_by(SystemLog.ip_address).order_by(desc('count')).limit(10).all()
    
    # Active API keys count
    active_api_keys = APIKey.query.filter_by(is_active=True).count()
    total_api_keys = APIKey.query.count()
    
    # Protected numbers count
    protected_numbers_count = ProtectedNumber.query.filter_by(is_protected=True).count()
    
    # Admin actions in last 24 hours
    yesterday = datetime.utcnow() - timedelta(days=1)
    recent_admin_actions = AdminAction.query.filter(
        AdminAction.created_at > yesterday
    ).count()
    
    stats = {
        'failed_logins': failed_logins,
        'security_incidents': security_incidents,
        'api_errors': api_errors,
        'active_api_keys': active_api_keys,
        'total_api_keys': total_api_keys,
        'protected_numbers': protected_numbers_count,
        'recent_admin_actions': recent_admin_actions
    }
    
    return render_template('admin/security.html',
                         stats=stats,
                         recent_events=recent_events,
                         failed_by_ip=failed_by_ip)

@app.route('/admin/security/block-ip', methods=['POST'])
@admin_required
def block_ip():
    """Block an IP address"""
    ip_address = request.form.get('ip_address')
    reason = request.form.get('reason', 'Manual block by admin')
    
    if not ip_address:
        flash('IP address is required', 'error')
        return redirect(url_for('admin_security'))
    
    # Log the blocking action
    log = SystemLog(
        log_type='ip_blocked',
        level='warning',
        message=f'IP {ip_address} blocked: {reason}',
        user_id=session.get('user_id'),
        ip_address=ip_address,
        user_agent=request.headers.get('User-Agent'),
        extra_data=json.dumps({'reason': reason, 'blocked_by': session.get('username')})
    )
    db.session.add(log)
    
    # Log admin action
    action = AdminAction(
        admin_id=session['user_id'],
        action_type='security_ip_block',
        description=f'Blocked IP address {ip_address}: {reason}',
        ip_address=request.remote_addr
    )
    db.session.add(action)
    
    db.session.commit()
    flash(f'IP address {ip_address} has been blocked', 'success')
    return redirect(url_for('admin_security'))

@app.route('/admin/security/clear-logs', methods=['POST'])
@admin_required  
def clear_security_logs():
    """Clear old security logs"""
    days = int(request.form.get('days', 30))
    cutoff_date = datetime.utcnow() - timedelta(days=days)
    
    # Delete old logs
    deleted = db.session.query(SystemLog).filter(
        SystemLog.created_at < cutoff_date,
        SystemLog.log_type.in_(['failed_login', 'api_error'])
    ).delete()
    
    # Log the action
    action = AdminAction(
        admin_id=session['user_id'],
        action_type='security_logs_cleared',
        description=f'Cleared {deleted} security logs older than {days} days',
        ip_address=request.remote_addr
    )
    db.session.add(action)
    
    db.session.commit()
    flash(f'Cleared {deleted} security logs older than {days} days', 'success')
    return redirect(url_for('admin_security'))