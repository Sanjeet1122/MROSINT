"""
Anti-interception security module for MROSINT platform
Protects against Burp Suite, OWASP ZAP, and other proxy tools
"""
import hashlib
import hmac
import time
import json
import secrets
import base64
from datetime import datetime, timedelta
from cryptography.fernet import Fernet
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC
from flask import request, session, abort, jsonify
import logging

logger = logging.getLogger(__name__)

class SecurityInterceptor:
    """Advanced security interceptor to prevent request interception"""
    
    def __init__(self):
        self.master_key = self._get_or_generate_master_key()
        self.cipher_suite = Fernet(self.master_key)
        self.active_nonces = {}  # Track active nonces
        self.request_signatures = {}  # Track request signatures
        self.client_fingerprints = {}  # Track legitimate clients
        
    def _get_or_generate_master_key(self):
        """Generate or retrieve master encryption key"""
        import os
        key = os.environ.get('ANTI_INTERCEPT_KEY')
        if not key:
            # Generate a new key for this session
            key = Fernet.generate_key()
            logger.warning("Generated temporary anti-intercept key - set ANTI_INTERCEPT_KEY in production")
        else:
            key = key.encode() if isinstance(key, str) else key
        return key
    
    def generate_client_token(self, user_id, ip_address, user_agent):
        """Generate encrypted client authentication token"""
        timestamp = int(time.time())
        payload = {
            'user_id': user_id,
            'ip': ip_address,
            'ua_hash': hashlib.sha256(user_agent.encode()).hexdigest()[:16],
            'issued_at': timestamp,
            'expires_at': timestamp + 3600  # 1 hour validity
        }
        
        # Encrypt the payload
        encrypted_payload = self.cipher_suite.encrypt(json.dumps(payload).encode())
        token = base64.urlsafe_b64encode(encrypted_payload).decode()
        
        # Store client fingerprint
        fingerprint = self._generate_client_fingerprint(ip_address, user_agent)
        self.client_fingerprints[user_id] = {
            'fingerprint': fingerprint,
            'last_seen': timestamp,
            'token': token
        }
        
        return token
    
    def _generate_client_fingerprint(self, ip_address, user_agent):
        """Generate unique client fingerprint"""
        fingerprint_data = f"{ip_address}:{user_agent}:{int(time.time() // 300)}"  # 5-minute windows
        return hashlib.sha256(fingerprint_data.encode()).hexdigest()
    
    def validate_request_integrity(self, request_data=None):
        """Validate request integrity and detect interception attempts"""
        try:
            # Check for proxy headers that indicate interception
            proxy_headers = [
                'X-Forwarded-For', 'X-Real-IP', 'X-Originating-IP',
                'X-Cluster-Client-IP', 'X-Forwarded-Host',
                'Proxy-Authorization', 'Via', 'X-Forwarded-Proto'
            ]
            
            suspicious_headers = []
            for header in proxy_headers:
                if request.headers.get(header):
                    suspicious_headers.append(header)
            
            # Check for common proxy/interceptor user agents
            user_agent = request.headers.get('User-Agent', '').lower()
            suspicious_uas = [
                'burp', 'owasp', 'zap', 'proxy', 'intercept',
                'tamper', 'fiddler', 'charles', 'mitmproxy'
            ]
            
            ua_suspicious = any(ua in user_agent for ua in suspicious_uas)
            
            # Validate request timing (detect replay attacks)
            timestamp = request.headers.get('X-Request-Time')
            if timestamp:
                try:
                    req_time = int(timestamp)
                    current_time = int(time.time())
                    if abs(current_time - req_time) > 300:  # 5 minute window
                        logger.warning(f"Request timestamp outside valid window: {req_time} vs {current_time}")
                        return False
                except ValueError:
                    logger.warning("Invalid timestamp format in request")
                    return False
            
            # Check request nonce (prevent replay attacks)
            nonce = request.headers.get('X-Request-Nonce')
            if nonce:
                if nonce in self.active_nonces:
                    logger.warning(f"Replay attack detected - duplicate nonce: {nonce}")
                    return False
                self.active_nonces[nonce] = time.time()
                
                # Clean old nonces (older than 1 hour)
                current_time = time.time()
                self.active_nonces = {
                    k: v for k, v in self.active_nonces.items() 
                    if current_time - v < 3600
                }
            
            # Log suspicious activity
            if suspicious_headers or ua_suspicious:
                logger.warning(f"Suspicious request detected - Headers: {suspicious_headers}, UA suspicious: {ua_suspicious}")
                from models import SystemLog
                SystemLog.log('WARNING', 'security', 
                            f'Potential interception attempt detected from {request.remote_addr}',
                            ip_address=request.remote_addr,
                            user_agent=request.headers.get('User-Agent'),
                            extra_data={
                                'suspicious_headers': suspicious_headers,
                                'ua_suspicious': ua_suspicious
                            })
                
                # Don't block immediately, but increase scrutiny
                return 'suspicious'
            
            return True
            
        except Exception as e:
            logger.error(f"Error validating request integrity: {e}")
            return False
    
    def encrypt_response_data(self, data, user_id=None):
        """Encrypt sensitive response data"""
        try:
            if isinstance(data, dict):
                # Only encrypt sensitive fields
                sensitive_fields = ['mobile', 'aadhar', 'name', 'address', 'owner_name']
                encrypted_data = data.copy()
                
                if 'data' in encrypted_data and isinstance(encrypted_data['data'], dict):
                    for field in sensitive_fields:
                        if field in encrypted_data['data'] and encrypted_data['data'][field]:
                            # Encrypt the field value
                            encrypted_value = self.cipher_suite.encrypt(
                                str(encrypted_data['data'][field]).encode()
                            )
                            encrypted_data['data'][field + '_encrypted'] = base64.urlsafe_b64encode(encrypted_value).decode()
                            # Keep original for demo purposes, remove in production
                            # del encrypted_data['data'][field]
                
                # Add integrity hash
                data_hash = hashlib.sha256(json.dumps(data, sort_keys=True).encode()).hexdigest()
                encrypted_data['_integrity_hash'] = data_hash
                encrypted_data['_encrypted'] = True
                
                return encrypted_data
            
            return data
            
        except Exception as e:
            logger.error(f"Error encrypting response data: {e}")
            return data
    
    def generate_request_signature(self, method, url, payload=None, user_id=None):
        """Generate HMAC signature for request validation"""
        timestamp = str(int(time.time()))
        nonce = secrets.token_urlsafe(16)
        
        # Create signature payload
        sig_payload = f"{method}:{url}:{timestamp}:{nonce}"
        if payload:
            if isinstance(payload, dict):
                payload = json.dumps(payload, sort_keys=True)
            sig_payload += f":{payload}"
        
        # Generate HMAC signature
        signature = hmac.new(
            self.master_key,
            sig_payload.encode(),
            hashlib.sha256
        ).hexdigest()
        
        return {
            'timestamp': timestamp,
            'nonce': nonce,
            'signature': signature
        }
    
    def validate_request_signature(self, method, url, signature_data, payload=None):
        """Validate HMAC signature to prevent tampering"""
        try:
            timestamp = signature_data.get('timestamp')
            nonce = signature_data.get('nonce') 
            signature = signature_data.get('signature')
            
            if not all([timestamp, nonce, signature]):
                return False
            
            # Check timestamp validity (5 minute window)
            current_time = int(time.time())
            req_time = int(timestamp)
            if abs(current_time - req_time) > 300:
                logger.warning("Request signature timestamp outside valid window")
                return False
            
            # Check nonce uniqueness
            if nonce in self.active_nonces:
                logger.warning("Duplicate nonce in request signature")
                return False
            
            # Recreate signature payload
            sig_payload = f"{method}:{url}:{timestamp}:{nonce}"
            if payload:
                if isinstance(payload, dict):
                    payload = json.dumps(payload, sort_keys=True)
                sig_payload += f":{payload}"
            
            # Validate signature
            expected_signature = hmac.new(
                self.master_key,
                sig_payload.encode(),
                hashlib.sha256
            ).hexdigest()
            
            if not hmac.compare_digest(signature, expected_signature):
                logger.warning("Request signature validation failed")
                return False
            
            # Store nonce to prevent replay
            self.active_nonces[nonce] = time.time()
            return True
            
        except Exception as e:
            logger.error(f"Error validating request signature: {e}")
            return False
    
    def detect_automation_tools(self, request_obj):
        """Detect automated tools and bots"""
        user_agent = request_obj.headers.get('User-Agent', '').lower()
        
        # Common automation tool signatures
        automation_signatures = [
            'selenium', 'webdriver', 'phantomjs', 'headless',
            'automation', 'bot', 'crawler', 'scraper',
            'requests', 'urllib', 'curl', 'wget',
            'python', 'java', 'go-http-client'
        ]
        
        # Check for automation signatures
        is_automated = any(sig in user_agent for sig in automation_signatures)
        
        # Check for missing browser headers
        browser_headers = ['Accept-Language', 'Accept-Encoding', 'Accept']
        missing_headers = [h for h in browser_headers if not request_obj.headers.get(h)]
        
        # Suspicious if too many browser headers are missing
        suspicious_headers = len(missing_headers) > 1
        
        return {
            'is_automated': is_automated,
            'suspicious_headers': suspicious_headers,
            'missing_headers': missing_headers,
            'user_agent': user_agent
        }
    
    def apply_security_headers(self, response):
        """Apply security headers to prevent interception"""
        # Prevent caching of sensitive data
        response.headers['Cache-Control'] = 'no-store, no-cache, must-revalidate, max-age=0'
        response.headers['Pragma'] = 'no-cache'
        response.headers['Expires'] = '0'
        
        # Content Security Policy
        response.headers['Content-Security-Policy'] = (
            "default-src 'self'; "
            "script-src 'self' 'unsafe-inline' cdnjs.cloudflare.com; "
            "style-src 'self' 'unsafe-inline' cdn.jsdelivr.net cdnjs.cloudflare.com; "
            "font-src 'self' cdnjs.cloudflare.com; "
            "img-src 'self' data:; "
            "connect-src 'self'; "
            "frame-ancestors 'none';"
        )
        
        # Additional security headers
        response.headers['X-Content-Type-Options'] = 'nosniff'
        response.headers['X-Frame-Options'] = 'DENY'
        response.headers['X-XSS-Protection'] = '1; mode=block'
        response.headers['Referrer-Policy'] = 'strict-origin-when-cross-origin'
        response.headers['Permissions-Policy'] = 'geolocation=(), microphone=(), camera=()'
        
        # Custom anti-interception headers
        response.headers['X-Anti-Intercept'] = secrets.token_hex(8)
        response.headers['X-Integrity-Check'] = 'enabled'
        
        return response

# Global security interceptor instance
security_interceptor = SecurityInterceptor()