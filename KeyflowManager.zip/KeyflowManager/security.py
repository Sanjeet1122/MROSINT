"""
Security module for API request encryption and authentication
"""
import os
import hmac
import hashlib
import base64
import json
import time
from cryptography.fernet import Fernet
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC
import secrets
import logging

logger = logging.getLogger(__name__)

class SecureAPIClient:
    """Highly secured API client with encryption and request signing"""
    
    def __init__(self):
        self.master_key = os.environ.get('MASTER_ENCRYPTION_KEY')
        if not self.master_key:
            # Generate a master key if not provided (for development)
            self.master_key = base64.urlsafe_b64encode(os.urandom(32)).decode()
            logger.warning("Using generated master key - set MASTER_ENCRYPTION_KEY in production")
        
        self.cipher_suite = self._init_cipher()
        self.api_keys = {}
        self._load_encrypted_keys()
    
    def _init_cipher(self):
        """Initialize Fernet cipher with master key"""
        key = base64.urlsafe_b64encode(self.master_key.encode()[:32].ljust(32, b'0'))
        return Fernet(key)
    
    def _load_encrypted_keys(self):
        """Load and decrypt API keys from environment or database"""
        try:
            # Try to load from database first
            from models import APIKey
            api_keys = APIKey.query.filter_by(is_active=True).all()
            
            for api_key in api_keys:
                try:
                    decrypted_key = self.decrypt_api_key(api_key.key_value)
                    self.api_keys[api_key.service] = {
                        'key': decrypted_key,
                        'name': api_key.name,
                        'service': api_key.service,
                        'endpoint': api_key.endpoint_url
                    }
                except Exception as e:
                    logger.error(f"Failed to decrypt API key for {api_key.service}: {e}")
            
        except Exception as e:
            logger.error(f"Failed to load API keys from database: {e}")
            # Fallback to environment variables
            self._load_from_env()
    
    def _load_from_env(self):
        """Fallback to load API keys from environment variables"""
        env_keys = {
            'mobile_api': os.environ.get('MOBILE_API_KEY'),
            'aadhar_api': os.environ.get('AADHAR_API_KEY'),
            'vehicle_api': os.environ.get('VEHICLE_API_KEY')
        }
        
        for service, key in env_keys.items():
            if key:
                self.api_keys[service] = {
                    'key': key,
                    'name': f'{service}_key',
                    'service': service,
                    'endpoint': None
                }
    
    def encrypt_api_key(self, api_key):
        """Encrypt an API key for secure storage"""
        try:
            encrypted_key = self.cipher_suite.encrypt(api_key.encode())
            return base64.urlsafe_b64encode(encrypted_key).decode()
        except Exception as e:
            logger.error(f"Failed to encrypt API key: {e}")
            raise
    
    def decrypt_api_key(self, encrypted_key):
        """Decrypt an API key for use"""
        try:
            decoded_key = base64.urlsafe_b64decode(encrypted_key.encode())
            return self.cipher_suite.decrypt(decoded_key).decode()
        except Exception as e:
            logger.error(f"Failed to decrypt API key: {e}")
            raise
    
    def generate_request_signature(self, method, url, payload, timestamp, nonce):
        """Generate HMAC signature for request authentication"""
        # Create string to sign
        string_to_sign = f"{method}\n{url}\n{payload}\n{timestamp}\n{nonce}"
        
        # Use master key for signing
        signature = hmac.new(
            self.master_key.encode(),
            string_to_sign.encode(),
            hashlib.sha256
        ).hexdigest()
        
        return signature
    
    def encrypt_payload(self, data):
        """Encrypt request payload"""
        try:
            json_data = json.dumps(data)
            encrypted_data = self.cipher_suite.encrypt(json_data.encode())
            return base64.urlsafe_b64encode(encrypted_data).decode()
        except Exception as e:
            logger.error(f"Failed to encrypt payload: {e}")
            raise
    
    def decrypt_response(self, encrypted_response):
        """Decrypt API response"""
        try:
            decoded_response = base64.urlsafe_b64decode(encrypted_response.encode())
            decrypted_data = self.cipher_suite.decrypt(decoded_response)
            return json.loads(decrypted_data.decode())
        except Exception as e:
            logger.error(f"Failed to decrypt response: {e}")
            return None
    
    def make_secure_request(self, service, endpoint, data=None, method='POST'):
        """Make a secure API request with encryption and signing"""
        import requests
        
        if service not in self.api_keys:
            raise ValueError(f"API key not found for service: {service}")
        
        api_config = self.api_keys[service]
        api_key = api_config['key']
        
        # Use custom endpoint if provided, otherwise use default
        if endpoint.startswith('http'):
            request_url = endpoint
        else:
            base_url = api_config.get('endpoint', '')
            request_url = f"{base_url.rstrip('/')}/{endpoint.lstrip('/')}" if base_url else endpoint
        
        # Generate request metadata
        timestamp = str(int(time.time()))
        nonce = secrets.token_hex(16)
        
        # Prepare payload
        if data:
            encrypted_payload = self.encrypt_payload(data)
        else:
            encrypted_payload = ""
        
        # Generate signature
        signature = self.generate_request_signature(
            method, request_url, encrypted_payload, timestamp, nonce
        )
        
        # Prepare headers
        headers = {
            'Content-Type': 'application/json',
            'X-API-Key': self._obfuscate_key(api_key),
            'X-Timestamp': timestamp,
            'X-Nonce': nonce,
            'X-Signature': signature,
            'X-Encrypted': 'true',
            'User-Agent': 'MROSINT-SecureClient/1.0'
        }
        
        # Log request (without sensitive data)
        logger.info(f"Making secure request to {service}: {request_url}")
        
        try:
            # Make the request
            if method.upper() == 'POST':
                response = requests.post(
                    request_url,
                    data=json.dumps({'encrypted_data': encrypted_payload}),
                    headers=headers,
                    timeout=30,
                    verify=True  # Always verify SSL certificates
                )
            else:
                response = requests.get(
                    request_url,
                    headers=headers,
                    timeout=30,
                    verify=True
                )
            
            # Log response status
            logger.info(f"Request completed with status: {response.status_code}")
            
            if response.status_code == 200:
                # Try to decrypt response if it's encrypted
                try:
                    response_data = response.json()
                    if 'encrypted_data' in response_data:
                        return self.decrypt_response(response_data['encrypted_data'])
                    else:
                        return response_data
                except json.JSONDecodeError:
                    return {'success': False, 'error': 'Invalid response format'}
            else:
                return {
                    'success': False,
                    'error': f'API request failed with status {response.status_code}',
                    'status_code': response.status_code
                }
                
        except requests.exceptions.RequestException as e:
            logger.error(f"Request failed: {e}")
            return {
                'success': False,
                'error': f'Request failed: {str(e)}'
            }
    
    def _obfuscate_key(self, api_key):
        """Obfuscate API key for transmission (additional security layer)"""
        # Simple obfuscation - in production, use more sophisticated methods
        obfuscated = base64.urlsafe_b64encode(api_key.encode()).decode()
        return f"obf_{obfuscated}"
    
    def validate_request_integrity(self, method, url, payload, timestamp, nonce, signature):
        """Validate incoming request signature"""
        expected_signature = self.generate_request_signature(
            method, url, payload, timestamp, nonce
        )
        
        # Use constant-time comparison to prevent timing attacks
        return hmac.compare_digest(signature, expected_signature)
    
    def get_rate_limit_key(self, user_id, service):
        """Generate rate limiting key"""
        return f"rate_limit:{user_id}:{service}:{int(time.time() // 60)}"
    
    def check_rate_limit(self, user_id, service, max_requests=60):
        """Check if user has exceeded rate limits"""
        # In production, use Redis for distributed rate limiting
        # For now, implement basic in-memory rate limiting
        key = self.get_rate_limit_key(user_id, service)
        
        # This is a simplified implementation
        # In production, implement proper distributed rate limiting
        return True  # Allow all requests for now
    
    def log_security_event(self, event_type, details, user_id=None, ip_address=None):
        """Log security-related events"""
        from models import SystemLog
        
        security_details = {
            'event_type': event_type,
            'details': details,
            'ip_address': ip_address
        }
        
        SystemLog.log(
            'SECURITY', 
            'security', 
            f"Security event: {event_type} - {details}",
            user_id,
            ip_address
        )

# Global secure client instance
secure_client = SecureAPIClient()
