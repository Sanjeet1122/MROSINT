"""
API client for OSINT searches with security and fallback data
"""
import requests
import json
import logging
from datetime import datetime
from security import secure_client
from models import SystemSetting, SystemLog

logger = logging.getLogger(__name__)

class OSINTAPIClient:
    """OSINT API client with secure communication and fallback data"""
    
    def __init__(self):
        self.timeout = None
        self.rate_limit = None
        self._initialized = False
    
    def search(self, search_type, query):
        """Perform search based on type"""
        if search_type == 'mobile':
            return self.search_mobile(query)
        elif search_type == 'aadhar':
            return self.search_aadhar(query)
        elif search_type == 'vehicle':
            return self.search_vehicle(query)
        else:
            return {
                'success': False,
                'error': f'Unknown search type: {search_type}'
            }
    
    def _ensure_initialized(self):
        """Lazy initialization to avoid database access during import"""
        if not self._initialized:
            self.timeout = SystemSetting.get_value('api.timeout', 30)
            self.rate_limit = SystemSetting.get_value('api.rate_limit', 60)
            self._initialized = True
    
    def search_mobile(self, mobile_number, user_id=None, ip_address=None):
        """Search mobile number information using external API"""
        try:
            self._ensure_initialized()
            
            # Check if number is protected
            from models import ProtectedNumber
            if ProtectedNumber.is_protected(mobile_number):
                SystemLog.log('WARNING', 'search', f'Protected number search blocked: {mobile_number}', 
                             user_id, ip_address)
                return {
                    'success': False,
                    'error': '🛡️ CYBER PROTECTED 🛡️\n\nThis number is under MROSINT Protection System.\nDetails are SAFE & SECURE and cannot be accessed.\n\n✅ Protected by Cyber Security Act',
                    'query': mobile_number,
                    'protected': True
                }
            
            # Check rate limit
            if not secure_client.check_rate_limit(user_id, 'mobile', self.rate_limit):
                return {
                    'success': False,
                    'error': 'Rate limit exceeded. Please try again later.',
                    'query': mobile_number
                }
            
            # Log search attempt
            SystemLog.log('INFO', 'search', f'Mobile search initiated: {mobile_number}', 
                         user_id, ip_address)
            
            # Use the external API provided by user
            api_url = f"https://software-jpeg-brochure-knowledgestorm.trycloudflare.com/search?mobile={mobile_number}"
            
            try:
                # Make direct API call
                response = requests.get(api_url, timeout=10)
                response.raise_for_status()
                
                # Parse the response
                api_data = response.json()
                
                if api_data and 'data' in api_data and len(api_data['data']) > 0:
                    # Process the results
                    results = api_data['data']
                    
                    # Return formatted results
                    SystemLog.log('INFO', 'search', f'Mobile search successful: {mobile_number}', 
                                 user_id, ip_address)
                    
                    return {
                        'success': True,
                        'query': mobile_number,
                        'query_type': 'mobile',
                        'data': results,
                        'count': len(results),
                        'timestamp': datetime.utcnow().isoformat(),
                        'is_demo': False
                    }
                else:
                    # No results found
                    return {
                        'success': True,
                        'query': mobile_number,
                        'query_type': 'mobile',
                        'data': [],
                        'count': 0,
                        'message': 'No records found for this mobile number',
                        'timestamp': datetime.utcnow().isoformat(),
                        'is_demo': False
                    }
                    
            except requests.exceptions.RequestException as e:
                SystemLog.log('WARNING', 'search', f'Mobile API call failed: {e}', user_id, ip_address)
                
                # Return error
                return {
                    'success': False,
                    'error': 'Unable to reach search service. Please try again later.',
                    'query': mobile_number
                }
            
        except Exception as e:
            logger.error(f"Mobile search error: {e}")
            SystemLog.log('ERROR', 'search', f'Mobile search failed: {mobile_number} - {str(e)}', 
                         user_id, ip_address)
            return {
                'success': False,
                'error': f'Search failed: {str(e)}',
                'query': mobile_number
            }
    
    def search_aadhar(self, aadhar_number, user_id=None, ip_address=None):
        """Search Aadhar information"""
        try:
            self._ensure_initialized()
            # Check rate limit
            if not secure_client.check_rate_limit(user_id, 'aadhar', self.rate_limit):
                return {
                    'success': False,
                    'error': 'Rate limit exceeded. Please try again later.',
                    'query': aadhar_number
                }
            
            # Log search attempt
            SystemLog.log('INFO', 'search', f'Aadhar search initiated: {aadhar_number[:4]}********', 
                         user_id, ip_address)
            
            # Try secure API call only if endpoint is configured
            endpoint = SystemSetting.get_value('api.aadhar_endpoint', '')
            if endpoint and endpoint.strip():
                try:
                    result = secure_client.make_secure_request(
                        'aadhar_api',
                        endpoint,
                        {'aadhar': aadhar_number, 'user_id': user_id}
                    )
                    
                    if result.get('success'):
                        SystemLog.log('INFO', 'search', f'Aadhar search successful: {aadhar_number[:4]}********', 
                                     user_id, ip_address)
                        return result
                except Exception as e:
                    SystemLog.log('WARNING', 'search', f'Aadhar API call failed: {e}', user_id, ip_address)
            
            # Fallback to demo data
            SystemLog.log('INFO', 'search', f'Aadhar search using demo data: {aadhar_number[:4]}********', 
                         user_id, ip_address)
            
            return {
                'success': True,
                'query': aadhar_number,
                'query_type': 'aadhar',
                'data': {
                    'aadhar': aadhar_number[:4] + '********',
                    'name': 'Jane Smith',
                    'dob': '15/08/1990',
                    'gender': 'Female',
                    'address': 'Demo House, Demo Street, Demo City, Demo State - 123456',
                    'mobile': '9876543210',
                    'status': 'Active (Demo Data)',
                    'details': 'This is demonstration data showing the expected output format.'
                },
                'timestamp': datetime.utcnow().isoformat(),
                'is_demo': True
            }
            
        except Exception as e:
            logger.error(f"Aadhar search error: {e}")
            SystemLog.log('ERROR', 'search', f'Aadhar search failed: {aadhar_number[:4]}******** - {str(e)}', 
                         user_id, ip_address)
            return {
                'success': False,
                'error': f'Search failed: {str(e)}',
                'query': aadhar_number
            }
    
    def search_vehicle(self, vehicle_number, user_id=None, ip_address=None):
        """Search vehicle information"""
        try:
            self._ensure_initialized()
            # Check rate limit
            if not secure_client.check_rate_limit(user_id, 'vehicle', self.rate_limit):
                return {
                    'success': False,
                    'error': 'Rate limit exceeded. Please try again later.',
                    'query': vehicle_number
                }
            
            # Log search attempt
            SystemLog.log('INFO', 'search', f'Vehicle search initiated: {vehicle_number}', 
                         user_id, ip_address)
            
            # Try secure API call only if endpoint is configured
            endpoint = SystemSetting.get_value('api.vehicle_endpoint', '')
            if endpoint and endpoint.strip():
                try:
                    result = secure_client.make_secure_request(
                        'vehicle_api',
                        endpoint,
                        {'vehicle': vehicle_number, 'user_id': user_id}
                    )
                    
                    if result.get('success'):
                        SystemLog.log('INFO', 'search', f'Vehicle search successful: {vehicle_number}', 
                                     user_id, ip_address)
                        return result
                except Exception as e:
                    SystemLog.log('WARNING', 'search', f'Vehicle API call failed: {e}', user_id, ip_address)
            
            # Fallback to demo data
            SystemLog.log('INFO', 'search', f'Vehicle search using demo data: {vehicle_number}', 
                         user_id, ip_address)
            
            return {
                'success': True,
                'query': vehicle_number,
                'query_type': 'vehicle',
                'data': {
                    'registration_number': vehicle_number,
                    'owner_name': 'Demo Owner',
                    'vehicle_class': 'MCWG',
                    'fuel_type': 'PETROL',
                    'manufacture_date': '2020-03-15',
                    'registration_date': '2020-04-01',
                    'insurance_validity': '2025-12-31',
                    'pollution_validity': '2024-06-30',
                    'fitness_validity': '2024-12-31',
                    'status': 'Active (Demo Data)',
                    'details': 'This is demonstration data showing the expected output format.'
                },
                'timestamp': datetime.utcnow().isoformat(),
                'is_demo': True
            }
            
        except Exception as e:
            logger.error(f"Vehicle search error: {e}")
            SystemLog.log('ERROR', 'search', f'Vehicle search failed: {vehicle_number} - {str(e)}', 
                         user_id, ip_address)
            return {
                'success': False,
                'error': f'Search failed: {str(e)}',
                'query': vehicle_number
            }

# Initialize the API client
api_client = OSINTAPIClient()

# Global API client instance
api_client = OSINTAPIClient()
