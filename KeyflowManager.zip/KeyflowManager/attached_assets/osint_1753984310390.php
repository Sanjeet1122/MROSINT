<?php
date_default_timezone_set('Asia/Kolkata');

$admin_ids = ['pasteadminidnumber']; // Telegram allowed admin IDs
$allowed_users = []; // Will be populated with approved users
$token = 'bot token here ';
$api_url = "https://api.telegram.org/bot$token/";
$log_file = 'user_access.log';
$allowed_users_file = 'allowed_users.json';
$search_stats_file = 'search_stats.json';
$user_info_file = 'user_info.json';
$data_api_url = "https://software-jpeg-brochure-knowledgestorm.trycloudflare.com/search";
$vehicle_api_url = "http://6.429.845.20/rc-details/";
$vehicle_api_key = "kevin_1150d25e";

// Load data from files
$allowed_users = file_exists($allowed_users_file) ? json_decode(file_get_contents($allowed_users_file), true) ?? [] : [];
$search_stats = file_exists($search_stats_file) ? json_decode(file_get_contents($search_stats_file), true) ?? [] : [];
$user_info = file_exists($user_info_file) ? json_decode(file_get_contents($user_info_file), true) ?? [] : [];

// Get Telegram update
$update = json_decode(file_get_contents('php://input'), true);
$chat_id = $update['message']['chat']['id'] ?? $update['callback_query']['message']['chat']['id'] ?? null;
$text = $update['message']['text'] ?? $update['callback_query']['data'] ?? null;
$user_name = $update['message']['from']['first_name'] ?? $update['callback_query']['from']['first_name'] ?? 'Unknown';
$user_lastname = $update['message']['from']['last_name'] ?? $update['callback_query']['from']['last_name'] ?? '';
$user_username = $update['message']['from']['username'] ?? $update['callback_query']['from']['username'] ?? 'none';
$full_name = trim("$user_name $user_lastname");

// Store user info if not exists
if (!isset($user_info[$chat_id])) {
    $user_info[$chat_id] = [
        'first_name' => $user_name,
        'last_name' => $user_lastname,
        'username' => $user_username,
        'full_name' => $full_name
    ];
    file_put_contents($user_info_file, json_encode($user_info));
}

// Handle /start command
if ($text === '/start') {
    $welcomeMsg = [
        'chat_id' => $chat_id,
        'text' => "👋 Welcome $full_name!\n\nSend me:\n📱 10-digit mobile number\n🆔 12-digit Aadhar number\n🚗 Vehicle number (e.g. UP14GF2831)\n\nUse /status to check your search stats",
        'parse_mode' => 'HTML',
        'reply_markup' => json_encode([
            'keyboard' => [
                ['/status']
            ],
            'resize_keyboard' => true
        ])
    ];
    sendTelegram($api_url.'sendMessage', $welcomeMsg);
    
    // Initialize user stats if not exists
    if (!isset($search_stats[$chat_id])) {
        $search_stats[$chat_id] = [
            'daily' => ['count' => 0, 'date' => date('Y-m-d')],
            'monthly' => ['count' => 0, 'month' => date('Y-m')],
            'total' => 0
        ];
        file_put_contents($search_stats_file, json_encode($search_stats));
    }
    
    // Notify admin about new user
    if (!in_array($chat_id, $allowed_users) && !in_array($chat_id, $admin_ids)) {
        $requestMsg = [
            'chat_id' => $admin_ids[0],
            'text' => "🆕 New user request:\n\n👤 Name: $full_name (@$user_username)\n🆔 ID: $chat_id\n\nTo approve, send:\n/allow_$chat_id\nTo reject, send:\n/remove_$chat_id",
            'parse_mode' => 'HTML'
        ];
        sendTelegram($api_url.'sendMessage', $requestMsg);
        logAccess($chat_id, "New user requested access");
    }
    exit;
}

// Handle /status command
if ($text === '/status') {
    updateDailyMonthlyStats($chat_id);
    $stats = $search_stats[$chat_id] ?? ['daily' => ['count' => 0], 'monthly' => ['count' => 0], 'total' => 0];
    
    $statusMsg = [
        'chat_id' => $chat_id,
        'text' => "📊 <b>Your Search Stats</b>\n\n"
                . "📅 <b>Today's Searches:</b> {$stats['daily']['count']}\n"
                . "📆 <b>This Month's Searches:</b> {$stats['monthly']['count']}\n"
                . "🔢 <b>Total Searches:</b> {$stats['total']}",
        'parse_mode' => 'HTML',
        'reply_markup' => json_encode([
            'inline_keyboard' => [
                [['text' => '🔄 Refresh', 'callback_data' => '/status']]
            ]
        ])
    ];
    sendTelegram($api_url.'sendMessage', $statusMsg);
    exit;
}

// Handle callback queries
if (isset($update['callback_query'])) {
    $callback_data = $update['callback_query']['data'];
    $message_id = $update['callback_query']['message']['message_id'];
    $chat_id = $update['callback_query']['message']['chat']['id'];
    
    if ($callback_data === '/status') {
        updateDailyMonthlyStats($chat_id);
        $stats = $search_stats[$chat_id] ?? ['daily' => ['count' => 0], 'monthly' => ['count' => 0], 'total' => 0];
        
        sendTelegram($api_url.'editMessageText', [
            'chat_id' => $chat_id,
            'message_id' => $message_id,
            'text' => "📊 <b>Your Search Stats</b>\n\n"
                    . "📅 <b>Today's Searches:</b> {$stats['daily']['count']}\n"
                    . "📆 <b>This Month's Searches:</b> {$stats['monthly']['count']}\n"
                    . "🔢 <b>Total Searches:</b> {$stats['total']}",
            'parse_mode' => 'HTML',
            'reply_markup' => json_encode([
                'inline_keyboard' => [
                    [['text' => '🔄 Refresh', 'callback_data' => '/status']]
                ]
            ])
        ]);
        exit;
    }
}

// Admin commands
if (in_array($chat_id, $admin_ids)) {
    // Handle user approval
    if (strpos($text, '/allow_') === 0) {
        $user_to_allow = str_replace('/allow_', '', $text);
        if (is_numeric($user_to_allow)) {
            if (!in_array($user_to_allow, $allowed_users)) {
                $allowed_users[] = $user_to_allow;
                file_put_contents($allowed_users_file, json_encode($allowed_users));
                
                // Initialize stats for new user
                if (!isset($search_stats[$user_to_allow])) {
                    $search_stats[$user_to_allow] = [
                        'daily' => ['count' => 0, 'date' => date('Y-m-d')],
                        'monthly' => ['count' => 0, 'month' => date('Y-m')],
                        'total' => 0
                    ];
                    file_put_contents($search_stats_file, json_encode($search_stats));
                }
                
                // Get user info
                $user_data = $user_info[$user_to_allow] ?? ['full_name' => 'Unknown', 'username' => 'none'];
                
                // Notify admin
                sendTelegram($api_url.'sendMessage', [
                    'chat_id' => $chat_id,
                    'text' => "✅ User $user_to_allow ({$user_data['full_name']} @{$user_data['username']}) has been approved.",
                    'parse_mode' => 'HTML'
                ]);
                
                // Notify user
                sendTelegram($api_url.'sendMessage', [
                    'chat_id' => $user_to_allow,
                    'text' => "🎉 Your access has been approved by admin!\n\nYou can now send search queries.",
                    'parse_mode' => 'HTML'
                ]);
                
                logAccess($user_to_allow, "Approved by admin $chat_id");
            } else {
                sendTelegram($api_url.'sendMessage', [
                    'chat_id' => $chat_id,
                    'text' => "ℹ️ User $user_to_allow was already approved.",
                    'parse_mode' => 'HTML'
                ]);
            }
        }
        exit;
    }
    
    // Handle user removal
    if (strpos($text, '/remove_') === 0) {
        $user_to_remove = str_replace('/remove_', '', $text);
        if (is_numeric($user_to_remove)) {
            $index = array_search($user_to_remove, $allowed_users);
            if ($index !== false) {
                unset($allowed_users[$index]);
                file_put_contents($allowed_users_file, json_encode(array_values($allowed_users)));
                
                // Get user info
                $user_data = $user_info[$user_to_remove] ?? ['full_name' => 'Unknown', 'username' => 'none'];
                
                // Notify admin
                sendTelegram($api_url.'sendMessage', [
                    'chat_id' => $chat_id,
                    'text' => "❌ User $user_to_remove ({$user_data['full_name']} @{$user_data['username']}) has been removed.",
                    'parse_mode' => 'HTML'
                ]);
                
                // Notify user
                sendTelegram($api_url.'sendMessage', [
                    'chat_id' => $user_to_remove,
                    'text' => "⛔ Your access has been revoked by admin.",
                    'parse_mode' => 'HTML'
                ]);
                
                logAccess($user_to_remove, "Removed by admin $chat_id");
            } else {
                sendTelegram($api_url.'sendMessage', [
                    'chat_id' => $chat_id,
                    'text' => "ℹ️ User $user_to_remove was not in the allowed users list.",
                    'parse_mode' => 'HTML'
                ]);
            }
        }
        exit;
    }
    
    // Handle /users command
    if ($text === '/users') {
        $users_list = "👥 <b>Approved Users List</b> 📋\n\n";
        $users_list .= "🆔 ID | 👤 Name | 🔍 Total Searches\n";
        $users_list .= "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n";
        
        foreach ($allowed_users as $user_id) {
            $user_data = $user_info[$user_id] ?? ['full_name' => 'Unknown', 'username' => 'none'];
            $total_searches = $search_stats[$user_id]['total'] ?? 0;
            
            $users_list .= "🆔 $user_id\n👤 {$user_data['full_name']} (@{$user_data['username']})\n🔍 $total_searches\n━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n";
        }
        
        $reply_markup = [
            'inline_keyboard' => [
                [
                    ['text' => '🔄 Refresh', 'callback_data' => '/users'],
                    ['text' => '🗑️ Remove User', 'callback_data' => '/removeuser']
                ]
            ]
        ];
        
        sendTelegram($api_url.'sendMessage', [
            'chat_id' => $chat_id,
            'text' => $users_list,
            'parse_mode' => 'HTML',
            'reply_markup' => json_encode($reply_markup)
        ]);
        exit;
    }
    
    // Handle callback queries for user management
    if (isset($update['callback_query'])) {
        $callback_data = $update['callback_query']['data'];
        $message_id = $update['callback_query']['message']['message_id'];
        
        if ($callback_data === '/users') {
            // Refresh users list
            $users_list = "👥 <b>Approved Users List</b> 📋\n\n";
            $users_list .= "🆔 ID | 👤 Name | 🔍 Total Searches\n";
            $users_list .= "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n";
            
            foreach ($allowed_users as $user_id) {
                $user_data = $user_info[$user_id] ?? ['full_name' => 'Unknown', 'username' => 'none'];
                $total_searches = $search_stats[$user_id]['total'] ?? 0;
                
                $users_list .= "🆔 $user_id\n👤 {$user_data['full_name']} (@{$user_data['username']})\n🔍 $total_searches\n━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n";
            }
            
            $reply_markup = [
                'inline_keyboard' => [
                    [
                        ['text' => '🔄 Refresh', 'callback_data' => '/users'],
                        ['text' => '🗑️ Remove User', 'callback_data' => '/removeuser']
                    ]
                ]
            ];
            
            sendTelegram($api_url.'editMessageText', [
                'chat_id' => $chat_id,
                'message_id' => $message_id,
                'text' => $users_list,
                'parse_mode' => 'HTML',
                'reply_markup' => json_encode($reply_markup)
            ]);
            exit;
        }
        elseif ($callback_data === '/removeuser') {
            // Create buttons for each user to remove
            $keyboard = [];
            foreach ($allowed_users as $user_id) {
                $user_data = $user_info[$user_id] ?? ['full_name' => 'Unknown', 'username' => 'none'];
                $keyboard[] = [
                    ['text' => "❌ Remove {$user_data['full_name']} (@{$user_data['username']})", 'callback_data' => "/remove_$user_id"]
                ];
            }
            
            // Add back button
            $keyboard[] = [
                ['text' => '🔙 Back to Users', 'callback_data' => '/users']
            ];
            
            sendTelegram($api_url.'editMessageText', [
                'chat_id' => $chat_id,
                'message_id' => $message_id,
                'text' => "🗑️ <b>Select user to remove:</b>",
                'parse_mode' => 'HTML',
                'reply_markup' => json_encode(['inline_keyboard' => $keyboard])
            ]);
            exit;
        }
    }
}

// Access control
if (!in_array($chat_id, $allowed_users) && !in_array($chat_id, $admin_ids)) {
    $denyMsg = [
        'chat_id' => $chat_id,
        'text' => "⏳ Your access is pending admin approval. You'll be notified when approved.",
        'parse_mode' => 'HTML'
    ];
    sendTelegram($api_url.'sendMessage', $denyMsg);
    logAccess($chat_id, "Attempted access without approval");
    exit;
}

// Handle vehicle search (both /vehicle command and direct input)
if (strpos($text, '/vehicle') === 0 || preg_match('/^[A-Z]{2}\d{1,4}[A-Z]{1,3}\d{1,4}$/', $text)) {
    $vehicle_number = strpos($text, '/vehicle') === 0 ? trim(str_replace('/vehicle', '', $text)) : $text;
    $vehicle_number = strtoupper(preg_replace('/\s+/', '', $vehicle_number));
    
    if (empty($vehicle_number)) {
        sendTelegram($api_url.'sendMessage', [
            'chat_id' => $chat_id,
            'text' => "❗ Please provide a vehicle number after /vehicle command\nExample: /vehicle UP14GF2831",
            'parse_mode' => 'HTML'
        ]);
        exit;
    }
    
    // Validate vehicle number format
    if (!preg_match('/^[A-Z]{2}\d{1,4}[A-Z]{1,3}\d{1,4}$/', $vehicle_number)) {
        sendTelegram($api_url.'sendMessage', [
            'chat_id' => $chat_id,
            'text' => "❗ Invalid vehicle number format. Please use format like UP14GF2831",
            'parse_mode' => 'HTML'
        ]);
        exit;
    }
    
    $api_link = $vehicle_api_url . $vehicle_number . "?api_key=" . $vehicle_api_key;
    
    try {
        $response = @file_get_contents($api_link);
        if ($response === FALSE) {
            throw new Exception("Failed to connect to vehicle API server");
        }
        
        $data = json_decode($response, true);
        
        if (isset($data['error'])) {
            throw new Exception($data['error']);
        }
        
        $formatted = formatVehicleData($data);
        updateSearchStats($chat_id);
        
    } catch (Exception $e) {
        $formatted = "⚠️ Error: " . $e->getMessage();
    }
    
    // Send results
    sendTelegram($api_url.'sendMessage', [
        'chat_id' => $chat_id,
        'text' => $formatted,
        'parse_mode' => 'HTML'
    ]);
    
    // Notify admin if user is not admin
    if (!in_array($chat_id, $admin_ids)) {
        $adminResults = "🔍 Vehicle search by @$user_username ($chat_id):\n\n$formatted";
        sendTelegram($api_url.'sendMessage', [
            'chat_id' => $admin_ids[0],
            'text' => $adminResults,
            'parse_mode' => 'HTML'
        ]);
    }
    
    logAccess($chat_id, "Searched for vehicle: $vehicle_number");
    exit;
}

// Handle mobile/aadhar search
if (preg_match('/^[6-9]\d{9}$/', $text)) {
    $type = 'mobile';
    $query = $text;
} elseif (preg_match('/^\d{12}$/', $text)) {
    $type = 'aadhar';
    $query = $text;
} else {
    sendTelegram($api_url.'sendMessage', [
        'chat_id' => $chat_id,
        'text' => "❗ Invalid query. Please send:\n📱 10-digit mobile number\n🆔 12-digit Aadhar number\n🚗 Vehicle number (e.g. UP14GF2831)\n\nOr use /vehicle UP14GF2831",
        'parse_mode' => 'HTML'
    ]);
    exit;
}

// Process mobile/aadhar search
try {
    $api_link = $data_api_url . "?$type=" . urlencode($query);
    $response = @file_get_contents($api_link);
    
    if ($response === FALSE) {
        throw new Exception("Failed to connect to API server");
    }
    
    $formatted = formatData($response, $type);
    updateSearchStats($chat_id);
    
} catch (Exception $e) {
    $formatted = "⚠️ Error: " . $e->getMessage();
}

// Send results
sendTelegram($api_url.'sendMessage', [
    'chat_id' => $chat_id,
    'text' => $formatted,
    'parse_mode' => 'HTML'
]);

// Notify admin if user is not admin
if (!in_array($chat_id, $admin_ids)) {
    $adminResults = "🔍 Search by @$user_username ($chat_id):\n\n$formatted";
    sendTelegram($api_url.'sendMessage', [
        'chat_id' => $admin_ids[0],
        'text' => $adminResults,
        'parse_mode' => 'HTML'
    ]);
}

logAccess($chat_id, "Searched for $type: $query");

// Helper functions
function updateDailyMonthlyStats($user_id) {
    global $search_stats, $search_stats_file;
    
    if (!isset($search_stats[$user_id])) {
        $search_stats[$user_id] = [
            'daily' => ['count' => 0, 'date' => date('Y-m-d')],
            'monthly' => ['count' => 0, 'month' => date('Y-m')],
            'total' => 0
        ];
    }
    
    // Reset daily count if new day
    if ($search_stats[$user_id]['daily']['date'] !== date('Y-m-d')) {
        $search_stats[$user_id]['daily'] = ['count' => 0, 'date' => date('Y-m-d')];
    }
    
    // Reset monthly count if new month
    if ($search_stats[$user_id]['monthly']['month'] !== date('Y-m')) {
        $search_stats[$user_id]['monthly'] = ['count' => 0, 'month' => date('Y-m')];
    }
    
    file_put_contents($search_stats_file, json_encode($search_stats));
}

function updateSearchStats($user_id) {
    global $search_stats, $search_stats_file;
    
    if (!isset($search_stats[$user_id])) {
        $search_stats[$user_id] = [
            'daily' => ['count' => 0, 'date' => date('Y-m-d')],
            'monthly' => ['count' => 0, 'month' => date('Y-m')],
            'total' => 0
        ];
    }
    
    // Update counts
    $search_stats[$user_id]['daily']['count']++;
    $search_stats[$user_id]['monthly']['count']++;
    $search_stats[$user_id]['total']++;
    
    file_put_contents($search_stats_file, json_encode($search_stats));
}

function formatVehicleData($data) {
    if (!isset($data['RegistrationNumber'])) {
        return "❌ No records found for this vehicle number.";
    }
    
    $output = "🚗 <b>Vehicle Details</b> 🚗\n\n";
    $output .= "🆔 <b>Registration Number:</b> " . ($data['VehicleNumber'] ?? 'N/A') . "\n";
    $output .= "📅 <b>Registration Date:</b> " . ($data['RegistrationDate'] ?? 'N/A') . "\n";
    $output .= "⏳ <b>RC Expiry Date:</b> " . ($data['RCExpiryDate'] ?? 'N/A') . "\n";
    $output .= "🟢 <b>Status:</b> " . ($data['VehicleStatus'] ?? 'N/A') . "\n\n";
    
    $output .= "👤 <b>Owner Name:</b> " . ($data['OwnerName'] ?? 'N/A') . "\n";
    $output .= "👨‍👦 <b>Father's Name:</b> " . ($data['FatherName'] ?? 'N/A') . "\n";
    $output .= "📱 <b>Mobile Number:</b> " . ($data['MobileNumber'] ?? 'N/A') . "\n\n";
    
    $output .= "🏠 <b>Address:</b>\n" . formatVehicleAddress($data['PermanentAddress'] ?? 'N/A') . "\n\n";
    
    $output .= "🚘 <b>Vehicle Info:</b>\n";
    $output .= "🔹 <b>Type:</b> " . ($data['VehicleClass'] ?? 'N/A') . "\n";
    $output .= "🔹 <b>Make/Model:</b> " . ($data['MakerDesc'] ?? 'N/A') . " - " . ($data['VehicleModel'] ?? 'N/A') . "\n";
    $output .= "🔹 <b>Fuel Type:</b> " . ($data['Fuel'] ?? 'N/A') . "\n";
    $output .= "🔹 <b>Color:</b> " . ($data['Color'] ?? 'N/A') . "\n";
    $output .= "🔹 <b>Manufacture Date:</b> " . ($data['ManufacturingMonthYear'] ?? 'N/A') . "\n\n";
    
    $output .= "🔧 <b>Technical Details:</b>\n";
    $output .= "🔹 <b>Chassis No:</b> " . ($data['ChasiNo'] ?? 'N/A') . "\n";
    $output .= "🔹 <b>Engine No:</b> " . ($data['EngineNo'] ?? 'N/A') . "\n";
    $output .= "🔹 <b>Seating Capacity:</b> " . ($data['SeatingCapacity'] ?? 'N/A') . "\n";
    $output .= "🔹 <b>Cubic Capacity:</b> " . ($data['CC'] ?? 'N/A') . " cc\n\n";
    
    $output .= "🏢 <b>RTO Details:</b>\n";
    $output .= "🔹 <b>RTO Name:</b> " . ($data['RTOName'] ?? 'N/A') . "\n";
    $output .= "🔹 <b>RTO Code:</b> " . ($data['RTOCode'] ?? 'N/A') . "\n\n";
    
    $output .= "📄 <b>Document Status:</b>\n";
    $output .= "🔹 <b>Insurance:</b> " . ($data['InsuranceCompany'] ?? 'N/A') . " (Valid till: " . ($data['InsuranceUpto'] ?? 'N/A') . ")\n";
    $output .= "🔹 <b>PUCC:</b> Valid till " . ($data['PUCCUpto'] ?? 'N/A') . "\n";
    $output .= "🔹 <b>Tax Paid Upto:</b> " . ($data['TaxPaidUpto'] ?? 'N/A') . "\n\n";
    
    $output .= "🕒 <b>Report Generated:</b> " . date('d M Y, h:i A');
    
    return $output;
}

function formatVehicleAddress($address) {
    if (empty($address)) return 'N/A';
    $formatted = preg_replace('/\s+/', ' ', $address);
    $formatted = trim($formatted);
    $formatted = preg_replace('/(\d{6})$/', "Pincode: $1", $formatted);
    return ucwords(strtolower($formatted));
}

function formatData($json, $searchType) {
    $data = json_decode($json, true);
    
    if (!isset($data['data']) || !is_array($data['data']) || count($data['data']) === 0) {
        return "🔍 No records found for this $searchType number.";
    }

    $output = "🔎 <b>Search Results</b> 🔍\n\n";
    $output .= "📌 <b>Search Type:</b> " . ($searchType === 'mobile' ? 'Mobile Number' : 'Aadhar Number') . "\n";
    $output .= "🕒 <b>Date:</b> " . date('d M Y, h:i A') . "\n\n";
    $output .= "📊 <b>Total Records Found:</b> " . count($data['data']) . "\n\n";
    $output .= "━━━━━━━━━━━━━━━━━━━━\n\n";

    $recordCount = 1;
    foreach ($data['data'] as $entry) {
        $output .= "📌 <b>Record #$recordCount</b>\n";
        $output .= "👤 <b>Full Name:</b> " . ($entry['name'] ?? 'Not Available') . "\n";
        $output .= "📱 <b>Mobile Number:</b> " . ($entry['mobile'] ?? 'Not Available') . "\n";
        
        if (isset($entry['alt']) && !empty($entry['alt'])) {
            $output .= "📱 <b>Alternative Number:</b> " . $entry['alt'] . "\n";
        }
        
        if (isset($entry['email']) && !empty($entry['email'])) {
            $output .= "📧 <b>Email:</b> " . $entry['email'] . "\n";
        }
        
        $output .= "👨‍👦 <b>Father's Name:</b> " . ($entry['fname'] ?? 'Not Available') . "\n";
        $output .= "🆔 <b>Aadhar Number:</b> " . ($entry['id'] ?? 'Not Available') . "\n";
        
        if (isset($entry['address'])) {
            $address = formatAddress($entry['address']);
            $output .= "🏠 <b>Address:</b>\n" . $address . "\n";
        }
        
        $output .= "🌐 <b>Telecom Circle:</b> " . ($entry['circle'] ?? 'Not Available') . "\n";
        $output .= "━━━━━━━━━━━━━━━━━━━━\n\n";
        $recordCount++;
    }
    
    $output .= "📌 <b>Note:</b> This information is provided for reference purposes only.\n";
    $output .= "🕒 <b>Report Generated:</b> " . date('d M Y, h:i A');
    
    return $output;
}

function formatAddress($address) {
    $formatted = str_replace(["!!", "!"], "\n", $address);
    $formatted = preg_replace('/\s+/', ' ', $formatted);
    $formatted = trim($formatted);
    $formatted = preg_replace('/(\d{6})$/', "Pincode: $1", $formatted);
    $lines = explode("\n", $formatted);
    $lines = array_map('ucwords', $lines);
    return implode("\n", $lines);
}

function sendTelegram($url, $params) {
    $query = http_build_query($params);
    @file_get_contents("$url?$query");
}

function logAccess($user_id, $action) {
    global $log_file;
    $timestamp = date('Y-m-d H:i:s');
    $log_entry = "[$timestamp] User $user_id - $action\n";
    file_put_contents($log_file, $log_entry, FILE_APPEND);
}