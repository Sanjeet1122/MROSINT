from app import db
from datetime import datetime
from werkzeug.security import generate_password_hash, check_password_hash

class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(64), unique=True, nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)
    password_hash = db.Column(db.String(256), nullable=False)
    full_name = db.Column(db.String(100), nullable=False)
    credits = db.Column(db.Float, default=0.0)
    is_admin = db.Column(db.Boolean, default=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    is_active = db.Column(db.Boolean, default=True)
    
    # Referral system fields
    referral_code = db.Column(db.String(20), unique=True, nullable=True)
    referred_by_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=True)
    total_referrals = db.Column(db.Integer, default=0)
    referral_earnings = db.Column(db.Float, default=0.0)
    
    # Relationships
    searches = db.relationship('Search', backref='user', lazy=True)
    transactions = db.relationship('Transaction', backref='user', lazy=True)
    payments = db.relationship('Payment', backref='user', lazy=True)
    referrals = db.relationship('User', backref=db.backref('referrer', remote_side=[id]), lazy=True)
    
    def set_password(self, password):
        self.password_hash = generate_password_hash(password)
    
    def check_password(self, password):
        return check_password_hash(self.password_hash, password)
    
    def get_search_stats(self):
        from sqlalchemy import func
        today = datetime.now().date()
        this_month = datetime.now().replace(day=1).date()
        
        # Today's searches
        today_searches = Search.query.filter(
            Search.user_id == self.id,
            func.date(Search.created_at) == today
        ).count()
        
        # This month's searches
        month_searches = Search.query.filter(
            Search.user_id == self.id,
            func.date(Search.created_at) >= this_month
        ).count()
        
        # Total searches
        total_searches = Search.query.filter_by(user_id=self.id).count()
        
        return {
            'today': today_searches,
            'month': month_searches,
            'total': total_searches
        }
    
    def generate_referral_code(self):
        """Generate a unique referral code for the user"""
        import random
        import string
        
        if self.referral_code:
            return self.referral_code
        
        while True:
            # Generate 8-character alphanumeric code
            code = ''.join(random.choices(string.ascii_uppercase + string.digits, k=8))
            # Check if code already exists
            if not User.query.filter_by(referral_code=code).first():
                self.referral_code = code
                db.session.commit()
                return code
    
    def get_referral_stats(self):
        """Get referral statistics for the user"""
        return {
            'total_referrals': self.total_referrals,
            'total_earnings': self.referral_earnings,
            'referral_code': self.referral_code or self.generate_referral_code(),
            'recent_referrals': User.query.filter_by(referred_by_id=self.id).order_by(User.created_at.desc()).limit(5).all()
        }

class Search(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    query_type = db.Column(db.String(20), nullable=False)  # mobile, aadhar, vehicle
    query_value = db.Column(db.String(100), nullable=False)
    result_data = db.Column(db.Text)
    credits_used = db.Column(db.Float, nullable=False)
    status = db.Column(db.String(20), default='completed')  # completed, failed, pending
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

class Transaction(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    transaction_type = db.Column(db.String(20), nullable=False)  # credit, debit
    amount = db.Column(db.Float, nullable=False)
    description = db.Column(db.String(200))
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

class Payment(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    amount = db.Column(db.Float, nullable=False)
    credits = db.Column(db.Float, nullable=False)
    payment_method = db.Column(db.String(50), nullable=False)
    transaction_id = db.Column(db.String(100), unique=True)
    status = db.Column(db.String(20), default='pending')  # pending, completed, failed
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
class AdminAction(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    admin_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    action = db.Column(db.String(100), nullable=False)
    target_user_id = db.Column(db.Integer, db.ForeignKey('user.id'))
    details = db.Column(db.Text)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    admin = db.relationship('User', foreign_keys=[admin_id])
    target_user = db.relationship('User', foreign_keys=[target_user_id])

class SystemSetting(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    key = db.Column(db.String(100), unique=True, nullable=False)
    value = db.Column(db.Text)
    description = db.Column(db.String(200))
    category = db.Column(db.String(50), default='general')
    data_type = db.Column(db.String(20), default='string')  # string, number, boolean, json
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    updated_by = db.Column(db.Integer, db.ForeignKey('user.id'))
    
    updater = db.relationship('User', foreign_keys=[updated_by])
    
    @classmethod
    def get_value(cls, key, default=None):
        setting = cls.query.filter_by(key=key).first()
        if not setting:
            return default
        
        if setting.data_type == 'boolean':
            return setting.value.lower() in ['true', '1', 'yes']
        elif setting.data_type == 'number':
            try:
                return float(setting.value)
            except (ValueError, TypeError):
                return default
        elif setting.data_type == 'json':
            try:
                import json
                return json.loads(setting.value)
            except (ValueError, TypeError):
                return default
        return setting.value
    
    @classmethod
    def set_value(cls, key, value, admin_id, description=None, category='general', data_type='string'):
        setting = cls.query.filter_by(key=key).first()
        if setting:
            setting.value = str(value)
            setting.updated_by = admin_id
            setting.updated_at = datetime.utcnow()
        else:
            setting = cls(
                key=key,
                value=str(value),
                description=description,
                category=category,
                data_type=data_type,
                updated_by=admin_id
            )
            db.session.add(setting)
        db.session.commit()
        return setting

class APIKey(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    service = db.Column(db.String(50), nullable=False)  # osint_mobile, osint_aadhar, osint_vehicle, payment
    key_value = db.Column(db.Text, nullable=False)
    is_active = db.Column(db.Boolean, default=True)
    description = db.Column(db.String(200))
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    created_by = db.Column(db.Integer, db.ForeignKey('user.id'))
    
    creator = db.relationship('User', foreign_keys=[created_by])

class SystemLog(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    level = db.Column(db.String(20), nullable=False)  # INFO, WARNING, ERROR, CRITICAL
    category = db.Column(db.String(50), nullable=False)  # auth, search, payment, admin, system
    message = db.Column(db.Text, nullable=False)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'))
    ip_address = db.Column(db.String(45))
    user_agent = db.Column(db.String(500))
    additional_data = db.Column(db.Text)  # JSON data
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    user = db.relationship('User', foreign_keys=[user_id])
    
    @classmethod
    def log(cls, level, category, message, user_id=None, ip_address=None, user_agent=None, additional_data=None):
        log_entry = cls(
            level=level,
            category=category,
            message=message,
            user_id=user_id,
            ip_address=ip_address,
            user_agent=user_agent,
            additional_data=additional_data
        )
        db.session.add(log_entry)
        db.session.commit()
        return log_entry

class Notification(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'))
    title = db.Column(db.String(200), nullable=False)
    message = db.Column(db.Text, nullable=False)
    type = db.Column(db.String(20), default='info')  # info, success, warning, error
    is_read = db.Column(db.Boolean, default=False)
    is_global = db.Column(db.Boolean, default=False)  # Send to all users
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    created_by = db.Column(db.Integer, db.ForeignKey('user.id'))
    
    user = db.relationship('User', foreign_keys=[user_id])
    creator = db.relationship('User', foreign_keys=[created_by])
