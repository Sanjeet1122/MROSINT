# MROSINT Anti-Interception Security Features

## Overview

MROSINT platform implements military-grade security measures to prevent request interception attacks from tools like Burp Suite, OWASP ZAP, Fiddler, Charles Proxy, and other proxy/debugging tools.

## Security Layers

### 1. Server-Side Protection (`security_interceptor.py`)

#### Request Validation
- **Proxy Header Detection**: Identifies common proxy headers (X-Forwarded-For, Via, Proxy-Authorization)
- **User Agent Analysis**: Detects automation tools and suspicious browser signatures
- **Timestamp Validation**: Prevents replay attacks with 5-minute request windows
- **Nonce System**: Unique request identifiers prevent request duplication
- **HMAC-SHA256 Signing**: Cryptographic request integrity verification

#### Automation Detection
- **Tool Signatures**: Detects Burp Suite, OWASP ZAP, Selenium, WebDriver, and other automation tools
- **Header Analysis**: Identifies missing browser headers typical of automated requests
- **Rate Limiting**: Built-in protection against rapid automated requests

#### Response Protection
- **Data Encryption**: Sensitive fields encrypted with AES-256 before transmission
- **Integrity Hashing**: SHA-256 hashes verify response data integrity
- **Security Headers**: Comprehensive security headers prevent caching and inspection

### 2. Client-Side Protection (`anti_intercept.js`)

#### Browser Fingerprinting
- **Canvas Fingerprinting**: Unique browser canvas signatures
- **Environment Detection**: Screen resolution, timezone, language, platform analysis
- **Real-time Monitoring**: Continuous security checks every 30 seconds

#### Interception Detection
- **Developer Tools**: Detects F12, Ctrl+Shift+I, inspect element usage
- **Network Timing**: Identifies unusual network delays indicating proxies
- **DOM Modification**: Monitors for external tool DOM manipulation
- **Console Activity**: Detects suspicious console commands and debugging

#### Request Protection
- **Automatic Headers**: Adds security headers to all outgoing requests
- **Form Encryption**: Encrypts sensitive form data before submission
- **Nonce Generation**: Client-side nonce generation for request uniqueness

### 3. Advanced Security Features

#### Multi-Layer Detection
- **Threshold System**: Requires multiple indicators before blocking (reduces false positives)
- **Graduated Response**: Suspicious activity logged but allowed, definite threats blocked
- **Incident Reporting**: Real-time security incident logging to server

#### Anti-Debugging
- **Function Protection**: Prevents console.log manipulation
- **Context Menu Blocking**: Disables right-click inspect element
- **Debugger Detection**: Multiple techniques to detect active debuggers
- **Performance Monitoring**: Detects execution delays from debugging tools

## Implementation Details

### Security Headers Applied
```
Cache-Control: no-store, no-cache, must-revalidate, max-age=0
Content-Security-Policy: default-src 'self'; script-src 'self' 'unsafe-inline' cdnjs.cloudflare.com
X-Content-Type-Options: nosniff
X-Frame-Options: DENY
X-XSS-Protection: 1; mode=block
Referrer-Policy: strict-origin-when-cross-origin
X-Anti-Intercept: [random-token]
X-Integrity-Check: enabled
```

### Request Validation Process
1. Check for proxy headers in incoming request
2. Analyze User-Agent for automation signatures
3. Validate request timestamp within 5-minute window
4. Verify nonce uniqueness (prevent replay attacks)
5. Check HMAC-SHA256 signature for tampering
6. Log suspicious activity to SystemLog
7. Block or allow with monitoring based on threat level

### Client-Side Monitoring
1. Generate unique browser fingerprint on page load
2. Monitor for developer tools activation
3. Detect unusual network timing patterns
4. Check for DOM modifications by external tools
5. Report security incidents to server endpoint
6. Encrypt sensitive form data before submission

## Tools Detected and Blocked

### Proxy/Interception Tools
- Burp Suite Professional/Community
- OWASP ZAP
- Fiddler Classic/Everywhere
- Charles Proxy
- mitmproxy
- HTTP Toolkit

### Automation Tools
- Selenium WebDriver
- Puppeteer
- PhantomJS
- Playwright
- requests (Python)
- curl/wget

### Browser Tools
- Developer Tools (F12)
- Network Inspector
- Console Debugger
- Element Inspector
- Source Debugger

## Security Incident Response

### Automatic Actions
1. **Suspicious Activity**: Log incident, allow with monitoring
2. **Definite Threat**: Block request, redirect to security warning
3. **Critical Threat**: Complete access denial, security team notification

### Logging Details
- IP address and geolocation
- User agent and browser fingerprint
- Specific threat indicators detected
- Request headers and timing
- User session information

## Configuration

### Environment Variables
```bash
ANTI_INTERCEPT_KEY=your-encryption-key-here
MASTER_ENCRYPTION_KEY=your-master-key-here
```

### System Settings
- `security.enable_anti_intercept` - Enable/disable protection
- `security.strict_mode` - Aggressive blocking vs monitoring
- `security.whitelist_ips` - Trusted IP addresses
- `security.detection_threshold` - Number of indicators required

## Testing Security

### Safe Testing Methods
- Use legitimate browsers without proxy tools
- Access directly via standard HTTP/HTTPS
- No automation or debugging tools active
- Standard user behavior patterns

### Blocked Scenarios
- Running Burp Suite with browser proxy configured
- Using Selenium/WebDriver for automated access
- Having developer tools open during requests
- Accessing via proxy servers or VPNs
- Using automated scripts or bots

## Performance Impact

- **Client-Side**: Minimal JavaScript overhead (~2KB compressed)
- **Server-Side**: <1ms additional processing per request
- **Memory Usage**: Negligible nonce/fingerprint storage
- **Network**: Additional security headers (~500 bytes per response)

## Compliance and Legal

This security system is designed to:
- Protect user data and platform integrity
- Prevent unauthorized access and data scraping
- Comply with data protection regulations
- Maintain service availability and performance

All security measures are transparent to legitimate users while effectively blocking malicious activities.