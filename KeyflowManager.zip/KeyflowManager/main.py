from app import app
from security_interceptor import security_interceptor
from flask import request, abort
import logging
import telegram_bot_routes  # noqa: F401

logger = logging.getLogger(__name__)

@app.before_request
def security_check():
    """Apply security checks before each request"""
    # Skip security checks for static files
    if request.endpoint == 'static':
        return
    
    # Validate request integrity
    integrity_result = security_interceptor.validate_request_integrity()
    
    if integrity_result == False:
        # Definite security threat - block request
        logger.warning(f"Request blocked due to security threat from {request.remote_addr}")
        abort(403)
    elif integrity_result == 'suspicious':
        # Suspicious request - log but allow with increased monitoring
        logger.info(f"Suspicious request allowed with monitoring from {request.remote_addr}")
    
    # Detect automation tools on sensitive endpoints (temporarily disabled for development)
    if request.path.startswith('/search') and not request.path.startswith('/admin'):
        automation_check = security_interceptor.detect_automation_tools(request)
        if automation_check['is_automated']:
            logger.warning(f"Automated tool blocked from sensitive endpoint: {automation_check}")
            abort(403)

@app.after_request
def apply_security_headers(response):
    """Apply security headers to all responses"""
    return security_interceptor.apply_security_headers(response)

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)
