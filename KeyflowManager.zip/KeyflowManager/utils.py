"""
Utility functions for the MROSINT platform
"""
from functools import wraps
from flask import session, redirect, url_for, flash
import qrcode
import qrcode.image.svg
from io import StringIO
import base64

def admin_required(f):
    """Decorator to require admin access"""
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'user_id' not in session or not session.get('is_admin'):
            flash('Admin access required', 'error')
            return redirect(url_for('login'))
        return f(*args, **kwargs)
    return decorated_function

def login_required(f):
    """Decorator to require user login"""
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'user_id' not in session:
            flash('Login required', 'error')
            return redirect(url_for('login'))
        return f(*args, **kwargs)
    return decorated_function

def generate_qr_code(data, size=280):
    """Generate QR code as base64 encoded image"""
    import io
    
    # Create QR code instance
    qr = qrcode.QRCode(
        version=1,
        error_correction=qrcode.constants.ERROR_CORRECT_H,
        box_size=10,
        border=4,
    )
    
    # Add data to QR code
    qr.add_data(data)
    qr.make(fit=True)
    
    # Create image
    img = qr.make_image(fill_color="black", back_color="white")
    
    # Convert to base64
    buffer = io.BytesIO()
    img.save(buffer, format='PNG')
    buffer.seek(0)
    
    # Return base64 encoded image
    return f"data:image/png;base64,{base64.b64encode(buffer.getvalue()).decode()}"

def generate_upi_string(upi_id, amount, payee_name="MROSINT", transaction_note="", transaction_id=""):
    """Generate UPI payment string for QR code"""
    # Format amount to 2 decimal places
    formatted_amount = f"{float(amount):.2f}"
    
    # Create UPI string
    upi_string = f"upi://pay?pa={upi_id}&pn={payee_name}&am={formatted_amount}&cu=INR"
    
    if transaction_note:
        # Limit transaction note length
        tn = transaction_note[:50] if len(transaction_note) > 50 else transaction_note
        upi_string += f"&tn={tn}"
    
    return upi_string

def format_currency(amount, currency='₹'):
    """Format currency with proper symbol"""
    return f"{currency}{amount:,.2f}"

def format_datetime(dt, format='%Y-%m-%d %H:%M:%S'):
    """Format datetime for display"""
    if dt:
        return dt.strftime(format)
    return 'N/A'

def truncate_text(text, max_length=50):
    """Truncate text with ellipsis"""
    if len(text) <= max_length:
        return text
    return text[:max_length-3] + '...'

def mask_sensitive_data(data, mask_char='*', visible_chars=4):
    """Mask sensitive data like phone numbers, aadhar"""
    if not data or len(data) <= visible_chars:
        return data
    
    visible_start = visible_chars // 2
    visible_end = visible_chars - visible_start
    
    if visible_end == 0:
        return data[:visible_start] + mask_char * (len(data) - visible_start)
    else:
        return data[:visible_start] + mask_char * (len(data) - visible_chars) + data[-visible_end:]

def validate_mobile_number(mobile):
    """Validate Indian mobile number"""
    import re
    return bool(re.match(r'^[6-9]\d{9}$', mobile))

def validate_aadhar_number(aadhar):
    """Validate Aadhar number"""
    import re
    if not re.match(r'^\d{12}$', aadhar):
        return False
    
    # Verhoeff algorithm for Aadhar validation
    def verhoeff_check(num):
        d = [[0, 1, 2, 3, 4, 5, 6, 7, 8, 9],
             [1, 2, 3, 4, 0, 6, 7, 8, 9, 5],
             [2, 3, 4, 0, 1, 7, 8, 9, 5, 6],
             [3, 4, 0, 1, 2, 8, 9, 5, 6, 7],
             [4, 0, 1, 2, 3, 9, 5, 6, 7, 8],
             [5, 9, 8, 7, 6, 0, 4, 3, 2, 1],
             [6, 5, 9, 8, 7, 1, 0, 4, 3, 2],
             [7, 6, 5, 9, 8, 2, 1, 0, 4, 3],
             [8, 7, 6, 5, 9, 3, 2, 1, 0, 4],
             [9, 8, 7, 6, 5, 4, 3, 2, 1, 0]]
        
        p = [[0, 1, 2, 3, 4, 5, 6, 7, 8, 9],
             [1, 5, 7, 6, 2, 8, 3, 0, 9, 4],
             [5, 8, 0, 3, 7, 9, 6, 1, 4, 2],
             [8, 9, 1, 6, 0, 4, 3, 5, 2, 7],
             [9, 4, 5, 3, 1, 2, 6, 8, 7, 0],
             [4, 2, 8, 6, 5, 7, 3, 9, 0, 1],
             [2, 7, 9, 3, 8, 0, 6, 4, 1, 5],
             [7, 0, 4, 6, 9, 1, 3, 2, 5, 8]]
        
        c = 0
        for i, digit in enumerate(reversed([int(d) for d in num])):
            c = d[c][p[i % 8][digit]]
        return c == 0
    
    return verhoeff_check(aadhar)

def validate_vehicle_number(vehicle_num):
    """Validate Indian vehicle number"""
    import re
    pattern = r'^[A-Z]{2}\d{2}[A-Z]{1,2}\d{4}$'
    return bool(re.match(pattern, vehicle_num.upper()))

def get_file_extension(filename):
    """Get file extension from filename"""
    return filename.rsplit('.', 1)[1].lower() if '.' in filename else ''

def allowed_file(filename, allowed_extensions={'txt', 'pdf', 'png', 'jpg', 'jpeg', 'gif'}):
    """Check if file extension is allowed"""
    return '.' in filename and get_file_extension(filename) in allowed_extensions

def generate_transaction_id():
    """Generate unique transaction ID"""
    import uuid
    import time
    timestamp = str(int(time.time()))
    unique_id = str(uuid.uuid4()).replace('-', '')[:8]
    return f"TXN{timestamp}{unique_id}".upper()

def calculate_gst(amount, gst_rate=18):
    """Calculate GST amount"""
    return (amount * gst_rate) / 100

def get_client_ip(request):
    """Get client IP address from request"""
    if request.environ.get('HTTP_X_FORWARDED_FOR') is None:
        return request.environ['REMOTE_ADDR']
    else:
        return request.environ['HTTP_X_FORWARDED_FOR']

def is_ajax_request(request):
    """Check if request is AJAX"""
    return request.headers.get('X-Requested-With') == 'XMLHttpRequest'

def safe_json_loads(json_string, default=None):
    """Safely load JSON string"""
    try:
        import json
        return json.loads(json_string) if json_string else default
    except (json.JSONDecodeError, TypeError):
        return default

def sanitize_filename(filename):
    """Sanitize filename for safe storage"""
    import re
    import unicodedata
    
    # Normalize unicode characters
    filename = unicodedata.normalize('NFKD', filename).encode('ascii', 'ignore').decode('ascii')
    
    # Remove or replace unsafe characters
    filename = re.sub(r'[^a-zA-Z0-9._-]', '_', filename)
    
    # Remove multiple consecutive underscores
    filename = re.sub(r'_+', '_', filename)
    
    # Remove leading/trailing underscores and dots
    filename = filename.strip('_.')
    
    return filename[:255]  # Limit filename length

def generate_secure_token(length=32):
    """Generate secure random token"""
    import secrets
    import string
    alphabet = string.ascii_letters + string.digits
    return ''.join(secrets.choice(alphabet) for _ in range(length))

def generate_upi_string(upi_id, amount, payee_name="MROSINT", transaction_note="", transaction_id=""):
    """Generate UPI payment string with proper formatting for exact amount"""
    try:
        # Format amount to 2 decimal places to ensure exact amount
        formatted_amount = "{:.2f}".format(float(amount))
        
        # Build UPI string with exact amount
        upi_params = {
            'pa': upi_id,  # Payee Address
            'pn': payee_name,  # Payee Name  
            'am': formatted_amount,  # Amount (exact)
            'cu': 'INR',  # Currency
        }
        
        # Add optional parameters
        if transaction_note:
            upi_params['tn'] = transaction_note  # Transaction Note
        if transaction_id:
            upi_params['tr'] = transaction_id  # Transaction Reference
        
        # Build URL parameters
        params = '&'.join([f"{key}={value}" for key, value in upi_params.items()])
        upi_string = f"upi://pay?{params}"
        
        return upi_string
    except Exception as e:
        # Fallback with exact amount formatting
        formatted_amount = "{:.2f}".format(float(amount))
        return f"upi://pay?pa={upi_id}&pn={payee_name}&am={formatted_amount}&cu=INR"
