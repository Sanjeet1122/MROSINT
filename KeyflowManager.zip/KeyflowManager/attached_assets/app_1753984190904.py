import os
import logging
from flask import Flask
from flask_sqlalchemy import SQLAlchemy
from sqlalchemy.orm import DeclarativeBase
from werkzeug.middleware.proxy_fix import ProxyFix

# Configure logging
logging.basicConfig(level=logging.DEBUG)

class Base(DeclarativeBase):
    pass

db = SQLAlchemy(model_class=Base)

# Create the app
app = Flask(__name__)
app.secret_key = os.environ.get("SESSION_SECRET", "dev-secret-key-change-in-production")
app.wsgi_app = ProxyFix(app.wsgi_app, x_proto=1, x_host=1)

# Configure the database
app.config["SQLALCHEMY_DATABASE_URI"] = os.environ.get("DATABASE_URL", "sqlite:///osint_platform.db")
app.config["SQLALCHEMY_ENGINE_OPTIONS"] = {
    "pool_recycle": 300,
    "pool_pre_ping": True,
}

# Initialize the app with the extension
db.init_app(app)

with app.app_context():
    # Import models and routes
    import models
    import routes
    
    # Create all tables
    db.create_all()
    
    # Add referral columns if they don't exist
    try:
        with db.engine.connect() as conn:
            # Check if referral columns exist
            result = conn.execute(db.text("PRAGMA table_info(user)"))
            columns = [row[1] for row in result.fetchall()]
            
            if 'referral_code' not in columns:
                conn.execute(db.text("ALTER TABLE user ADD COLUMN referral_code VARCHAR(20)"))
                conn.execute(db.text("ALTER TABLE user ADD COLUMN referred_by_id INTEGER"))
                conn.execute(db.text("ALTER TABLE user ADD COLUMN total_referrals INTEGER DEFAULT 0"))
                conn.execute(db.text("ALTER TABLE user ADD COLUMN referral_earnings FLOAT DEFAULT 0.0"))
                conn.commit()
                print("Referral system columns added to database")
    except Exception as e:
        print(f"Database migration warning: {e}")
    
    # Create admin user if it doesn't exist
    from models import User, SystemSetting, SystemLog
    from werkzeug.security import generate_password_hash
    
    admin = User.query.filter_by(username='admin').first()
    if not admin:
        admin_user = User(
            username='admin',
            email='admin@osint.com',
            full_name='Administrator',
            password_hash=generate_password_hash('admin123'),
            credits=1000.0,
            is_admin=True
        )
        db.session.add(admin_user)
        db.session.commit()
        
        # Initialize default system settings
        default_settings = [
            ('search.mobile_cost', '99', 'Cost per mobile number search', 'pricing', 'number'),
            ('search.aadhar_cost', '149', 'Cost per Aadhar number search', 'pricing', 'number'),
            ('search.vehicle_cost', '49.63', 'Cost per vehicle number search', 'pricing', 'number'),
            ('system.maintenance_mode', 'false', 'Enable maintenance mode', 'system', 'boolean'),
            ('system.registration_enabled', 'true', 'Allow new user registrations', 'system', 'boolean'),
            ('system.welcome_credits', '100', 'Credits given to new users', 'user', 'number'),
            ('system.max_searches_per_day', '50', 'Maximum searches per user per day', 'limits', 'number'),
            ('notifications.email_enabled', 'false', 'Enable email notifications', 'notifications', 'boolean'),
            ('notifications.sms_enabled', 'false', 'Enable SMS notifications', 'notifications', 'boolean'),
            ('api.rate_limit', '60', 'API requests per minute limit', 'api', 'number'),
            ('ui.theme', 'default', 'Default UI theme', 'ui', 'string'),
            ('ui.show_pricing', 'true', 'Show pricing information to users', 'ui', 'boolean'),
            ('referral.bonus_amount', '5.0', 'Referral bonus amount in rupees', 'referral', 'number'),
            ('referral.enabled', 'true', 'Enable referral system', 'referral', 'boolean'),
        ]
        
        for key, value, description, category, data_type in default_settings:
            if not SystemSetting.query.filter_by(key=key).first():
                setting = SystemSetting(
                    key=key,
                    value=value,
                    description=description,
                    category=category,
                    data_type=data_type,
                    updated_by=admin_user.id
                )
                db.session.add(setting)
        
        db.session.commit()
        
        # Log system initialization
        SystemLog.log('INFO', 'system', 'System initialized with default settings', admin_user.id)
        print("Admin user created: username=admin, password=admin123")
        print("Default system settings initialized")

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)
