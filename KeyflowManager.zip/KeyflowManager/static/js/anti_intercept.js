/**
 * Client-side anti-interception protection for MROSINT
 * Detects and prevents proxy tools like Burp Suite, OWASP ZAP
 */

class AntiInterceptor {
    constructor() {
        this.fingerprint = null;
        this.sessionToken = null;
        this.nonces = new Set();
        this.requestHistory = [];
        this.init();
    }

    init() {
        this.generateFingerprint();
        this.setupRequestInterceptors();
        this.startSecurityMonitoring();
        this.detectDebuggerTools();
    }

    generateFingerprint() {
        // Generate unique browser fingerprint
        const canvas = document.createElement('canvas');
        const ctx = canvas.getContext('2d');
        ctx.textBaseline = 'top';
        ctx.font = '14px Arial';
        ctx.fillText('MROSINT Security Check', 2, 2);
        
        const fingerprint = {
            userAgent: navigator.userAgent,
            screen: `${screen.width}x${screen.height}`,
            timezone: Intl.DateTimeFormat().resolvedOptions().timeZone,
            language: navigator.language,
            platform: navigator.platform,
            cookieEnabled: navigator.cookieEnabled,
            canvas: canvas.toDataURL(),
            timestamp: Date.now()
        };

        this.fingerprint = btoa(JSON.stringify(fingerprint));
    }

    setupRequestInterceptors() {
        const originalFetch = window.fetch;
        const originalXHR = XMLHttpRequest.prototype.open;
        const self = this;

        // Intercept fetch requests
        window.fetch = function(...args) {
            const [url, options = {}] = args;
            
            // Add security headers
            options.headers = {
                ...options.headers,
                'X-Client-Fingerprint': self.fingerprint,
                'X-Request-Time': Date.now().toString(),
                'X-Request-Nonce': self.generateNonce(),
                'X-Anti-Intercept': 'enabled'
            };

            // Detect if request is being intercepted
            if (self.detectInterception()) {
                console.warn('Request interception detected - blocking');
                return Promise.reject(new Error('Security check failed'));
            }

            return originalFetch.apply(this, [url, options]);
        };

        // Intercept XMLHttpRequest
        XMLHttpRequest.prototype.open = function(method, url, async, user, password) {
            this.setRequestHeader('X-Client-Fingerprint', self.fingerprint);
            this.setRequestHeader('X-Request-Time', Date.now().toString());
            this.setRequestHeader('X-Request-Nonce', self.generateNonce());
            this.setRequestHeader('X-Anti-Intercept', 'enabled');
            
            if (self.detectInterception()) {
                throw new Error('Security check failed');
            }
            
            return originalXHR.apply(this, arguments);
        };
    }

    generateNonce() {
        const nonce = Date.now().toString(36) + Math.random().toString(36).substr(2);
        this.nonces.add(nonce);
        
        // Clean old nonces
        if (this.nonces.size > 100) {
            const nonceArray = Array.from(this.nonces);
            this.nonces = new Set(nonceArray.slice(-50));
        }
        
        return nonce;
    }

    detectInterception() {
        const checks = [
            this.checkProxyHeaders(),
            this.checkBrowserConsole(),
            this.checkDebuggerTools(),
            this.checkNetworkTiming(),
            this.checkDOMModification()
        ];

        const suspiciousCount = checks.filter(check => check).length;
        return suspiciousCount >= 2; // Require multiple indicators
    }

    checkProxyHeaders() {
        // This will be checked server-side, but we can detect client-side signs
        try {
            const xhr = new XMLHttpRequest();
            xhr.open('HEAD', window.location.href, false);
            xhr.send();
            
            // Check for proxy-related headers in response
            const headers = xhr.getAllResponseHeaders().toLowerCase();
            const proxyIndicators = ['proxy', 'via', 'x-forwarded', 'x-real-ip'];
            
            return proxyIndicators.some(indicator => headers.includes(indicator));
        } catch (e) {
            return false;
        }
    }

    checkBrowserConsole() {
        // Detect if developer tools are open
        let devtools = false;
        const threshold = 160;

        setInterval(() => {
            if (window.outerHeight - window.innerHeight > threshold || 
                window.outerWidth - window.innerWidth > threshold) {
                devtools = true;
            }
        }, 500);

        return devtools;
    }

    checkDebuggerTools() {
        // Detect common debugging and interception tools
        const debuggerStrings = [
            'burp', 'owasp', 'zap', 'proxy', 'intercept',
            'tamper', 'fiddler', 'charles', 'mitmproxy'
        ];

        // Check user agent
        const userAgent = navigator.userAgent.toLowerCase();
        if (debuggerStrings.some(tool => userAgent.includes(tool))) {
            return true;
        }

        // Check for debugger statements
        try {
            const start = performance.now();
            debugger;
            const end = performance.now();
            
            // If debugger was hit, execution time will be much longer
            if (end - start > 100) {
                return true;
            }
        } catch (e) {
            // Ignore errors
        }

        return false;
    }

    checkNetworkTiming() {
        // Check for unusual network timing that might indicate proxy
        if (!window.performance || !window.performance.timing) {
            return false;
        }

        const timing = window.performance.timing;
        const networkTime = timing.responseStart - timing.requestStart;
        
        // If network time is unusually high, might indicate proxy
        return networkTime > 5000; // 5 seconds threshold
    }

    checkDOMModification() {
        // Detect if DOM is being modified by external tools
        let modifications = 0;
        
        const observer = new MutationObserver((mutations) => {
            mutations.forEach((mutation) => {
                if (mutation.type === 'childList' && mutation.addedNodes.length > 0) {
                    modifications++;
                }
            });
        });

        observer.observe(document.body, {
            childList: true,
            subtree: true
        });

        // Check modification rate
        setTimeout(() => {
            observer.disconnect();
        }, 1000);

        return modifications > 50; // High modification rate might indicate tools
    }

    startSecurityMonitoring() {
        // Periodic security checks
        setInterval(() => {
            if (this.detectInterception()) {
                this.handleSecurityThreat();
            }
        }, 30000); // Check every 30 seconds

        // Monitor for suspicious events
        document.addEventListener('keydown', (e) => {
            // Detect F12 (developer tools)
            if (e.keyCode === 123 || 
                (e.ctrlKey && e.shiftKey && (e.keyCode === 73 || e.keyCode === 74))) {
                this.handleSecurityThreat('Developer tools detected');
            }
        });

        // Detect right-click (inspect element)
        document.addEventListener('contextmenu', (e) => {
            // Don't block completely, but log suspicious activity
            console.warn('Right-click detected - monitoring for inspection tools');
        });
    }

    detectDebuggerTools() {
        // Advanced debugger detection
        const techniques = [
            () => {
                // Console detection
                let devtools = false;
                const img = new Image();
                Object.defineProperty(img, 'id', {
                    get: function() {
                        devtools = true;
                        return 'devtools-detected';
                    }
                });
                console.log(img);
                return devtools;
            },
            () => {
                // Performance-based detection
                const start = performance.now();
                console.log('Security check');
                const end = performance.now();
                return (end - start) > 100;
            },
            () => {
                // Function toString detection
                const original = Function.prototype.toString;
                Function.prototype.toString = function() {
                    if (this === Function.prototype.toString) {
                        return 'function toString() { [native code] }';
                    }
                    return original.apply(this, arguments);
                };
                
                try {
                    return original.toString().indexOf('[native code]') === -1;
                } finally {
                    Function.prototype.toString = original;
                }
            }
        ];

        return techniques.some(technique => {
            try {
                return technique();
            } catch (e) {
                return false;
            }
        });
    }

    handleSecurityThreat(reason = 'Interception detected') {
        console.error(`Security threat detected: ${reason}`);
        
        // Send alert to server
        this.reportSecurityIncident(reason);
        
        // Optionally redirect or disable functionality
        if (this.isCriticalThreat(reason)) {
            window.location.href = '/security-warning';
        }
    }

    isCriticalThreat(reason) {
        const criticalIndicators = [
            'Developer tools detected',
            'Multiple interception indicators',
            'Proxy headers detected'
        ];
        
        return criticalIndicators.some(indicator => reason.includes(indicator));
    }

    reportSecurityIncident(reason) {
        try {
            fetch('/api/security-incident', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-Client-Fingerprint': this.fingerprint
                },
                body: JSON.stringify({
                    reason: reason,
                    timestamp: Date.now(),
                    fingerprint: this.fingerprint,
                    userAgent: navigator.userAgent,
                    url: window.location.href
                })
            }).catch(e => {
                // Silently fail - don't alert potential attackers
                console.log('Security report failed');
            });
        } catch (e) {
            // Ignore errors in reporting
        }
    }

    // Encrypt sensitive form data before submission
    encryptFormData(formData) {
        // Simple XOR encryption for demo (use stronger encryption in production)
        const key = this.fingerprint.slice(0, 32);
        let encrypted = '';
        
        for (let i = 0; i < formData.length; i++) {
            encrypted += String.fromCharCode(
                formData.charCodeAt(i) ^ key.charCodeAt(i % key.length)
            );
        }
        
        return btoa(encrypted);
    }
}

// Initialize anti-interceptor when DOM is ready
document.addEventListener('DOMContentLoaded', function() {
    if (typeof window.antiInterceptor === 'undefined') {
        window.antiInterceptor = new AntiInterceptor();
    }
    
    // Add encryption to search forms
    const searchFormElements = document.querySelectorAll('form[action*="search"]');
    searchFormElements.forEach(form => {
        form.addEventListener('submit', function(e) {
            const inputs = form.querySelectorAll('input[type="text"], input[type="tel"]');
            inputs.forEach(input => {
                if (input.value && input.value.length > 5) {
                    // Store original value in hidden field for server processing
                    const hiddenInput = document.createElement('input');
                    hiddenInput.type = 'hidden';
                    hiddenInput.name = input.name + '_encrypted';
                    hiddenInput.value = window.antiInterceptor.encryptFormData(input.value);
                    form.appendChild(hiddenInput);
                }
            });
        });
    });
});

// Prevent common debugging techniques
(() => {
    'use strict';
    
    // Disable F12, Ctrl+Shift+I, Ctrl+Shift+J, Ctrl+U
    document.addEventListener('keydown', function(e) {
        if (e.keyCode === 123 || // F12
            (e.ctrlKey && e.shiftKey && e.keyCode === 73) || // Ctrl+Shift+I
            (e.ctrlKey && e.shiftKey && e.keyCode === 74) || // Ctrl+Shift+J
            (e.ctrlKey && e.keyCode === 85)) { // Ctrl+U
            e.preventDefault();
            e.stopPropagation();
            return false;
        }
    });
    
    // Disable right-click context menu
    document.addEventListener('contextmenu', function(e) {
        e.preventDefault();
        return false;
    });
    
    // Detect and prevent common console commands
    const originalLog = console.log;
    console.log = function(...args) {
        // Allow normal logging but detect suspicious patterns
        const message = args.join(' ').toLowerCase();
        if (message.includes('intercept') || message.includes('proxy') || message.includes('burp')) {
            console.warn('Suspicious console activity detected');
        }
        return originalLog.apply(console, args);
    };
})();