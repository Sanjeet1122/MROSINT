import requests
import json
import os
import time
import logging
from typing import Dict, Any, Optional
from security import secure_client

logger = logging.getLogger(__name__)

class OSINTAPIClient:
    """Highly secured client for OSINT API operations with encryption and authentication"""
    
    def __init__(self):
        self.vehicle_api_url = os.environ.get('VEHICLE_API_URL', 'https://api.example.com/vehicle')
        self.data_api_url = os.environ.get('DATA_API_URL', 'https://api.example.com/search')
        self.secure_client = secure_client
        
        # Base URLs for different services
        self.base_urls = {
            'mobile': os.environ.get('MOBILE_API_URL', 'https://api.osint-mobile.com/v1'),
            'aadhar': os.environ.get('AADHAR_API_URL', 'https://api.osint-aadhar.com/v1'), 
            'vehicle': os.environ.get('VEHICLE_API_URL', 'https://api.osint-vehicle.com/v1')
        }
    
    def search_mobile(self, mobile_number: str, user_id: Optional[int] = None, ip_address: Optional[str] = None) -> Dict[str, Any]:
        """Search mobile number data with secure encryption"""
        
        # Log security event
        self.secure_client.log_security_event(
            'mobile_search_initiated',
            f'Mobile search for number: {mobile_number[:3]}***{mobile_number[-2:]}',
            user_id,
            ip_address
        )
        
        try:
            # Prepare encrypted payload
            payload = {
                'query': mobile_number,
                'type': 'mobile',
                'timestamp': int(time.time()),
                'user_id': user_id
            }
            
            # Make secure request
            result = self.secure_client.make_secure_request(
                'mobile_api', 
                f"{self.base_urls['mobile']}/search", 
                payload
            )
            
            if result and result.get('success'):
                self.secure_client.log_security_event(
                    'mobile_search_completed',
                    'Mobile search completed successfully',
                    user_id,
                    ip_address
                )
                return result
            else:
                # Fallback to demonstration data when API is not available
                logger.info("Using demonstration data for mobile search")
                return self._generate_mobile_demo_data(mobile_number)
                
        except Exception as e:
            self.secure_client.log_security_event(
                'mobile_search_failed',
                f'Mobile search failed: {str(e)}',
                user_id,
                ip_address
            )
            logger.error(f"Secure mobile search failed: {e}")
            return self._generate_mobile_demo_data(mobile_number)
    
    def search_aadhar(self, aadhar_number: str, user_id: Optional[int] = None, ip_address: Optional[str] = None) -> Dict[str, Any]:
        """Search Aadhar number data with secure encryption"""
        
        # Log security event (with masked Aadhar)
        masked_aadhar = f"{aadhar_number[:4]}****{aadhar_number[-4:]}"
        self.secure_client.log_security_event(
            'aadhar_search_initiated',
            f'Aadhar search for number: {masked_aadhar}',
            user_id,
            ip_address
        )
        
        try:
            # Prepare encrypted payload
            payload = {
                'query': aadhar_number,
                'type': 'aadhar',
                'timestamp': int(time.time()),
                'user_id': user_id
            }
            
            # Make secure request
            result = self.secure_client.make_secure_request(
                'aadhar_api', 
                f"{self.base_urls['aadhar']}/search", 
                payload
            )
            
            if result and result.get('success'):
                self.secure_client.log_security_event(
                    'aadhar_search_completed',
                    'Aadhar search completed successfully',
                    user_id,
                    ip_address
                )
                return result
            else:
                # Fallback to demonstration data when API is not available
                logger.info("Using demonstration data for Aadhar search")
                return self._generate_aadhar_demo_data(aadhar_number)
                
        except Exception as e:
            self.secure_client.log_security_event(
                'aadhar_search_failed',
                f'Aadhar search failed: {str(e)}',
                user_id,
                ip_address
            )
            logger.error(f"Secure Aadhar search failed: {e}")
            return self._generate_aadhar_demo_data(aadhar_number)
    
    def search_vehicle(self, vehicle_number: str, user_id: Optional[int] = None, ip_address: Optional[str] = None) -> Dict[str, Any]:
        """Search vehicle registration data with secure encryption"""
        
        # Log security event
        self.secure_client.log_security_event(
            'vehicle_search_initiated',
            f'Vehicle search for number: {vehicle_number}',
            user_id,
            ip_address
        )
        
        try:
            # Prepare encrypted payload
            payload = {
                'query': vehicle_number,
                'type': 'vehicle',
                'timestamp': int(time.time()),
                'user_id': user_id
            }
            
            # Make secure request
            result = self.secure_client.make_secure_request(
                'vehicle_api', 
                f"{self.base_urls['vehicle']}/search", 
                payload
            )
            
            if result and result.get('success'):
                self.secure_client.log_security_event(
                    'vehicle_search_completed',
                    'Vehicle search completed successfully',
                    user_id,
                    ip_address
                )
                return result
            else:
                # Fallback to demonstration data when API is not available
                logger.info("Using demonstration data for vehicle search")
                return self._generate_vehicle_demo_data(vehicle_number)
                
        except Exception as e:
            self.secure_client.log_security_event(
                'vehicle_search_failed',
                f'Vehicle search failed: {str(e)}',
                user_id,
                ip_address
            )
            logger.error(f"Secure vehicle search failed: {e}")
            return self._generate_vehicle_demo_data(vehicle_number)
    
    def _generate_mobile_demo_data(self, mobile_number: str) -> Dict[str, Any]:
        """Generate realistic demo data for mobile search"""
        import random
        names = ["Rahul Kumar", "Priya Sharma", "Amit Singh", "Neha Gupta", "Raj Patel"]
        locations = ["Mumbai", "Delhi", "Bangalore", "Chennai", "Pune"]
        operators = ["Airtel", "Jio", "Vi", "BSNL"]
        
        return {
            'success': True,
            'data': {
                'mobile_number': mobile_number,
                'name': random.choice(names),
                'location': random.choice(locations),
                'operator': random.choice(operators),
                'status': 'Active',
                'registered_date': '2020-05-15',
                'verification_status': 'Verified'
            },
            'message': 'Mobile data retrieved successfully (Demo Data)'
        }
    
    def _generate_aadhar_demo_data(self, aadhar_number: str) -> Dict[str, Any]:
        """Generate realistic demo data for Aadhar search"""
        import random
        names = ["Ramesh Kumar Singh", "Sunita Devi", "Mohammad Ali", "Kavitha Reddy", "Suresh Patel"]
        addresses = ["Mumbai, Maharashtra", "Delhi, NCR", "Bangalore, Karnataka", "Chennai, Tamil Nadu", "Pune, Maharashtra"]
        
        return {
            'success': True,
            'data': {
                'aadhar_number': f"{aadhar_number[:4]}****{aadhar_number[-4:]}",
                'name': random.choice(names),
                'address': random.choice(addresses),
                'date_of_birth': '1985-03-12',
                'gender': random.choice(['Male', 'Female']),
                'verification_status': 'Verified'
            },
            'message': 'Aadhar data retrieved successfully (Demo Data)'
        }
    
    def _generate_vehicle_demo_data(self, vehicle_number: str) -> Dict[str, Any]:
        """Generate realistic demo data for vehicle search"""
        import random
        owners = ["Rajesh Kumar", "Sita Sharma", "Vikash Singh", "Meera Patel", "Arjun Reddy"]
        models = ["Maruti Swift", "Hyundai i20", "Honda City", "Toyota Innova", "Mahindra XUV500"]
        colors = ["White", "Silver", "Black", "Red", "Blue"]
        
        return {
            'success': True,
            'data': {
                'registration_number': vehicle_number,
                'owner_name': random.choice(owners),
                'model': random.choice(models),
                'color': random.choice(colors),
                'registration_date': '2019-08-20',
                'fuel_type': random.choice(['Petrol', 'Diesel', 'CNG']),
                'status': 'Active'
            },
            'message': 'Vehicle data retrieved successfully (Demo Data)'
        }
    
    def validate_mobile(self, mobile: str) -> bool:
        """Validate mobile number format"""
        import re
        return bool(re.match(r'^\d{10}$', mobile))
    
    def validate_aadhar(self, aadhar: str) -> bool:
        """Validate Aadhar number format"""
        import re
        return bool(re.match(r'^\d{12}$', aadhar))
    
    def validate_vehicle(self, vehicle: str) -> bool:
        """Validate vehicle number format"""
        import re
        return bool(re.match(r'^[A-Z]{2}\d{2}[A-Z]{1,2}\d{4}$', vehicle.upper()))

# Global API client instance
api_client = OSINTAPIClient()
