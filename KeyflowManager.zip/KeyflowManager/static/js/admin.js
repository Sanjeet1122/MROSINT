// MROSINT Admin Dashboard JavaScript

document.addEventListener('DOMContentLoaded', function() {
    // Mobile menu toggle
    const mobileMenuToggle = document.querySelector('.mobile-menu-toggle');
    const sidebar = document.querySelector('.admin-sidebar');
    const sidebarOverlay = document.querySelector('.sidebar-overlay');

    if (mobileMenuToggle) {
        mobileMenuToggle.addEventListener('click', function() {
            sidebar.classList.toggle('show');
            sidebarOverlay.classList.toggle('show');
        });
    }

    if (sidebarOverlay) {
        sidebarOverlay.addEventListener('click', function() {
            sidebar.classList.remove('show');
            sidebarOverlay.classList.remove('show');
        });
    }

    // Auto-hide alerts
    const alerts = document.querySelectorAll('.alert');
    alerts.forEach(alert => {
        setTimeout(() => {
            alert.style.opacity = '0';
            setTimeout(() => {
                if (alert.parentNode) {
                    alert.parentNode.removeChild(alert);
                }
            }, 300);
        }, 5000);
    });

    // Admin dropdown toggle
    window.toggleAdminDropdown = function() {
        const dropdown = document.getElementById('adminDropdown').parentElement;
        dropdown.classList.toggle('open');
        
        // Close dropdown when clicking outside
        document.addEventListener('click', function(event) {
            if (!dropdown.contains(event.target)) {
                dropdown.classList.remove('open');
            }
        });
    };

    // Confirm delete actions
    const deleteButtons = document.querySelectorAll('[data-action="delete"]');
    deleteButtons.forEach(button => {
        button.addEventListener('click', function(e) {
            const itemName = this.getAttribute('data-item') || 'this item';
            if (!confirm(`Are you sure you want to delete ${itemName}? This action cannot be undone.`)) {
                e.preventDefault();
            }
        });
    });

    // API Key toggle
    const toggleButtons = document.querySelectorAll('[data-action="toggle"]');
    toggleButtons.forEach(button => {
        button.addEventListener('click', function(e) {
            const action = this.getAttribute('data-current-state') === 'active' ? 'deactivate' : 'activate';
            const itemName = this.getAttribute('data-item') || 'this API key';
            if (!confirm(`Are you sure you want to ${action} ${itemName}?`)) {
                e.preventDefault();
            }
        });
    });

    // Payment approval
    const approvalForms = document.querySelectorAll('.payment-approval-form');
    approvalForms.forEach(form => {
        form.addEventListener('submit', function(e) {
            const action = form.querySelector('select[name="action"]').value;
            const amount = form.getAttribute('data-amount');
            const username = form.getAttribute('data-username');
            
            if (action === 'approve') {
                if (!confirm(`Approve payment of ₹${amount} for ${username}? Credits will be added immediately.`)) {
                    e.preventDefault();
                }
            } else if (action === 'reject') {
                if (!confirm(`Reject payment of ₹${amount} for ${username}? This action cannot be undone.`)) {
                    e.preventDefault();
                }
            }
        });
    });

    // User management actions
    const userActionForms = document.querySelectorAll('.user-action-form');
    userActionForms.forEach(form => {
        form.addEventListener('submit', function(e) {
            const action = form.querySelector('select[name="action"]').value;
            const credits = form.querySelector('input[name="credits"]').value;
            const username = form.getAttribute('data-username');
            
            let message = '';
            if (action === 'add') {
                message = `Add ₹${credits} credits to ${username}?`;
            } else if (action === 'remove') {
                message = `Remove ₹${credits} credits from ${username}?`;
            } else if (action === 'activate') {
                message = `Activate user ${username}?`;
            } else if (action === 'deactivate') {
                message = `Deactivate user ${username}? They will be unable to login.`;
            }
            
            if (message && !confirm(message)) {
                e.preventDefault();
            }
        });
    });

    // Search functionality
    const searchInputs = document.querySelectorAll('[data-search-target]');
    searchInputs.forEach(input => {
        input.addEventListener('input', function() {
            const target = this.getAttribute('data-search-target');
            const searchTerm = this.value.toLowerCase();
            const items = document.querySelectorAll(target);
            
            items.forEach(item => {
                const text = item.textContent.toLowerCase();
                if (text.includes(searchTerm)) {
                    item.style.display = '';
                } else {
                    item.style.display = 'none';
                }
            });
        });
    });

    // Form validation for admin forms
    const formElements = document.querySelectorAll('form');
    formElements.forEach(form => {
        form.addEventListener('submit', function(e) {
            const requiredFields = form.querySelectorAll('[required]');
            let isValid = true;
            
            requiredFields.forEach(field => {
                if (!field.value.trim()) {
                    isValid = false;
                    field.classList.add('is-invalid');
                    
                    // Remove invalid class after user starts typing
                    field.addEventListener('input', function() {
                        this.classList.remove('is-invalid');
                    }, { once: true });
                }
            });
            
            if (!isValid) {
                e.preventDefault();
                alert('Please fill in all required fields.');
            }
        });
    });

    // Copy to clipboard functionality
    const copyButtons = document.querySelectorAll('[data-copy]');
    copyButtons.forEach(button => {
        button.addEventListener('click', function() {
            const textToCopy = this.getAttribute('data-copy');
            navigator.clipboard.writeText(textToCopy).then(() => {
                // Show success feedback
                const originalText = this.textContent;
                this.textContent = 'Copied!';
                this.classList.add('btn-success');
                
                setTimeout(() => {
                    this.textContent = originalText;
                    this.classList.remove('btn-success');
                }, 2000);
            }).catch(err => {
                console.error('Failed to copy text: ', err);
                alert('Failed to copy to clipboard');
            });
        });
    });

    // Auto-refresh data
    const autoRefreshElements = document.querySelectorAll('[data-auto-refresh]');
    autoRefreshElements.forEach(element => {
        const interval = parseInt(element.getAttribute('data-auto-refresh')) * 1000;
        setInterval(() => {
            // Simple page reload for auto-refresh
            // In a more complex app, you'd use AJAX to refresh specific sections
            if (document.visibilityState === 'visible') {
                window.location.reload();
            }
        }, interval);
    });

    // Statistics animation
    const statValues = document.querySelectorAll('.stat-value');
    statValues.forEach(stat => {
        const finalValue = parseInt(stat.textContent.replace(/[^0-9]/g, ''));
        if (finalValue > 0) {
            animateCount(stat, 0, finalValue, 2000);
        }
    });

    function animateCount(element, start, end, duration) {
        const startTime = performance.now();
        const originalText = element.textContent;
        const isMonetary = originalText.includes('₹');
        
        function updateCount(currentTime) {
            const elapsed = currentTime - startTime;
            const progress = Math.min(elapsed / duration, 1);
            const currentValue = Math.floor(start + (end - start) * progress);
            
            if (isMonetary) {
                element.textContent = `₹${currentValue.toLocaleString()}`;
            } else {
                element.textContent = currentValue.toLocaleString();
            }
            
            if (progress < 1) {
                requestAnimationFrame(updateCount);
            }
        }
        
        requestAnimationFrame(updateCount);
    }

    // Table sorting
    const sortableHeaders = document.querySelectorAll('[data-sort]');
    sortableHeaders.forEach(header => {
        header.style.cursor = 'pointer';
        header.addEventListener('click', function() {
            const table = this.closest('table');
            const tbody = table.querySelector('tbody');
            const rows = Array.from(tbody.querySelectorAll('tr'));
            const column = this.getAttribute('data-sort');
            const columnIndex = Array.from(this.parentNode.children).indexOf(this);
            
            // Toggle sort direction
            const isAscending = this.classList.contains('sort-asc');
            
            // Remove existing sort classes
            this.parentNode.querySelectorAll('th').forEach(th => {
                th.classList.remove('sort-asc', 'sort-desc');
            });
            
            // Add new sort class
            this.classList.add(isAscending ? 'sort-desc' : 'sort-asc');
            
            // Sort rows
            rows.sort((a, b) => {
                const aValue = a.children[columnIndex].textContent.trim();
                const bValue = b.children[columnIndex].textContent.trim();
                
                // Try to parse as numbers
                const aNum = parseFloat(aValue.replace(/[^0-9.-]/g, ''));
                const bNum = parseFloat(bValue.replace(/[^0-9.-]/g, ''));
                
                if (!isNaN(aNum) && !isNaN(bNum)) {
                    return isAscending ? bNum - aNum : aNum - bNum;
                } else {
                    return isAscending ? 
                        bValue.localeCompare(aValue) : 
                        aValue.localeCompare(bValue);
                }
            });
            
            // Reorder rows in table
            rows.forEach(row => tbody.appendChild(row));
        });
    });

    // Filter functionality
    const filterSelects = document.querySelectorAll('[data-filter]');
    filterSelects.forEach(select => {
        select.addEventListener('change', function() {
            const filterValue = this.value;
            const targetTable = document.querySelector(this.getAttribute('data-filter'));
            const rows = targetTable.querySelectorAll('tbody tr');
            
            rows.forEach(row => {
                if (filterValue === '' || row.textContent.toLowerCase().includes(filterValue.toLowerCase())) {
                    row.style.display = '';
                } else {
                    row.style.display = 'none';
                }
            });
        });
    });

    // Loading states for forms
    const loadingForms = document.querySelectorAll('form');
    loadingForms.forEach(form => {
        form.addEventListener('submit', function() {
            const submitButton = form.querySelector('button[type="submit"]');
            if (submitButton) {
                const originalText = submitButton.textContent;
                submitButton.textContent = 'Processing...';
                submitButton.disabled = true;
                
                // Re-enable after 5 seconds as fallback
                setTimeout(() => {
                    submitButton.textContent = originalText;
                    submitButton.disabled = false;
                }, 5000);
            }
        });
    });

    // Initialize tooltips if available
    if (typeof bootstrap !== 'undefined' && bootstrap.Tooltip) {
        const tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
        tooltipTriggerList.map(function (tooltipTriggerEl) {
            return new bootstrap.Tooltip(tooltipTriggerEl);
        });
    }
});

// Utility functions
function showLoading() {
    const overlay = document.createElement('div');
    overlay.className = 'loading-overlay';
    overlay.innerHTML = '<div class="loading-spinner"></div>';
    document.body.appendChild(overlay);
}

function hideLoading() {
    const overlay = document.querySelector('.loading-overlay');
    if (overlay) {
        overlay.remove();
    }
}

function showAlert(message, type = 'info') {
    const alertDiv = document.createElement('div');
    alertDiv.className = `alert alert-${type} fade-in`;
    alertDiv.textContent = message;
    
    const container = document.querySelector('.admin-content') || document.body;
    container.insertBefore(alertDiv, container.firstChild);
    
    setTimeout(() => {
        alertDiv.style.opacity = '0';
        setTimeout(() => {
            if (alertDiv.parentNode) {
                alertDiv.parentNode.removeChild(alertDiv);
            }
        }, 300);
    }, 5000);
}

// Export functions for use in other scripts
window.AdminDashboard = {
    showLoading,
    hideLoading,
    showAlert
};
