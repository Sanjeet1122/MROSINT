"""
Dynamic API Service Handler
Handles API calls based on configuration files
"""

import json
import requests
import os
from typing import Dict, Any, Optional, List
from models import SystemSetting
import logging

logger = logging.getLogger(__name__)

class APIService:
    def __init__(self):
        self.config = self._load_config()
        
    def _load_config(self) -> Dict[str, Any]:
        """Load API configuration from file"""
        config_path = os.path.join('config', 'api_config.json')
        try:
            with open(config_path, 'r') as f:
                return json.load(f)
        except FileNotFoundError:
            logger.error(f"API config file not found: {config_path}")
            return {}
        except json.JSONDecodeError as e:
            logger.error(f"Invalid JSON in config file: {e}")
            return {}
    
    def get_service_config(self, service_name: str) -> Optional[Dict[str, Any]]:
        """Get configuration for a specific service"""
        return self.config.get(f"{service_name}_api")
    
    def is_service_active(self, service_name: str) -> bool:
        """Check if service is active"""
        config = self.get_service_config(service_name)
        if config and isinstance(config, dict):
            return config.get('active', False)
        return False
    
    def get_api_key(self, service_name: str) -> Optional[str]:
        """Get API key from system settings"""
        key_name = f"api.{service_name}.key"
        value = SystemSetting.get_value(key_name)
        return str(value) if value is not None else None
    
    def make_request(self, service_name: str, **params) -> Dict[str, Any]:
        """Make API request based on service configuration"""
        config = self.get_service_config(service_name)
        
        if not config:
            return {
                'success': False,
                'error': f'Service {service_name} not configured'
            }
        
        if not config.get('active', False):
            return {
                'success': False,
                'error': f'Service {service_name} is not active'
            }
        
        try:
            # Build URL
            base_url = config['base_url']
            endpoint = config['endpoint']
            url = f"{base_url}{endpoint}"
            
            # Prepare headers
            headers = {'Content-Type': 'application/json'}
            
            # Add API key if required
            if config.get('requires_key', False):
                api_key = self.get_api_key(service_name)
                if not api_key:
                    return {
                        'success': False,
                        'error': f'API key required for {service_name} but not configured'
                    }
                
                key_header = config.get('key_header', 'X-API-Key')
                key_prefix = config.get('key_prefix', '')
                headers[key_header] = f"{key_prefix}{api_key}"
            
            # Prepare parameters
            api_params = {}
            param_mapping = config.get('parameters', {})
            
            for local_param, api_param in param_mapping.items():
                if local_param in params:
                    api_params[api_param] = params[local_param]
            
            # Make request
            method = config.get('method', 'GET').upper()
            timeout = config.get('timeout', 30)
            
            if method == 'GET':
                response = requests.get(url, params=api_params, headers=headers, timeout=timeout)
            elif method == 'POST':
                response = requests.post(url, json=api_params, headers=headers, timeout=timeout)
            else:
                return {
                    'success': False,
                    'error': f'Unsupported HTTP method: {method}'
                }
            
            # Process response
            if response.status_code == 200:
                try:
                    data = response.json()
                    return {
                        'success': True,
                        'data': data,
                        'service': service_name,
                        'cost': config.get('cost', 0)
                    }
                except json.JSONDecodeError:
                    return {
                        'success': False,
                        'error': 'Invalid JSON response from API'
                    }
            else:
                return {
                    'success': False,
                    'error': f'API returned status {response.status_code}: {response.text}'
                }
                
        except requests.exceptions.Timeout:
            return {
                'success': False,
                'error': 'API request timed out'
            }
        except requests.exceptions.RequestException as e:
            return {
                'success': False,
                'error': f'Network error: {str(e)}'
            }
        except Exception as e:
            logger.error(f"Unexpected error in API request: {e}")
            return {
                'success': False,
                'error': 'Internal server error'
            }
    
    def test_service(self, service_name: str, test_params: Dict[str, Any]) -> Dict[str, Any]:
        """Test API service with given parameters"""
        logger.info(f"Testing {service_name} API service")
        return self.make_request(service_name, **test_params)
    
    def get_service_cost(self, service_name: str) -> float:
        """Get cost for using a service"""
        config = self.get_service_config(service_name)
        return config.get('cost', 0.0) if config else 0.0
    
    def list_active_services(self) -> List[Dict[str, Any]]:
        """List all active services"""
        active_services = []
        for key, config in self.config.items():
            if config.get('active', False):
                service_name = key.replace('_api', '')
                active_services.append({
                    'name': service_name,
                    'display_name': config.get('name', service_name),
                    'description': config.get('description', ''),
                    'cost': config.get('cost', 0.0),
                    'requires_key': config.get('requires_key', False)
                })
        return active_services

# Global instance
api_service = APIService()

def search_mobile(mobile_number: str) -> Dict[str, Any]:
    """Search mobile number using configured API"""
    return api_service.make_request('mobile', mobile=mobile_number)

def search_aadhar(aadhar_number: str) -> Dict[str, Any]:
    """Search Aadhar using configured API"""
    return api_service.make_request('aadhar', aadhar=aadhar_number)

def search_vehicle(vehicle_number: str) -> Dict[str, Any]:
    """Search vehicle using configured API"""
    return api_service.make_request('vehicle', vehicle_number=vehicle_number)