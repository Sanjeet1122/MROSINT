# API Service Setup Guide

This guide explains how to configure and implement new API services in MROSINT.

## Quick Setup for New APIs

### 1. Add API Configuration

Edit `config/api_config.json` to add your new API service:

```json
{
  "mobile_api": {
    "name": "Mobile Number Search",
    "base_url": "https://your-api-domain.com",
    "endpoint": "/search/mobile",
    "method": "GET",
    "requires_key": false,
    "parameters": {
      "mobile": "query_parameter_name"
    },
    "response_format": "json"
  },
  "aadhar_api": {
    "name": "Aadhar Verification",
    "base_url": "https://your-aadhar-api.com",
    "endpoint": "/verify",
    "method": "POST",
    "requires_key": true,
    "key_header": "X-API-Key",
    "parameters": {
      "aadhar": "aadhar_number"
    },
    "response_format": "json"
  }
}
```

### 2. Add Your API Key (if required)

Go to Admin Panel → Settings → System Settings and add:
- Key: `api.your_service_name.key`
- Value: `your_api_key_here`
- Data Type: `string`
- Category: `api`

### 3. Update Service Implementation

The system automatically loads API configurations. No code changes needed for basic APIs.

## Advanced Configuration

### Custom Response Processing

If your API returns non-standard data, create a processor in `processors/`:

```python
# processors/your_api_processor.py
def process_response(response_data, search_type):
    """Process API response into standard format"""
    if search_type == 'mobile':
        return {
            'success': True,
            'data': {
                'name': response_data.get('full_name'),
                'mobile': response_data.get('phone'),
                'address': response_data.get('location')
            }
        }
    return response_data
```

### Authentication Methods

Supported authentication types:
- `header`: API key in header
- `query`: API key as query parameter  
- `bearer`: Bearer token authentication
- `basic`: Basic authentication

### Error Handling

The system handles common errors automatically:
- Network timeouts
- Invalid responses
- API rate limits
- Authentication failures

## Testing Your API

1. Go to Admin Panel → API Testing
2. Select your service
3. Enter test parameters
4. Verify response format

## Troubleshooting

### API Not Working?
1. Check API key is correct
2. Verify endpoint URL
3. Check API service status
4. Review system logs

### Response Format Issues?
1. Create custom processor
2. Test with sample data
3. Update configuration

## Supported Services

Currently configured:
- Mobile Number Search
- Aadhar Verification  
- Vehicle Information
- Custom APIs (add your own)

## Need Help?

Contact admin or check system logs for detailed error messages.