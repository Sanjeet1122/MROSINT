# MROSINT Architecture Blueprint

## System Components Map

### 🔐 Authentication & Security Layer
```
security.py ─────┬─→ Master encryption key management
                 ├─→ AES-256 API key encryption
                 └─→ Password hashing utilities

security_interceptor.py ─┬─→ Anti-proxy detection
                         ├─→ Request fingerprinting
                         └─→ Threat monitoring
```

### 📊 Database Architecture
```
models.py
├── User ──────────┬─→ Authentication
│                  ├─→ Credit balance
│                  └─→ Referral tracking
├── Payment ───────┬─→ UPI transactions
│                  ├─→ Admin approval
│                  └─→ Status tracking
├── Search ────────┬─→ Query logging
│                  ├─→ Result storage
│                  └─→ Cost tracking
├── Transaction ───┬─→ Credit history
│                  └─→ Financial audit
├── SystemSetting ─┬─→ Dynamic config
│                  └─→ Pricing control
└── SystemLog ─────┬─→ Security events
                   └─→ Error tracking
```

### 🌐 Route Structure
```
routes.py (User Routes)
├── / ─────────────────→ Landing page
├── /login ────────────→ Authentication
├── /register ─────────→ Signup + referral
├── /dashboard ────────→ User home
├── /search ───────────→ OSINT interface
├── /search/<type> ────→ Specific searches
├── /payment ──────────→ UPI QR generation
└── /profile ──────────→ User settings

admin_routes.py (Admin Panel)
├── /admin ────────────→ Dashboard stats
├── /admin/users ──────→ User management
├── /admin/payments ───→ Payment approval
├── /admin/pricing ────→ Cost settings
├── /admin/api-config ─→ API management
└── /admin/security ───→ Security panel
```

### 🔌 API Integration Flow
```
User Request
    ↓
routes.py
    ↓
api_client.py ─────┬─→ Encrypt request
                   ├─→ Sign with HMAC
                   ├─→ Call external API
                   └─→ Decrypt response
    ↓
External APIs
├── Mobile API ────→ No auth required
├── Aadhar API ────→ API key required
└── Vehicle API ───→ Bearer token auth
```

### 💳 Payment Flow
```
User clicks "Add Credits"
    ↓
payment.html ──────┬─→ Amount selection
                   └─→ Generate UPI QR
    ↓
UPI App Payment
    ↓
Admin Panel ───────┬─→ View pending
                   ├─→ Verify payment
                   └─→ Approve/Reject
    ↓
Credits Added ─────→ User can search
```

### 🎨 Frontend Architecture
```
Templates Structure:
base.html (User Layout)
    ├── CSS Variables
    ├── Dark mode toggle
    └── Navigation menu

admin_base.html (Admin Layout)
    ├── Sidebar navigation
    ├── Admin header
    └── Content area

Static Files:
├── css/
│   ├── style.css ─────→ User interface
│   └── admin.css ─────→ Admin styles
├── js/
│   └── admin.js ──────→ Admin functions
└── images/
    └── logo.svg ──────→ MROSINT branding
```

### 🔧 Configuration System
```
config/api_config.json
    ↓
services/api_service.py ─┬─→ Load config
                         ├─→ Validate APIs
                         └─→ Handle requests
    ↓
SystemSetting (DB) ──────┬─→ API keys
                         └─→ Pricing
```

### 🚀 Deployment Stack
```
Gunicorn (WSGI Server)
    ↓
Flask Application
    ↓
PostgreSQL Database
    ↓
Environment Variables:
├── DATABASE_URL
├── SESSION_SECRET
├── MASTER_ENCRYPTION_KEY
├── TELEGRAM_BOT_TOKEN
└── ANTI_INTERCEPT_KEY
```

### 📱 Support System
```
support_routes.py
    ↓
Telegram Bot (@MROSINT1bot)
├── /start ────────→ Welcome message
├── /balance ──────→ Check credits
├── /ticket ───────→ Create support ticket
└── Notifications ─→ Payment alerts
```

### 🔄 Data Flow Example (Mobile Search)
```
1. User enters mobile number
2. Form validation (regex check)
3. Credit check (99 rupees required)
4. API call to external service
5. Response processing
6. Credit deduction
7. Result display
8. Search logged in database
```

### 🛡️ Security Layers
```
Level 1: CSRF Protection (Flask-WTF)
Level 2: Password Hashing (bcrypt)
Level 3: API Encryption (AES-256)
Level 4: Request Signing (HMAC-SHA256)
Level 5: Anti-Interception (Proxy blocking)
Level 6: Rate Limiting (Request throttling)
Level 7: Audit Logging (All actions tracked)
```

### 💾 Database Relationships
```
User (1) ───→ (∞) Payment
User (1) ───→ (∞) Search
User (1) ───→ (∞) Transaction
User (1) ───→ (∞) SupportTicket
Payment (1) ─→ (1) Transaction
Admin (1) ──→ (∞) AdminAction
```

### 🎯 Key Features Map
```
Credit System
├── Dynamic pricing
├── Instant deduction
└── Admin control

Referral System
├── Unique codes
├── Fraud detection
└── Bonus tracking

Security System
├── Military-grade encryption
├── Proxy detection
└── Complete audit trail

Payment System
├── UPI-only
├── QR generation
└── Manual approval
```

This blueprint provides the complete technical architecture of MROSINT. Each component's purpose and connections are clearly mapped for reproduction.