# MROSINT - OSINT Search Platform

## Overview

MROSINT is a comprehensive OSINT (Open Source Intelligence) search platform that enables users to search for mobile numbers, Aadhar details, and vehicle information. The platform operates on a credit-based system where users purchase credits via UPI-only payments to perform searches. It features military-grade API security with AES-256 encryption, comprehensive admin management, streamlined UPI payment processing, and a referral system. The platform is built with enterprise-grade security including encrypted API key storage, HMAC-SHA256 request signing, and comprehensive security logging.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: Flask with Jinja2 templating engine for server-side rendering
- **UI Framework**: Bootstrap 5.3.0 for responsive design and components
- **Icons**: Font Awesome 6.4.0 for consistent iconography
- **Styling**: Custom CSS with CSS variables following Stripe-inspired design system
- **JavaScript**: Vanilla JavaScript with Bootstrap components for interactivity
- **Admin Interface**: Separate admin dashboard with sidebar navigation and dedicated styling

### Backend Architecture
- **Framework**: Flask (Python web framework) with modular route organization
- **Database ORM**: SQLAlchemy with Flask-SQLAlchemy extension using declarative base
- **Form Handling**: Flask-WTF with WTForms for comprehensive form validation and CSRF protection
- **Session Management**: Flask sessions with configurable secret key for user authentication
- **Password Security**: Werkzeug's password hashing utilities with bcrypt
- **Security Layer**: Custom secure API client with encryption and request signing
- **Logging**: Comprehensive system logging with different severity levels

### Database Schema
- **Users**: Complete user management with admin roles, referral system, and Telegram integration
- **Searches**: Search history with query types, results storage, and credit tracking
- **Transactions**: Financial transaction records with payment gateway integration
- **Payments**: Payment processing with multiple methods (UPI, Card, Net Banking)
- **System Settings**: Dynamic configuration storage for pricing and system parameters
- **API Keys**: Encrypted storage of external API credentials
- **System Logs**: Comprehensive audit trail with security event tracking

### Security Architecture
- **API Encryption**: Military-grade encryption using AES-256 for all stored API keys and communications
- **Request Authentication**: HMAC-SHA256 request signing with timestamps and nonces for authentication
- **Key Management**: Encrypted API key storage with secure management interface
- **Security Monitoring**: Real-time security event monitoring and failed login attempt tracking
- **Rate Limiting**: Built-in rate limiting to prevent API abuse and replay attacks
- **Session Security**: Secure session management with CSRF protection
- **Input Validation**: Regex-based validation for all search inputs (mobile, Aadhar, vehicle)
- **Audit Trail**: Complete security logging system with IP address tracking and admin action monitoring

### Credit System Architecture
- **Dynamic Pricing**: Configurable pricing stored in system settings (Mobile: ₹99, Aadhar: ₹149, Vehicle: ₹49.63)
- **Real-time Deduction**: Immediate credit deduction upon successful searches
- **UPI-Only Payments**: Streamlined payment system using UPI QR codes for exact deposit amounts
- **Referral System**: Automated referral tracking with earnings calculation
- **Bonus Management**: Admin-configurable signup bonus (₹500), referral bonus (₹50), and referral signup bonus (₹25)

### API Integration Layer
- **Secure Client**: Custom secure API client with encryption and fallback mechanisms
- **Fallback Data**: Demo data system when external APIs are unavailable
- **Error Handling**: Comprehensive error handling with user-friendly messages
- **Logging**: All API calls logged with security event tracking

## External Dependencies

### Core Framework Dependencies
- **Flask**: Web framework for Python applications
- **SQLAlchemy**: Database ORM with PostgreSQL/SQLite support
- **Flask-WTF**: Form handling and CSRF protection
- **Werkzeug**: WSGI utilities and password hashing

### Security Dependencies
- **cryptography**: Fernet encryption for API key protection
- **hmac/hashlib**: Request signing and integrity verification
- **secrets**: Secure random number generation

### Frontend Dependencies
- **Bootstrap 5.3.0**: CSS framework for responsive design
- **Font Awesome 6.4.0**: Icon library
- **Google Fonts (Inter)**: Typography

### Payment Integration
- **UPI-Only Payment System**: Streamlined payment experience using only UPI transactions
- **UPI QR Code Generation**: Generates QR codes with exact deposit amounts (e.g., ₹100 creates QR for exactly ₹100.00)
- **Real-time Amount Processing**: Precise amount formatting ensures UPI apps receive correct payment values
- **Mobile-Optimized Flow**: Simplified payment interface designed for mobile UPI apps

### External OSINT APIs
- **Mobile Number API**: https://software-jpeg-brochure-knowledgestorm.trycloudflare.com/search?mobile={10-digit-number}
  - Returns multiple records with name, father's name, address, circle/operator information
  - No API key required, direct HTTP GET requests
- **Aadhar Verification APIs**: Government and third-party Aadhar verification services
- **Vehicle Information APIs**: RTO and vehicle registration databases

### Optional Integrations
- **Telegram Bot API**: For user notifications and bot integration
- **Email Services**: For user registration and notifications
- **Analytics Services**: For usage tracking and reporting

### Database Support
- **SQLite**: Default database for development and testing
- **PostgreSQL**: Production database via DATABASE_URL environment variable
- **Connection Pooling**: Built-in connection pool management for reliability

## Recent Updates (July 2025)

### Enhanced Admin Navigation System (Latest - July 31, 2025)
- **Account Management System**: Added comprehensive Account dropdown menu to user navigation with Profile, Settings, Change Password, and Delete Account options
- **Account Settings Page**: Created detailed account settings with notification preferences, privacy controls, and account information display
- **Password Change System**: Built secure password change functionality with current password verification and security validation
- **Account Deletion Process**: Implemented safe account deletion with password confirmation, typed confirmation, and detailed warning information
- **Enhanced Security**: All account management actions logged with comprehensive audit trail

### Telegram Admin Management Enhancement (Latest - July 31, 2025)
- **Dedicated Telegram Management Section**: Created separate admin menu section specifically for Telegram bot management
- **Bot Settings Management**: New admin interface for configuring bot settings, welcome messages, help text, and operational modes
- **Command Usage Analytics**: Comprehensive command statistics dashboard with usage tracking and performance metrics
- **Webhook Status Monitoring**: Real-time webhook health monitoring with performance statistics and management controls
- **Organized Menu Structure**: Restructured admin navigation with logical grouping without auto-opening behavior
- **Complete Bot Administration**: All Telegram bot features now accessible through organized admin interface

### Comprehensive User Management System (July 31, 2025)
- **Complete Admin User Management**: Implemented comprehensive user management system in admin panel
- **Edit User Functionality**: Full user editing including username, email, full name, credits, password, active status, and admin privileges
- **View User Details**: Complete user profile view with transaction history, search history, payments, gift card redemptions, and admin action logs
- **User Statistics**: Real-time statistics showing total spent, earned, searches performed, and referral counts
- **Admin Action Logging**: All user modifications logged with detailed audit trail including old/new values and admin notes
- **Soft Delete System**: Safe user deletion with reason tracking and admin action logging
- **Credit Management**: Direct credit adjustment with automatic transaction record creation
- **Password Reset**: Admins can reset user passwords directly from the edit interface
- **Enhanced User List**: Updated user list with direct View and Edit buttons for streamlined workflow

### Telegram Bot Implementation (Latest - July 31, 2025)
- **Full-Featured Telegram Bot**: Created @MROSINT1bot with complete feature parity with website
- **Bot Token**: 7577806882:AAHPzM8GY8bSpAqp2hd75hw6cgV5f6jf0zM
- **Admin Telegram ID**: 7597633895 for bot management
- **Complete Features**: All website features available through bot - searches, payments, referrals, history
- **Bot Commands**: /start, /help, /balance, /search, /history, /referral, /payment, /protect, /support, /admin
- **Webhook Integration**: Integrated with Flask app for real-time updates
- **QR Code Payments**: Generate UPI QR codes directly in Telegram
- **Admin Panel Integration**: Manage Telegram users and payments from website admin panel
- **Comprehensive Documentation**: Created TELEGRAM_BOT_GUIDE.md with complete usage instructions
- **Auto Registration**: Users automatically registered with Telegram ID as credentials

### Simple API Service Implementation 
- **JSON-Based Configuration**: Created simple config/api_config.json system for easy API service setup
- **No-Code API Integration**: Admins can add new API services by just editing configuration files
- **Dynamic Service Loading**: System automatically loads and manages API services from configuration
- **Admin API Management**: Complete admin interface at /admin/api-config for service management
- **Simplified Documentation**: Created README_API_SETUP.txt with step-by-step instructions
- **API Testing Interface**: Built-in testing system to verify API services before activation

### External Mobile API Integration
- **Integrated External Mobile Search API**: Implemented live mobile number search using provided API endpoint
- **Multiple Results Support**: Updated search results template to display multiple records per mobile number
- **Enhanced Data Display**: Shows name, father's name, address, circle/operator, alternate numbers, and IDs
- **Real-time Search**: Direct API calls without requiring API keys or authentication
- **Improved UI**: Results displayed in cards with proper formatting and record numbering

### Project Documentation Update (August 1, 2025)
- **Created OVERVIEW.md**: Added comprehensive project overview document explaining what MROSINT is, how it works, key features, technical basics, recent improvements, and special notes about Telegram integration
- **Simple Language Documentation**: Overview written in non-technical language for easy understanding by all stakeholders

## Recent Updates (January 2025)

### Support System Implementation
- **Telegram Bot Integration**: Implemented complete support system with Telegram bot @MROSINT1bot
- **Support Ticketing**: Full-featured ticket system with categories, priorities, and status tracking
- **Real-time Notifications**: Telegram notifications for ticket updates, payment confirmations
- **Admin Support Panel**: Comprehensive admin interface for managing support tickets
- **Bot Features**: Balance check, ticket creation, instant notifications via Telegram

### Anti-Interception Security Implementation
- **Burp Suite Protection**: Comprehensive detection and blocking of Burp Suite, OWASP ZAP, Fiddler, Charles Proxy
- **Multi-Layer Detection**: Server-side and client-side threat detection with graduated response system
- **Request Encryption**: AES-256 encryption with HMAC-SHA256 signing for all sensitive communications
- **Real-time Monitoring**: Continuous security monitoring with automated incident reporting
- **Advanced Fingerprinting**: Browser fingerprinting and environment analysis for threat identification

### Security Enhancements
- **Military-Grade API Security**: Implemented AES-256 encryption for all stored API keys
- **Request Authentication**: Added HMAC-SHA256 request signing with timestamps and nonces
- **Security Management Panel**: Created dedicated admin security interface at `/admin/security`
- **Comprehensive Audit Trail**: Complete security logging system with IP tracking and event monitoring
- **Replay Attack Prevention**: Implemented nonce-based protection against replay attacks

### Payment System Optimization
- **UPI-Only Implementation**: Removed all payment methods except UPI for streamlined user experience
- **Enhanced Payment Flow**: Simplified payment interface with UPI-focused design and instructions
- **Mobile-First Design**: Optimized payment system for mobile UPI app integration

### User Interface Improvements
- **Animated Navigation**: Added professional hamburger menu icon with smooth transitions
- **Responsive Design**: Enhanced mobile navigation with Bootstrap collapse functionality
- **Logo Integration**: Consistent MROSINT branding across all pages including admin panel
- **Dark Mode Support**: Persistent dark mode toggle with localStorage integration

### Admin Features
- **Bonus Settings Management**: Real-time configuration of signup, referral, and referral signup bonuses
- **Security Event Monitoring**: Live tracking of failed login attempts and security events
- **Encrypted Key Management**: Secure API key storage and management interface
- **Search Activity Logging**: Comprehensive search query monitoring and analytics