from flask import render_template, request, redirect, url_for, flash, session, jsonify
from app import app, db
from models import User, Search, Transaction, Payment, AdminAction
from forms import LoginForm, RegisterForm, SearchForm, PaymentForm, AdminUserForm
from api_client import api_client
from datetime import datetime
import json
import uuid

# Dynamic pricing configuration from system settings
def get_pricing():
    from models import SystemSetting
    return {
        'mobile': SystemSetting.get_value('search.mobile_cost', 99.0),
        'aadhar': SystemSetting.get_value('search.aadhar_cost', 149.0),
        'vehicle': SystemSetting.get_value('search.vehicle_cost', 49.63)
    }

@app.route('/')
def index():
    if 'user_id' in session:
        return redirect(url_for('dashboard'))
    return render_template('index.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    from models import SystemLog
    
    form = LoginForm()
    if form.validate_on_submit():
        user = User.query.filter_by(username=form.username.data).first()
        if user and user.check_password(form.password.data) and user.is_active:
            session['user_id'] = user.id
            session['username'] = user.username
            session['is_admin'] = user.is_admin
            
            # Log successful login
            SystemLog.log('INFO', 'auth', f'User logged in: {user.username}', 
                         user.id, request.remote_addr, request.headers.get('User-Agent'))
            
            flash('Logged in successfully!', 'success')
            return redirect(url_for('dashboard'))
        else:
            # Log failed login attempt
            SystemLog.log('WARNING', 'auth', f'Failed login attempt for username: {form.username.data}', 
                         None, request.remote_addr, request.headers.get('User-Agent'))
            flash('Invalid username or password', 'error')
    return render_template('login.html', form=form)

@app.route('/register', methods=['GET', 'POST'])
def register():
    from models import SystemLog, SystemSetting
    
    # Check if registration is enabled
    registration_enabled = SystemSetting.get_value('system.registration_enabled', True)
    if not registration_enabled:
        flash('Registration is currently disabled. Please contact administrator.', 'error')
        return redirect(url_for('login'))
    
    form = RegisterForm()
    if form.validate_on_submit():
        welcome_credits = SystemSetting.get_value('system.welcome_credits', 25.0)
        referrer = None
        
        # Check referral code if provided
        if form.referral_code.data:
            referrer = User.query.filter_by(referral_code=form.referral_code.data.strip().upper()).first()
            if not referrer:
                flash('Invalid referral code. Registration will continue without referral bonus.', 'warning')
        
        user = User(
            username=form.username.data,
            email=form.email.data,
            full_name=form.full_name.data,
            credits=welcome_credits,
            referred_by_id=referrer.id if referrer else None
        )
        user.set_password(form.password.data)
        
        # Generate referral code for new user
        user.generate_referral_code()
        
        db.session.add(user)
        db.session.flush()  # Get user ID
        
        # Add welcome transaction
        transaction = Transaction(
            user=user,
            transaction_type='credit',
            amount=welcome_credits,
            description='Welcome bonus'
        )
        db.session.add(transaction)
        
        # Process referral bonus if valid referrer
        if referrer:
            referral_bonus = SystemSetting.get_value('referral.bonus_amount', 5.0)
            
            # Add bonus to referrer
            referrer.credits += referral_bonus
            referrer.total_referrals += 1
            referrer.referral_earnings += referral_bonus
            
            # Create referral bonus transaction
            referral_transaction = Transaction(
                user=referrer,
                transaction_type='credit',
                amount=referral_bonus,
                description=f'Referral bonus for {user.username}'
            )
            db.session.add(referral_transaction)
            
            # Log referral
            SystemLog.log('INFO', 'referral', f'Referral bonus awarded: {referrer.username} -> {user.username} (₹{referral_bonus})', 
                         referrer.id, request.remote_addr)
        
        db.session.commit()
        
        # Log new user registration
        SystemLog.log('INFO', 'auth', f'New user registered: {user.username}' + (' (via referral)' if referrer else ''), 
                     user.id, request.remote_addr, request.headers.get('User-Agent'))
        
        success_message = f'Registration successful! You received ₹{welcome_credits} welcome bonus.'
        if referrer:
            success_message += f' Your referrer earned ₹{SystemSetting.get_value("referral.bonus_amount", 5.0)} bonus!'
        
        flash(success_message, 'success')
        return redirect(url_for('login'))
    return render_template('register.html', form=form)

@app.route('/logout')
def logout():
    session.clear()
    flash('Logged out successfully!', 'info')
    return redirect(url_for('index'))

@app.route('/dashboard')
def dashboard():
    if 'user_id' not in session:
        return redirect(url_for('login'))
    
    user = User.query.get(session['user_id'])
    if not user or not user.is_active:
        session.clear()
        flash('Account deactivated', 'error')
        return redirect(url_for('login'))
    
    stats = user.get_search_stats()
    recent_searches = Search.query.filter_by(user_id=user.id).order_by(Search.created_at.desc()).limit(5).all()
    
    return render_template('dashboard.html', user=user, stats=stats, recent_searches=recent_searches, pricing=get_pricing())

@app.route('/search', methods=['GET', 'POST'])
def search():
    if 'user_id' not in session:
        return redirect(url_for('login'))
    
    user = User.query.get(session['user_id'])
    form = SearchForm()
    
    if form.validate_on_submit():
        search_type = form.search_type.data
        query = form.query.data.upper() if search_type == 'vehicle' else form.query.data
        cost = get_pricing()[search_type]
        
        # Check if user has enough credits
        if user.credits < cost:
            flash(f'Insufficient credits. You need ₹{cost} but have ₹{user.credits:.2f}', 'error')
            return redirect(url_for('credits'))
        
        # Perform secure search based on type
        if search_type == 'mobile':
            result = api_client.search_mobile(query, user.id, request.remote_addr)
        elif search_type == 'aadhar':
            result = api_client.search_aadhar(query, user.id, request.remote_addr)
        else:  # vehicle
            result = api_client.search_vehicle(query, user.id, request.remote_addr)
        
        # Deduct credits
        user.credits -= cost
        
        # Record transaction
        transaction = Transaction(
            user_id=user.id,
            transaction_type='debit',
            amount=cost,
            description=f'{search_type.title()} search: {query}'
        )
        db.session.add(transaction)
        
        # Record search
        search_record = Search(
            user_id=user.id,
            query_type=search_type,
            query_value=query,
            result_data=json.dumps(result),
            credits_used=cost,
            status='completed' if result.get('success') else 'failed'
        )
        db.session.add(search_record)
        db.session.commit()
        
        return render_template('search_results.html', 
                             result=result, 
                             search_type=search_type, 
                             query=query, 
                             cost=cost)
    
    return render_template('search.html', form=form, user=user, pricing=get_pricing())

@app.route('/history')
def history():
    if 'user_id' not in session:
        return redirect(url_for('login'))
    
    user = User.query.get(session['user_id'])
    page = request.args.get('page', 1, type=int)
    searches = Search.query.filter_by(user_id=user.id).order_by(Search.created_at.desc()).paginate(
        page=page, per_page=20, error_out=False
    )
    
    return render_template('history.html', searches=searches, user=user)

@app.route('/referrals')
def referrals():
    if 'user_id' not in session:
        return redirect(url_for('login'))
    
    user = User.query.get(session['user_id'])
    referral_stats = user.get_referral_stats()
    
    return render_template('referrals.html', user=user, referral_stats=referral_stats)

@app.route('/credits', methods=['GET', 'POST'])
def credits():
    if 'user_id' not in session:
        return redirect(url_for('login'))
    
    user = User.query.get(session['user_id'])
    form = PaymentForm()
    
    if form.validate_on_submit():
        amount = form.amount.data
        payment_method = form.payment_method.data
        credits_to_add = amount  # 1 Rupee = 1 Credit
        
        # Create payment record
        payment = Payment(
            user_id=user.id,
            amount=amount,
            credits=credits_to_add,
            payment_method=payment_method,
            transaction_id=str(uuid.uuid4()),
            status='pending'
        )
        db.session.add(payment)
        db.session.commit()
        
        return redirect(url_for('payment', payment_id=payment.id))
    
    # Get recent transactions
    transactions = Transaction.query.filter_by(user_id=user.id).order_by(Transaction.created_at.desc()).limit(10).all()
    
    return render_template('credits.html', form=form, user=user, transactions=transactions)

@app.route('/payment/<int:payment_id>')
def payment(payment_id):
    if 'user_id' not in session:
        return redirect(url_for('login'))
    
    payment = Payment.query.get_or_404(payment_id)
    if payment.user_id != session['user_id']:
        flash('Access denied', 'error')
        return redirect(url_for('dashboard'))
    
    return render_template('payment.html', payment=payment)

@app.route('/complete_payment/<int:payment_id>')
def complete_payment(payment_id):
    """Simulate payment completion - in production this would be handled by payment gateway webhook"""
    if 'user_id' not in session:
        return redirect(url_for('login'))
    
    payment = Payment.query.get_or_404(payment_id)
    if payment.user_id != session['user_id']:
        flash('Access denied', 'error')
        return redirect(url_for('dashboard'))
    
    if payment.status == 'pending':
        # Update payment status
        payment.status = 'completed'
        
        # Add credits to user
        user = User.query.get(payment.user_id)
        user.credits += payment.credits
        
        # Record transaction
        transaction = Transaction(
            user_id=user.id,
            transaction_type='credit',
            amount=payment.credits,
            description=f'Payment completed - {payment.payment_method}'
        )
        db.session.add(transaction)
        db.session.commit()
        
        flash(f'Payment successful! ₹{payment.credits} credits added to your account.', 'success')
    
    return redirect(url_for('dashboard'))

@app.route('/admin')
def admin():
    if 'user_id' not in session or not session.get('is_admin'):
        flash('Access denied', 'error')
        return redirect(url_for('dashboard'))
    
    # Get statistics
    total_users = User.query.count()
    active_users = User.query.filter_by(is_active=True).count()
    total_searches = Search.query.count()
    total_revenue = db.session.query(db.func.sum(Payment.amount)).filter_by(status='completed').scalar() or 0
    
    # Recent users
    recent_users = User.query.order_by(User.created_at.desc()).limit(10).all()
    
    # Recent searches
    recent_searches = Search.query.order_by(Search.created_at.desc()).limit(10).all()
    
    # Pending payments
    pending_payments = Payment.query.filter_by(status='pending').order_by(Payment.created_at.desc()).all()
    
    stats = {
        'total_users': total_users,
        'active_users': active_users,
        'total_searches': total_searches,
        'total_revenue': total_revenue
    }
    
    return render_template('admin.html', 
                         stats=stats, 
                         recent_users=recent_users, 
                         recent_searches=recent_searches,
                         pending_payments=pending_payments)

@app.route('/admin/user/<int:user_id>', methods=['GET', 'POST'])
def admin_user(user_id):
    if 'user_id' not in session or not session.get('is_admin'):
        flash('Access denied', 'error')
        return redirect(url_for('dashboard'))
    
    user = User.query.get_or_404(user_id)
    form = AdminUserForm()
    
    if form.validate_on_submit():
        admin_user = User.query.get(session['user_id'])
        action = form.action.data
        credits = form.credits.data
        reason = form.reason.data
        
        if action == 'add':
            user.credits += credits
            transaction = Transaction(
                user_id=user.id,
                transaction_type='credit',
                amount=credits,
                description=f'Admin credit: {reason}'
            )
            db.session.add(transaction)
            
        elif action == 'remove':
            user.credits = max(0, user.credits - credits)
            transaction = Transaction(
                user_id=user.id,
                transaction_type='debit',
                amount=credits,
                description=f'Admin debit: {reason}'
            )
            db.session.add(transaction)
            
        elif action == 'activate':
            user.is_active = True
            
        elif action == 'deactivate':
            user.is_active = False
        
        # Record admin action
        admin_action = AdminAction(
            admin_id=admin_user.id,
            action=f'{action} - {reason}',
            target_user_id=user.id,
            details=f'Credits: {credits}' if action in ['add', 'remove'] else ''
        )
        db.session.add(admin_action)
        db.session.commit()
        
        flash(f'Action "{action}" completed successfully', 'success')
        return redirect(url_for('admin'))
    
    # Get user's search history and transactions
    searches = Search.query.filter_by(user_id=user.id).order_by(Search.created_at.desc()).limit(10).all()
    transactions = Transaction.query.filter_by(user_id=user.id).order_by(Transaction.created_at.desc()).limit(10).all()
    
    return render_template('admin_user.html', user=user, form=form, searches=searches, transactions=transactions)

@app.route('/admin/settings', methods=['GET', 'POST'])
def admin_settings():
    if 'user_id' not in session or not session.get('is_admin'):
        flash('Access denied', 'error')
        return redirect(url_for('dashboard'))
    
    from models import SystemSetting, APIKey, SystemLog
    
    if request.method == 'POST':
        admin_id = session['user_id']
        action = request.form.get('action')
        
        if action == 'update_setting':
            key = request.form.get('key')
            value = request.form.get('value')
            data_type = request.form.get('data_type', 'string')
            description = request.form.get('description')
            category = request.form.get('category', 'general')
            
            SystemSetting.set_value(key, value, admin_id, description, category, data_type)
            SystemLog.log('INFO', 'admin', f'System setting updated: {key}', admin_id)
            flash(f'Setting "{key}" updated successfully', 'success')
        
        elif action == 'add_api_key':
            from security import secure_client
            
            name = request.form.get('name')
            service = request.form.get('service')
            key_value = request.form.get('key_value')
            description = request.form.get('description')
            
            # Encrypt the API key before storing
            try:
                encrypted_key = secure_client.encrypt_api_key(key_value)
                
                api_key = APIKey(
                    name=name,
                    service=service,
                    key_value=encrypted_key,  # Store encrypted key
                    description=description,
                    created_by=admin_id
                )
                db.session.add(api_key)
                db.session.commit()
                
                SystemLog.log('INFO', 'admin', f'Encrypted API key added: {name}', admin_id)
                flash(f'API key "{name}" added and encrypted successfully', 'success')
                
            except Exception as e:
                SystemLog.log('ERROR', 'admin', f'Failed to encrypt API key: {name} - {str(e)}', admin_id)
                flash('Failed to encrypt and store API key', 'error')
        
        elif action == 'toggle_api_key':
            api_id = request.form.get('api_id')
            api_key = APIKey.query.get(api_id)
            if api_key:
                api_key.is_active = not api_key.is_active
                db.session.commit()
                status = 'activated' if api_key.is_active else 'deactivated'
                SystemLog.log('INFO', 'admin', f'API key {status}: {api_key.name}', admin_id)
                flash(f'API key {status}', 'success')
        
        return redirect(url_for('admin_settings'))
    
    # Get all settings grouped by category
    settings = SystemSetting.query.order_by(SystemSetting.category, SystemSetting.key).all()
    settings_by_category = {}
    for setting in settings:
        if setting.category not in settings_by_category:
            settings_by_category[setting.category] = []
        settings_by_category[setting.category].append(setting)
    
    # Get API keys
    api_keys = APIKey.query.order_by(APIKey.service, APIKey.name).all()
    
    return render_template('admin_settings.html', 
                         settings_by_category=settings_by_category,
                         api_keys=api_keys)

@app.route('/admin/logs')
def admin_logs():
    if 'user_id' not in session or not session.get('is_admin'):
        flash('Access denied', 'error')
        return redirect(url_for('dashboard'))
    
    from models import SystemLog
    
    # Get filters from query parameters
    level = request.args.get('level', '')
    category = request.args.get('category', '')
    page = request.args.get('page', 1, type=int)
    per_page = 50
    
    # Build query
    query = SystemLog.query
    
    if level:
        query = query.filter(SystemLog.level == level)
    if category:
        query = query.filter(SystemLog.category == category)
    
    logs = query.order_by(SystemLog.created_at.desc()).paginate(
        page=page, per_page=per_page, error_out=False
    )
    
    # Get unique levels and categories for filters
    levels = db.session.query(SystemLog.level).distinct().all()
    categories = db.session.query(SystemLog.category).distinct().all()
    
    return render_template('admin_logs.html', 
                         logs=logs,
                         levels=[l[0] for l in levels],
                         categories=[c[0] for c in categories],
                         current_level=level,
                         current_category=category)

@app.route('/admin/security', methods=['GET', 'POST'])
def admin_security():
    if 'user_id' not in session or not session.get('is_admin'):
        flash('Access denied', 'error')
        return redirect(url_for('dashboard'))
    
    from models import APIKey, SystemLog
    from datetime import datetime, timedelta
    
    if request.method == 'POST':
        admin_id = session['user_id']
        action = request.form.get('action')
        
        if action == 'add_api_key':
            from security import secure_client
            
            name = request.form.get('name')
            service = request.form.get('service')
            key_value = request.form.get('key_value')
            description = request.form.get('description')
            
            # Encrypt the API key before storing
            try:
                encrypted_key = secure_client.encrypt_api_key(key_value)
                
                api_key = APIKey(
                    name=name,
                    service=service,
                    key_value=encrypted_key,  # Store encrypted key
                    description=description,
                    created_by=admin_id
                )
                db.session.add(api_key)
                db.session.commit()
                
                SystemLog.log('INFO', 'admin', f'Encrypted API key added: {name}', admin_id)
                flash(f'API key "{name}" added and encrypted successfully', 'success')
                
            except Exception as e:
                SystemLog.log('ERROR', 'admin', f'Failed to encrypt API key: {name} - {str(e)}', admin_id)
                flash('Failed to encrypt and store API key', 'error')
        
        elif action == 'toggle_api_key':
            api_id = request.form.get('api_id')
            api_key = APIKey.query.get(api_id)
            if api_key:
                api_key.is_active = not api_key.is_active
                db.session.commit()
                status = 'activated' if api_key.is_active else 'deactivated'
                SystemLog.log('INFO', 'admin', f'API key {status}: {api_key.name}', admin_id)
                flash(f'API key {status}', 'success')
        
        return redirect(url_for('admin_security'))
    
    # Get API keys
    api_keys = APIKey.query.order_by(APIKey.service, APIKey.name).all()
    
    # Get security statistics
    today = datetime.now().date()
    security_logs_count = SystemLog.query.filter(
        SystemLog.category == 'security',
        db.func.date(SystemLog.created_at) == today
    ).count()
    
    failed_attempts = SystemLog.query.filter(
        SystemLog.category == 'auth',
        SystemLog.level == 'WARNING',
        db.func.date(SystemLog.created_at) == today
    ).count()
    
    # Get recent security logs
    recent_security_logs = SystemLog.query.filter(
        SystemLog.category == 'security'
    ).order_by(SystemLog.created_at.desc()).limit(10).all()
    
    return render_template('admin_security.html',
                         api_keys=api_keys,
                         security_logs_count=security_logs_count,
                         failed_attempts=failed_attempts,
                         recent_security_logs=recent_security_logs)

@app.route('/admin/notifications', methods=['GET', 'POST'])
def admin_notifications():
    if 'user_id' not in session or not session.get('is_admin'):
        flash('Access denied', 'error')
        return redirect(url_for('dashboard'))
    
    from models import Notification, SystemLog
    
    if request.method == 'POST':
        admin_id = session['user_id']
        action = request.form.get('action')
        
        if action == 'send_notification':
            title = request.form.get('title')
            message = request.form.get('message')
            notification_type = request.form.get('type', 'info')
            target_user_id = request.form.get('user_id')
            is_global = request.form.get('is_global') == 'on'
            
            if is_global:
                # Send to all users
                users = User.query.filter_by(is_active=True).all()
                for user in users:
                    notification = Notification(
                        user_id=user.id,
                        title=title,
                        message=message,
                        type=notification_type,
                        is_global=True,
                        created_by=admin_id
                    )
                    db.session.add(notification)
                
                SystemLog.log('INFO', 'admin', f'Global notification sent: {title}', admin_id)
                flash(f'Global notification sent to {len(users)} users', 'success')
            
            elif target_user_id:
                notification = Notification(
                    user_id=target_user_id,
                    title=title,
                    message=message,
                    type=notification_type,
                    created_by=admin_id
                )
                db.session.add(notification)
                
                SystemLog.log('INFO', 'admin', f'Notification sent to user {target_user_id}: {title}', admin_id)
                flash('Notification sent successfully', 'success')
            
            db.session.commit()
        
        return redirect(url_for('admin_notifications'))
    
    # Get recent notifications
    notifications = Notification.query.order_by(Notification.created_at.desc()).limit(50).all()
    
    # Get users for dropdown
    users = User.query.filter_by(is_active=True).order_by(User.username).all()
    
    return render_template('admin_notifications.html', 
                         notifications=notifications,
                         users=users)

@app.route('/admin/analytics')
def admin_analytics():
    if 'user_id' not in session or not session.get('is_admin'):
        flash('Access denied', 'error')
        return redirect(url_for('dashboard'))
    
    from datetime import datetime, timedelta
    from sqlalchemy import func, extract
    
    # Date range for analytics (last 30 days)
    end_date = datetime.now()
    start_date = end_date - timedelta(days=30)
    
    # User registrations over time
    user_registrations = db.session.query(
        func.date(User.created_at).label('date'),
        func.count(User.id).label('count')
    ).filter(
        User.created_at >= start_date
    ).group_by(
        func.date(User.created_at)
    ).order_by('date').all()
    
    # Search statistics by type
    search_stats = db.session.query(
        Search.query_type,
        func.count(Search.id).label('count'),
        func.sum(Search.credits_used).label('total_credits')
    ).group_by(Search.query_type).all()
    
    # Revenue over time
    revenue_stats = db.session.query(
        func.date(Payment.created_at).label('date'),
        func.sum(Payment.amount).label('revenue')
    ).filter(
        Payment.status == 'completed',
        Payment.created_at >= start_date
    ).group_by(
        func.date(Payment.created_at)
    ).order_by('date').all()
    
    # Top users by search activity
    top_users = db.session.query(
        User.username,
        func.count(Search.id).label('search_count'),
        func.sum(Search.credits_used).label('total_credits_used')
    ).join(Search).group_by(User.id, User.username).order_by(
        func.count(Search.id).desc()
    ).limit(10).all()
    
    return render_template('admin_analytics.html',
                         user_registrations=user_registrations,
                         search_stats=search_stats,
                         revenue_stats=revenue_stats,
                         top_users=top_users,
                         start_date=start_date,
                         end_date=end_date)

@app.route('/admin/system')
def admin_system():
    if 'user_id' not in session or not session.get('is_admin'):
        flash('Access denied', 'error')
        return redirect(url_for('dashboard'))
    
    import os
    import psutil
    import sys
    from datetime import datetime
    
    # System information
    system_info = {
        'python_version': sys.version,
        'platform': os.name,
        'cpu_count': psutil.cpu_count(),
        'cpu_percent': psutil.cpu_percent(interval=1),
        'memory': psutil.virtual_memory(),
        'disk': psutil.disk_usage('/'),
        'uptime': datetime.now() - datetime.fromtimestamp(psutil.boot_time())
    }
    
    # Database statistics
    db_stats = {
        'users': User.query.count(),
        'searches': Search.query.count(),
        'transactions': Transaction.query.count(),
        'payments': Payment.query.count(),
        'admin_actions': AdminAction.query.count()
    }
    
    # Recent admin actions
    recent_actions = AdminAction.query.order_by(AdminAction.created_at.desc()).limit(10).all()
    
    return render_template('admin_system.html',
                         system_info=system_info,
                         db_stats=db_stats,
                         recent_actions=recent_actions)

@app.errorhandler(404)
def not_found_error(error):
    return render_template('404.html'), 404

@app.errorhandler(500)
def internal_error(error):
    db.session.rollback()
    return render_template('500.html'), 500
