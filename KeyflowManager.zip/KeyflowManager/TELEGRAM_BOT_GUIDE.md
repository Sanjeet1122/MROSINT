# MROSINT Telegram Bot - Complete Guide

## Table of Contents
1. [Overview](#overview)
2. [Bot Setup & Configuration](#bot-setup--configuration)
3. [User Commands](#user-commands)
4. [Admin Commands](#admin-commands)
5. [Features](#features)
6. [Database Integration](#database-integration)
7. [Payment System](#payment-system)
8. [Security](#security)
9. [Troubleshooting](#troubleshooting)
10. [API Documentation](#api-documentation)

## Overview

MROSINT Telegram Bot is a fully functional bot that mirrors all website features, allowing users to perform OSINT searches directly from Telegram.

### Bot Details
- **Bot Username**: @MROSINT1bot
- **Bot Token**: 7577806882:AAHPzM8GY8bSpAqp2hd75hw6cgV5f6jf0zM
- **Admin ID**: 7597633895
- **Website**: https://mrosint.com

### Key Features
- ✅ Complete OSINT search functionality (Mobile, Aadhar, Vehicle)
- ✅ Credit-based payment system with UPI integration
- ✅ User registration and authentication
- ✅ Search history tracking
- ✅ Referral program
- ✅ Phone number protection
- ✅ Admin panel integration
- ✅ Support system

## Bot Setup & Configuration

### 1. Initial Setup
```bash
# Install dependencies
pip install python-telegram-bot>=20.0

# Set environment variable
export TELEGRAM_BOT_TOKEN="7577806882:AAHPzM8GY8bSpAqp2hd75hw6cgV5f6jf0zM"
```

### 2. Running the Bot
```bash
# Standalone mode
python telegram_bot/bot.py

# With Flask integration
python telegram_bot/webhook.py
```

### 3. Webhook Configuration
For production, use webhooks instead of polling:
```python
# Set webhook URL
https://mrosint.com/telegram-webhook
```

## User Commands

### Basic Commands
| Command | Description | Example |
|---------|-------------|---------|
| `/start` | Start the bot and register | `/start` or `/start REF123` |
| `/help` | Show all available commands | `/help` |
| `/balance` | Check credit balance | `/balance` |
| `/search` | Start a new search | `/search` |
| `/history` | View search history | `/history` |
| `/referral` | Get referral link & stats | `/referral` |
| `/payment` | Add credits to account | `/payment` |
| `/protect` | Protect phone number | `/protect` |
| `/support` | Contact support | `/support` |

### Search Process
1. User sends `/search` command
2. Bot shows search type options (Mobile/Aadhar/Vehicle)
3. User selects type and enters query
4. Bot validates input and checks balance
5. If sufficient credits, performs search
6. Deducts credits and shows results
7. Saves search to history

### Registration Flow
```
User: /start
Bot: Creates account with Telegram ID
     Sets default password as Telegram ID
     Grants ₹500 signup bonus
     Shows login credentials

User: /start REF123
Bot: Same as above + 
     Links to referrer
     Adds ₹25 extra bonus
     Credits ₹50 to referrer
```

## Admin Commands

### Admin-Only Commands
| Command | Description | Access |
|---------|-------------|--------|
| `/admin` | Access admin dashboard | Admin ID only |
| `/broadcast` | Send message to all users | Admin only |
| `/stats` | View system statistics | Admin only |
| `/users` | Manage users | Admin only |
| `/settings` | System settings | Admin only |

### Admin Dashboard Features
- View total users, searches, revenue
- Manage user accounts
- Approve/reject payments
- View analytics
- System settings
- Broadcast messages

## Features

### 1. Search Features
```python
# Mobile Search
- Input: 10-digit number (6-9 starting)
- Cost: ₹99
- Returns: Name, Father name, Address, Operator

# Aadhar Search  
- Input: 12-digit number
- Cost: ₹149
- Returns: Personal details (masked)

# Vehicle Search
- Input: Registration number
- Cost: ₹49.63
- Returns: Owner details, vehicle info
```

### 2. Credit System
- New users get ₹500 signup bonus
- Referral bonus: ₹50 to referrer, ₹25 to new user
- Credits deducted per search
- Real-time balance updates

### 3. Payment Integration
```
User: /payment
Bot: Shows amount options
User: Selects ₹100
Bot: Generates UPI QR code
     Shows payment instructions
     Creates pending payment record
Admin: Approves payment
Bot: Credits added, user notified
```

### 4. Referral System
```python
# Generate referral link
https://t.me/MROSINT1bot?start=USER_REFERRAL_CODE

# Track referrals
- Total referrals count
- Total earnings
- Automatic credit distribution
```

### 5. Number Protection
- Cost: ₹500 (one-time)
- Prevents number from being searched
- Stored in protected_numbers table
- Checked before each search

## Database Integration

### User Management
```python
# Telegram users are created with:
- username: tg_[telegram_id]
- email: tg_[telegram_id]@telegram.user
- password: telegram_id (as string)
- telegram_id: stored for linking
- created_via: 'telegram'
```

### Search Records
- All searches saved with user_id
- Includes query, type, cost, results
- Accessible via /history command

### Transaction Tracking
- Every credit operation logged
- Payment records linked to users
- Admin approval workflow

## Payment System

### UPI Payment Flow
1. User selects amount
2. Bot generates QR code with exact amount
3. User pays via UPI app
4. Admin receives notification
5. Admin approves in admin panel
6. Bot credits user account
7. User receives confirmation

### Payment Commands
```
/payment - Start payment process
- Select preset amounts (₹100, ₹250, ₹500, ₹1000)
- Or enter custom amount
- Generate UPI QR code
- Track payment status
```

## Security

### Authentication
- Telegram ID used as primary identifier
- Automatic account creation on /start
- Secure password generation
- Session management

### Data Protection
- Aadhar numbers masked in display
- Search results encrypted in database
- Protected numbers cannot be searched
- Admin actions logged

### Rate Limiting
- Prevents spam searches
- Cooldown between requests
- Daily search limits (configurable)

## Troubleshooting

### Common Issues

#### Bot Not Responding
```bash
# Check bot status
curl https://api.telegram.org/bot7577806882:AAHPzM8GY8bSpAqp2hd75hw6cgV5f6jf0zM/getMe

# Check webhook
curl https://api.telegram.org/bot7577806882:AAHPzM8GY8bSpAqp2hd75hw6cgV5f6jf0zM/getWebhookInfo
```

#### Database Connection
```python
# Ensure DATABASE_URL is set
# Bot uses same database as website
# Check models are imported
```

#### Payment Issues
- Ensure UPI ID is correct in settings
- Check payment approval workflow
- Verify admin notifications

### Error Messages
| Error | Cause | Solution |
|-------|-------|----------|
| "Please start the bot first" | User not registered | Send /start command |
| "Insufficient credits" | Low balance | Add credits via /payment |
| "Invalid number format" | Wrong input | Check format requirements |
| "Protected number" | Number is protected | Cannot be searched |

## API Documentation

### Webhook Endpoint
```python
POST /telegram-webhook
Content-Type: application/json

{
  "update_id": 123456789,
  "message": {
    "message_id": 1,
    "from": {...},
    "text": "/start",
    ...
  }
}
```

### Bot API Methods Used
- sendMessage - Send text messages
- sendPhoto - Send QR codes
- editMessageText - Update messages
- answerCallbackQuery - Handle button clicks
- sendInvoice - Payment requests (future)

### Integration with Website
- Shared database (PostgreSQL)
- Same user accounts
- Synchronized credits
- Unified search history
- Admin panel integration

## Admin Access Without Main ID

### Alternative Admin Access Methods

#### 1. Website Admin Panel
- Login at https://mrosint.com/admin
- Username: mrmac
- Password: 953146563
- Full control over bot users

#### 2. Database Admin Access
```sql
-- Add admin privileges to user
UPDATE "user" 
SET is_admin = true 
WHERE telegram_id = 'YOUR_TELEGRAM_ID';
```

#### 3. Environment Variable
```bash
# Set multiple admin IDs
export TELEGRAM_ADMIN_IDS="7597633895,OTHER_ID,OTHER_ID"
```

#### 4. Dynamic Admin Management
```python
# Add admin via website
Admin Panel > Users > Edit User > Set Admin = True

# User with admin=true can use /admin command
```

### Emergency Access
If locked out of admin:
1. Access database directly
2. Update user admin status
3. Or use website admin panel
4. Or modify bot.py ADMIN_ID constant

## Maintenance & Updates

### Regular Tasks
- Monitor bot uptime
- Check payment approvals
- Review search logs
- Update API endpoints
- Backup database

### Adding New Features
1. Update bot.py with new handlers
2. Add database models if needed
3. Update admin panel
4. Test thoroughly
5. Update this guide

### Monitoring
- Check @BotFather for bot status
- Monitor error logs
- Track user growth
- Review search patterns
- Analyze revenue

## Support & Contact

### User Support
- Telegram: @mrmac_admin
- Email: support@mrosint.com
- Website: https://mrosint.com/support

### Developer Support
- Check logs in telegram_bot/logs/
- Database queries for debugging
- Telegram Bot API documentation
- Python-telegram-bot documentation

---

**Last Updated**: July 31, 2025
**Version**: 1.0.0
**Author**: MROSINT Development Team