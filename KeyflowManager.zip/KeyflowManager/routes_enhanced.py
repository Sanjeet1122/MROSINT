# Enhanced search logging system inspired from reference
import json
import os
from datetime import datetime
from flask import request

def log_search_query(mobile_number, user_id=None, ip_address=None):
    """Log search queries with detailed information"""
    try:
        # Create logs directory if it doesn't exist
        if not os.path.exists('logs'):
            os.makedirs('logs')
        
        # Load existing queries
        queries_file = 'logs/queries.json'
        if os.path.exists(queries_file):
            with open(queries_file, 'r') as f:
                queries = json.load(f)
        else:
            queries = []
        
        # Add new query
        query_data = {
            'mobile': mobile_number,
            'user_id': user_id,
            'ip_address': ip_address or request.remote_addr,
            'timestamp': datetime.now().isoformat(),
            'user_agent': request.headers.get('User-Agent', ''),
            'success': True
        }
        
        queries.append(query_data)
        
        # Save updated queries
        with open(queries_file, 'w') as f:
            json.dump(queries, f, indent=2)
            
        return True
    except Exception as e:
        print(f"Error logging search query: {e}")
        return False

def get_search_logs():
    """Get all search logs for admin panel"""
    try:
        queries_file = 'logs/queries.json'
        if os.path.exists(queries_file):
            with open(queries_file, 'r') as f:
                return json.load(f)
        return []
    except:
        return []

def format_search_result_with_emojis(data, search_type):
    """Format search results with emojis for better UI"""
    if search_type == 'mobile' and data:
        formatted_data = {
            '📞 Mobile': data.get('mobile', 'Not available'),
            '🙍‍♂️ Name': data.get('name', 'Not available'), 
            '👨‍👦 Father': data.get('fname', 'Not available'),
            '📍 Address': data.get('address', 'Not available').replace('!', ', '),
            '📶 Circle': data.get('circle', 'Not available'),
            '🆔 ID': data.get('id', 'Not available')
        }
        return formatted_data
    elif search_type == 'aadhar' and data:
        formatted_data = {
            '🆔 Aadhar': data.get('aadhar', 'Not available'),
            '👤 Name': data.get('name', 'Not available'),
            '📞 Mobile': data.get('mobile', 'Not available'),
            '📍 Address': data.get('address', 'Not available'),
            '🎂 DOB': data.get('dob', 'Not available')
        }
        return formatted_data
    elif search_type == 'vehicle' and data:
        formatted_data = {
            '🚗 Vehicle Number': data.get('vehicle_number', 'Not available'),
            '👤 Owner': data.get('owner_name', 'Not available'),
            '📞 Mobile': data.get('mobile', 'Not available'),
            '🏠 Address': data.get('address', 'Not available'),
            '🚙 Model': data.get('vehicle_model', 'Not available')
        }
        return formatted_data
    
    return data