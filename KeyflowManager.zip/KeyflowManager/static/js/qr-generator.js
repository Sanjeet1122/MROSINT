// QR Code Generator for MROSINT Payment System

class QRGenerator {
    constructor() {
        this.qrCodeCache = new Map();
    }

    /**
     * Generate QR code using external library (qrcode.js)
     */
    async generateQRCode(data, options = {}) {
        const defaultOptions = {
            width: 200,
            height: 200,
            colorDark: '#000000',
            colorLight: '#ffffff',
            correctLevel: QRCode.CorrectLevel.M
        };

        const qrOptions = { ...defaultOptions, ...options };

        try {
            // Check cache first
            const cacheKey = `${data}_${JSON.stringify(qrOptions)}`;
            if (this.qrCodeCache.has(cacheKey)) {
                return this.qrCodeCache.get(cacheKey);
            }

            // Create QR code container
            const qrContainer = document.createElement('div');
            
            // Generate QR code
            const qrCode = new QRCode(qrContainer, {
                text: data,
                width: qrOptions.width,
                height: qrOptions.height,
                colorDark: qrOptions.colorDark,
                colorLight: qrOptions.colorLight,
                correctLevel: qrOptions.correctLevel
            });

            // Wait for QR code generation
            await new Promise(resolve => setTimeout(resolve, 100));

            // Get the generated SVG or Canvas
            const qrElement = qrContainer.querySelector('canvas') || qrContainer.querySelector('svg');
            
            if (!qrElement) {
                throw new Error('Failed to generate QR code');
            }

            // Convert to data URL if canvas
            let qrDataUrl;
            if (qrElement.tagName === 'CANVAS') {
                qrDataUrl = qrElement.toDataURL('image/png');
            } else {
                // For SVG, serialize to string
                const serializer = new XMLSerializer();
                qrDataUrl = 'data:image/svg+xml;base64,' + btoa(serializer.serializeToString(qrElement));
            }

            // Cache the result
            this.qrCodeCache.set(cacheKey, qrDataUrl);

            return qrDataUrl;
        } catch (error) {
            console.error('QR Code generation failed:', error);
            throw error;
        }
    }

    /**
     * Generate UPI payment QR code
     */
    async generateUPIQR(paymentData) {
        const {
            upiId,
            payeeName,
            amount,
            transactionNote,
            transactionId
        } = paymentData;

        // UPI URL format
        const upiUrl = `upi://pay?pa=${upiId}&pn=${encodeURIComponent(payeeName)}&am=${amount}&cu=INR&tn=${encodeURIComponent(transactionNote)}&tr=${transactionId}`;

        return await this.generateQRCode(upiUrl, {
            width: 250,
            height: 250
        });
    }

    /**
     * Display QR code in a container
     */
    async displayQRCode(containerId, data, options = {}) {
        const container = document.getElementById(containerId);
        if (!container) {
            throw new Error(`Container with ID ${containerId} not found`);
        }

        try {
            // Show loading state
            container.innerHTML = `
                <div class="qr-loading">
                    <div class="spinner"></div>
                    <p>Generating QR Code...</p>
                </div>
            `;

            const qrDataUrl = await this.generateQRCode(data, options);

            // Display the QR code
            container.innerHTML = `
                <div class="qr-code-display">
                    <img src="${qrDataUrl}" alt="QR Code" class="qr-image" />
                    <div class="qr-actions">
                        <button class="btn btn-outline" onclick="QRGen.downloadQR('${qrDataUrl}', 'qr-code.png')">
                            <i class="fas fa-download"></i> Download
                        </button>
                        <button class="btn btn-outline" onclick="QRGen.copyQRData('${data}')">
                            <i class="fas fa-copy"></i> Copy Data
                        </button>
                    </div>
                </div>
            `;

            return qrDataUrl;
        } catch (error) {
            container.innerHTML = `
                <div class="qr-error">
                    <i class="fas fa-exclamation-triangle"></i>
                    <p>Failed to generate QR code</p>
                    <small>${error.message}</small>
                </div>
            `;
            throw error;
        }
    }

    /**
     * Download QR code as image
     */
    downloadQR(dataUrl, filename = 'qr-code.png') {
        const link = document.createElement('a');
        link.href = dataUrl;
        link.download = filename;
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
    }

    /**
     * Copy QR code data to clipboard
     */
    async copyQRData(data) {
        try {
            await navigator.clipboard.writeText(data);
            this.showNotification('QR code data copied to clipboard!', 'success');
        } catch (error) {
            console.error('Failed to copy to clipboard:', error);
            this.showNotification('Failed to copy to clipboard', 'error');
        }
    }

    /**
     * Show notification
     */
    showNotification(message, type = 'info') {
        const notification = document.createElement('div');
        notification.className = `qr-notification qr-notification-${type}`;
        notification.textContent = message;

        document.body.appendChild(notification);

        // Auto-remove after 3 seconds
        setTimeout(() => {
            notification.style.opacity = '0';
            setTimeout(() => {
                if (notification.parentNode) {
                    notification.parentNode.removeChild(notification);
                }
            }, 300);
        }, 3000);
    }

    /**
     * Generate and display payment QR code
     */
    async generatePaymentQR(paymentId, containerSelector = '.qr-code-container') {
        try {
            const response = await fetch(`/admin/generate-qr/${paymentId}`);
            const data = await response.json();

            if (data.success) {
                const container = document.querySelector(containerSelector);
                if (container) {
                    container.innerHTML = `
                        <div class="qr-code-display">
                            <div class="qr-image-container">
                                <img src="${data.qr_code_url}" alt="UPI QR Code" class="qr-image" style="max-width: 300px; border-radius: 10px;">
                            </div>
                            <div class="qr-info">
                                <p class="text-muted">Scan this QR code with any UPI app</p>
                                <div class="upi-string">
                                    <small class="text-break">${data.upi_string}</small>
                                </div>
                                <div class="alert alert-info mt-2" style="font-size: 0.9rem;">
                                    <strong>Amount:</strong> ₹${data.amount}<br>
                                    <strong>UPI ID:</strong> 9053407823@mbk
                                </div>
                            </div>
                            <div class="qr-actions">
                                <button class="btn btn-outline btn-sm" onclick="QRGen.copyQRData('${data.upi_string.replace(/'/g, "\\'")}')">
                                    <i class="fas fa-copy"></i> Copy UPI String
                                </button>
                            </div>
                        </div>
                    `;
                }
            } else {
                throw new Error(data.error || 'Failed to generate QR code');
            }
        } catch (error) {
            console.error('Payment QR generation failed:', error);
            const container = document.querySelector(containerSelector);
            if (container) {
                container.innerHTML = `
                    <div class="qr-error">
                        <i class="fas fa-exclamation-triangle"></i>
                        <p>Failed to generate payment QR code</p>
                        <small>${error.message}</small>
                    </div>
                `;
            }
        }
    }

    /**
     * Validate UPI ID format
     */
    validateUPIId(upiId) {
        const upiRegex = /^[a-zA-Z0-9.\-_]{2,256}@[a-zA-Z]{2,64}$/;
        return upiRegex.test(upiId);
    }

    /**
     * Format UPI payment URL
     */
    formatUPIUrl(paymentData) {
        const {
            upiId,
            payeeName = 'MROSINT',
            amount,
            transactionNote = 'Payment',
            transactionId
        } = paymentData;

        if (!this.validateUPIId(upiId)) {
            throw new Error('Invalid UPI ID format');
        }

        if (!amount || amount <= 0) {
            throw new Error('Invalid amount');
        }

        const params = new URLSearchParams({
            pa: upiId,
            pn: payeeName,
            am: amount.toString(),
            cu: 'INR',
            tn: transactionNote
        });

        if (transactionId) {
            params.append('tr', transactionId);
        }

        return `upi://pay?${params.toString()}`;
    }

    /**
     * Clear QR code cache
     */
    clearCache() {
        this.qrCodeCache.clear();
    }
}

// Create global instance
const QRGen = new QRGenerator();

// Auto-generate QR codes for payment pages
document.addEventListener('DOMContentLoaded', function() {
    // Generate QR codes for payment containers
    const qrContainers = document.querySelectorAll('[data-payment-qr]');
    qrContainers.forEach(async container => {
        const paymentId = container.getAttribute('data-payment-qr');
        if (paymentId) {
            await QRGen.generatePaymentQR(paymentId, `#${container.id}`);
        }
    });

    // Handle manual QR generation buttons
    const qrButtons = document.querySelectorAll('[data-generate-qr]');
    qrButtons.forEach(button => {
        button.addEventListener('click', async function() {
            const paymentId = this.getAttribute('data-generate-qr');
            const targetContainer = this.getAttribute('data-target') || '.qr-code-container';
            
            try {
                this.disabled = true;
                this.innerHTML = '<span class="spinner"></span> Generating...';
                
                await QRGen.generatePaymentQR(paymentId, targetContainer);
                
                this.innerHTML = '<i class="fas fa-qrcode"></i> Regenerate QR';
            } catch (error) {
                this.innerHTML = '<i class="fas fa-exclamation-triangle"></i> Failed';
            } finally {
                this.disabled = false;
            }
        });
    });

    // Handle UPI string copy buttons
    const copyButtons = document.querySelectorAll('[data-copy-upi]');
    copyButtons.forEach(button => {
        button.addEventListener('click', function() {
            const upiString = this.getAttribute('data-copy-upi');
            QRGen.copyQRData(upiString);
        });
    });
});

// Add CSS for QR code components
const qrStyles = `
    .qr-code-display {
        text-align: center;
        padding: 1rem;
    }

    .qr-image-container {
        display: inline-block;
        padding: 1rem;
        background: white;
        border: 2px solid var(--border);
        border-radius: var(--radius-lg);
        margin-bottom: 1rem;
    }

    .qr-image {
        max-width: 100%;
        height: auto;
        border-radius: var(--radius-sm);
    }

    .qr-info {
        margin: 1rem 0;
    }

    .qr-actions {
        display: flex;
        gap: 0.5rem;
        justify-content: center;
        flex-wrap: wrap;
    }

    .qr-loading,
    .qr-error {
        text-align: center;
        padding: 2rem;
        color: var(--text-muted);
    }

    .qr-loading .spinner {
        width: 40px;
        height: 40px;
        border: 4px solid var(--border);
        border-top-color: var(--primary);
        border-radius: 50%;
        animation: spin 1s linear infinite;
        margin: 0 auto 1rem;
    }

    .qr-error i {
        font-size: 2rem;
        color: var(--error);
        margin-bottom: 1rem;
    }

    .qr-notification {
        position: fixed;
        top: 20px;
        right: 20px;
        padding: 1rem 1.5rem;
        border-radius: var(--radius-md);
        color: white;
        font-weight: 500;
        z-index: 10000;
        transition: opacity 0.3s ease;
    }

    .qr-notification-success {
        background-color: var(--success);
    }

    .qr-notification-error {
        background-color: var(--error);
    }

    .qr-notification-info {
        background-color: var(--primary);
    }

    @media (max-width: 768px) {
        .qr-actions {
            flex-direction: column;
            align-items: center;
        }
        
        .qr-actions .btn {
            width: 100%;
            max-width: 200px;
        }
    }
`;

// Inject styles
const styleSheet = document.createElement('style');
styleSheet.textContent = qrStyles;
document.head.appendChild(styleSheet);

// Export for use in other scripts
window.QRGenerator = QRGenerator;
window.QRGen = QRGen;
