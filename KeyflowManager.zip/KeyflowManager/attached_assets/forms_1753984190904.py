from flask_wtf import FlaskForm
from wtforms import StringField, PasswordField, FloatField, SelectField, TextAreaField, IntegerField
from wtforms.validators import DataRequired, Email, Length, NumberRange, Regexp, ValidationError, Optional
from models import User
import re

class LoginForm(FlaskForm):
    username = StringField('Username', validators=[DataRequired(), Length(min=3, max=64)])
    password = PasswordField('Password', validators=[DataRequired()])

class RegisterForm(FlaskForm):
    username = StringField('Username', validators=[
        DataRequired(), 
        Length(min=3, max=64),
        Regexp('^[A-Za-z0-9_]+$', message='Username must contain only letters, numbers, and underscores')
    ])
    email = StringField('Email', validators=[DataRequired(), Email()])
    full_name = StringField('Full Name', validators=[DataRequired(), Length(min=2, max=100)])
    password = PasswordField('Password', validators=[DataRequired(), Length(min=6)])
    referral_code = StringField('Referral Code (Optional)', validators=[Optional()])
    
    def validate_username(self, username):
        user = User.query.filter_by(username=username.data).first()
        if user:
            raise ValidationError('Username already exists. Choose a different one.')
    
    def validate_email(self, email):
        user = User.query.filter_by(email=email.data).first()
        if user:
            raise ValidationError('Email already registered. Choose a different one.')

class SearchForm(FlaskForm):
    search_type = SelectField('Search Type', choices=[
        ('mobile', 'Mobile Number'),
        ('aadhar', 'Aadhar Number'),
        ('vehicle', 'Vehicle Number')
    ], validators=[DataRequired()])
    query = StringField('Search Query', validators=[DataRequired()])
    
    def validate_query(self, query):
        if self.search_type.data == 'mobile':
            if not re.match(r'^\d{10}$', query.data):
                raise ValidationError('Mobile number must be exactly 10 digits')
        elif self.search_type.data == 'aadhar':
            if not re.match(r'^\d{12}$', query.data):
                raise ValidationError('Aadhar number must be exactly 12 digits')
        elif self.search_type.data == 'vehicle':
            if not re.match(r'^[A-Z]{2}\d{2}[A-Z]{1,2}\d{4}$', query.data.upper()):
                raise ValidationError('Vehicle number format should be like UP14GF2831')

class PaymentForm(FlaskForm):
    amount = FloatField('Amount', validators=[
        DataRequired(), 
        NumberRange(min=100, max=10000, message='Amount must be between ₹100 and ₹10,000')
    ])
    payment_method = SelectField('Payment Method', choices=[
        ('upi', 'UPI Payment'),
        ('netbanking', 'Net Banking'),
        ('card', 'Credit/Debit Card')
    ], validators=[DataRequired()])

class AdminUserForm(FlaskForm):
    user_id = IntegerField('User ID', validators=[DataRequired()])
    credits = FloatField('Credits to Add/Remove', validators=[DataRequired()])
    action = SelectField('Action', choices=[
        ('add', 'Add Credits'),
        ('remove', 'Remove Credits'),
        ('activate', 'Activate User'),
        ('deactivate', 'Deactivate User')
    ], validators=[DataRequired()])
    reason = TextAreaField('Reason', validators=[DataRequired()])
