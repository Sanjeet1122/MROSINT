import os
import logging
from flask import Flask
from flask_sqlalchemy import SQLAlchemy
from sqlalchemy.orm import DeclarativeBase
from werkzeug.middleware.proxy_fix import ProxyFix

# Configure logging
logging.basicConfig(level=logging.DEBUG)

class Base(DeclarativeBase):
    pass

db = SQLAlchemy(model_class=Base)

# Create the app
app = Flask(__name__)
app.secret_key = os.environ.get("SESSION_SECRET", "dev-secret-key-change-in-production")
app.wsgi_app = ProxyFix(app.wsgi_app, x_proto=1, x_host=1)

# Configure the database - use SQLite for development if external DB is unavailable
database_url = os.environ.get("DATABASE_URL", "sqlite:///mrosint.db")
# Override with SQLite if external database is unavailable
if "neon.tech" in database_url:
    database_url = "sqlite:///mrosint.db"
app.config["SQLALCHEMY_DATABASE_URI"] = database_url
app.config["SQLALCHEMY_ENGINE_OPTIONS"] = {
    "pool_recycle": 300,
    "pool_pre_ping": True,
}

# Additional configuration
app.config['WTF_CSRF_ENABLED'] = False  # Disable CSRF for now
app.config['WTF_CSRF_TIME_LIMIT'] = 3600
app.config['MAX_CONTENT_LENGTH'] = 16 * 1024 * 1024  # 16MB max file upload

# Initialize the app with the extension
db.init_app(app)

with app.app_context():
    # Import models to ensure tables are created
    import models
    import routes
    import admin_routes
    import support_routes
    import gift_card_routes
    import admin_security_routes
    
    # Create all tables
    db.create_all()
    
    # Initialize default admin user and system settings
    # models.init_default_data()  # Commented out to avoid initialization issues
